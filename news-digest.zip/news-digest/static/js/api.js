/**
 * API client for News Digest
 */

const API_BASE = '/api';

// Get stored auth token
function getToken() {
    return localStorage.getItem('token');
}

// Set auth token
function setToken(token) {
    localStorage.setItem('token', token);
}

// Clear auth token
function clearToken() {
    localStorage.removeItem('token');
}

// Get stored user
function getUser() {
    const user = localStorage.getItem('user');
    return user ? JSON.parse(user) : null;
}

// Set user
function setUser(user) {
    localStorage.setItem('user', JSON.stringify(user));
}

// Clear user
function clearUser() {
    localStorage.removeItem('user');
}

// Check if logged in
function isLoggedIn() {
    return !!getToken();
}

// API request helper
async function apiRequest(endpoint, options = {}) {
    const token = getToken();
    
    const headers = {
        'Content-Type': 'application/json',
        ...options.headers
    };
    
    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    }
    
    const response = await fetch(`${API_BASE}${endpoint}`, {
        ...options,
        headers
    });
    
    if (response.status === 401) {
        clearToken();
        clearUser();
        window.location.href = '/';
        throw new Error('Unauthorized');
    }
    
    const data = await response.json();
    
    if (!response.ok) {
        throw new Error(data.detail || 'Request failed');
    }
    
    return data;
}

// Auth API
const api = {
    auth: {
        async register(email, username, password) {
            const data = await apiRequest('/auth/register', {
                method: 'POST',
                body: JSON.stringify({ email, username, password })
            });
            if (data.access_token) {
                setToken(data.access_token);
                setUser(data.user);
            }
            return data;
        },
        
        async login(email, password) {
            const data = await apiRequest('/auth/login', {
                method: 'POST',
                body: JSON.stringify({ email, password })
            });
            if (data.access_token) {
                setToken(data.access_token);
                setUser(data.user);
            }
            return data;
        },
        
        logout() {
            clearToken();
            clearUser();
            window.location.href = '/';
        }
    },
    
    digest: {
        async getToday(refresh = false) {
            return apiRequest(`/digest/today?refresh=${refresh}`);
        },
        
        async getHistory(limit = 30) {
            return apiRequest(`/digest/history?limit=${limit}`);
        },
        
        async getStats() {
            return apiRequest('/digest/stats');
        },
        
        // Streaming digest generation
        streamToday(onEvent, onComplete, onError) {
            const token = getToken();
            const eventSource = new EventSource(`${API_BASE}/digest/today/stream`, {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });
            
            // For SSE with auth, we need to use fetch
            fetch(`${API_BASE}/digest/today/stream`, {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            }).then(response => {
                const reader = response.body.getReader();
                const decoder = new TextDecoder();
                
                function read() {
                    reader.read().then(({ done, value }) => {
                        if (done) {
                            onComplete && onComplete();
                            return;
                        }
                        
                        const text = decoder.decode(value);
                        const lines = text.split('\n');
                        
                        for (const line of lines) {
                            if (line.startsWith('data: ')) {
                                try {
                                    const event = JSON.parse(line.slice(6));
                                    onEvent && onEvent(event);
                                    
                                    if (event.type === 'complete') {
                                        onComplete && onComplete(event);
                                    }
                                } catch (e) {
                                    console.error('Failed to parse event:', e);
                                }
                            }
                        }
                        
                        read();
                    }).catch(onError);
                }
                
                read();
            }).catch(onError);
        }
    },
    
    articles: {
        async getAll(limit = 50, source = null, topics = null) {
            let url = `/articles?limit=${limit}`;
            if (source) url += `&source=${source}`;
            if (topics) url += `&topics=${topics.join(',')}`;
            return apiRequest(url);
        },
        
        async search(query, limit = 20) {
            return apiRequest(`/articles/search?q=${encodeURIComponent(query)}&limit=${limit}`);
        },
        
        async get(articleId) {
            return apiRequest(`/articles/${articleId}`);
        }
    },
    
    preferences: {
        async get() {
            return apiRequest('/preferences');
        },
        
        async update(updates) {
            return apiRequest('/preferences', {
                method: 'PUT',
                body: JSON.stringify(updates)
            });
        },
        
        async reset() {
            return apiRequest('/preferences/reset', { method: 'POST' });
        },
        
        async blockSource(source) {
            return apiRequest('/preferences/block-source', {
                method: 'POST',
                body: JSON.stringify({ source })
            });
        },
        
        async unblockSource(source) {
            return apiRequest('/preferences/unblock-source', {
                method: 'POST',
                body: JSON.stringify({ source })
            });
        },
        
        async addCustomFeed(name, url) {
            return apiRequest('/preferences/custom-feed', {
                method: 'POST',
                body: JSON.stringify({ name, url })
            });
        },
        
        async removeCustomFeed(name) {
            return apiRequest(`/preferences/custom-feed/${name}`, {
                method: 'DELETE'
            });
        }
    },
    
    interactions: {
        async record(articleId, action, articleData = {}, digestDate = null) {
            return apiRequest('/interactions', {
                method: 'POST',
                body: JSON.stringify({
                    article_id: articleId,
                    action,
                    article_title: articleData.title || '',
                    article_topics: articleData.topics || [],
                    article_source: articleData.source || '',
                    digest_date: digestDate
                })
            });
        },
        
        async getHistory(limit = 50) {
            return apiRequest(`/interactions/history?limit=${limit}`);
        }
    },
    
    // Chat API
    chat: {
        async send(message, conversationHistory = [], articleId = null) {
            return apiRequest('/chat', {
                method: 'POST',
                body: JSON.stringify({
                    message,
                    conversation_history: conversationHistory,
                    article_id: articleId
                })
            });
        },
        
        async clearHistory() {
            return apiRequest('/chat/history', {
                method: 'DELETE'
            });
        },
        
        // Stream chat (for real-time typing effect)
        async streamChat(message, conversationHistory, onChunk, onComplete, onError) {
            const token = getToken();
            
            try {
                const response = await fetch(`${API_BASE}/chat/stream`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}`
                    },
                    body: JSON.stringify({
                        message,
                        conversation_history: conversationHistory
                    })
                });
                
                const reader = response.body.getReader();
                const decoder = new TextDecoder();
                
                while (true) {
                    const { done, value } = await reader.read();
                    if (done) break;
                    
                    const text = decoder.decode(value);
                    const lines = text.split('\n');
                    
                    for (const line of lines) {
                        if (line.startsWith('data: ')) {
                            try {
                                const event = JSON.parse(line.slice(6));
                                if (event.type === 'chunk') {
                                    onChunk && onChunk(event.content);
                                } else if (event.type === 'complete') {
                                    onComplete && onComplete(event);
                                } else if (event.type === 'error') {
                                    onError && onError(new Error(event.error));
                                }
                            } catch (e) {
                                console.error('Parse error:', e);
                            }
                        }
                    }
                }
            } catch (error) {
                onError && onError(error);
            }
        }
    },
    
    // Explain API
    explain: {
        async getExplanation(articleId, level = 'eli5') {
            return apiRequest(`/explain/${articleId}?level=${level}`);
        },
        
        async explainTopic(articleId, topic) {
            return apiRequest(`/explain/${articleId}/topic`, {
                method: 'POST',
                body: JSON.stringify({ topic })
            });
        }
    },
    
    // Audio API
    audio: {
        async getToday(style = 'briefing') {
            return apiRequest(`/audio/today?style=${style}`);
        },
        
        async getArticle(articleId) {
            return apiRequest(`/audio/article/${articleId}`);
        },
        
        async getHeadlines(count = 5) {
            return apiRequest(`/audio/headlines?count=${count}`);
        }
    }
};

// Export for use in other scripts
window.api = api;
window.isLoggedIn = isLoggedIn;
window.getUser = getUser;
