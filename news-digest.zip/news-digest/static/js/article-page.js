/**
 * Article Page - Full screen article view with AI features
 */

let articleData = null;
let conversationHistory = [];
let currentExplainLevel = 'simple';
let isPlaying = false;
let speechUtterance = null;
let isExplainLoading = false;  // Prevent tab switching during generation

document.addEventListener('DOMContentLoaded', async () => {
    // Check auth
    if (!isLoggedIn()) {
        window.location.href = '/';
        return;
    }
    
    // Get article ID from URL
    const urlParams = new URLSearchParams(window.location.search);
    const articleId = urlParams.get('id');
    
    if (!articleId) {
        showError('No article ID provided');
        return;
    }
    
    // Try to get article data from sessionStorage first (passed from dashboard)
    const storedArticle = sessionStorage.getItem('currentArticle');
    if (storedArticle) {
        articleData = JSON.parse(storedArticle);
        renderArticle(articleData);
    }
    
    // Fetch fresh article data
    try {
        const response = await api.articles.get(articleId);
        if (response) {
            articleData = response;
            renderArticle(articleData);
        }
    } catch (error) {
        if (!articleData) {
            showError('Article not found');
        }
    }
    
    // Set up event listeners
    setupEventListeners();
    
    // Load initial explanation (simple is default)
    loadExplanation('simple');
});

function renderArticle(article) {
    // Title
    document.getElementById('article-title').textContent = article.title;
    document.title = `${article.title} - News Digest`;
    
    // Source and time
    document.getElementById('article-source').textContent = article.source?.toUpperCase() || 'NEWS';
    document.getElementById('article-time').textContent = formatTimeAgo(article.published);
    
    // TLDR
    const tldrSection = document.getElementById('tldr-section');
    if (article.tldr) {
        document.getElementById('tldr-text').textContent = article.tldr;
        tldrSection.style.display = 'block';
    } else {
        tldrSection.style.display = 'none';
    }
    
    // Summary
    document.getElementById('article-summary').textContent = article.summary || article.description;
    
    // Original link
    document.getElementById('read-original').href = article.link;
    
    // Badges
    renderBadges(article);
    
    // Topics
    renderTopics(article.topics || []);
    
    // Sentiment
    renderSentiment(article.sentiment, article.sentiment_score);
    
    // Bias
    renderBias(article.bias, article.bias_explanation);
    
    // Related
    renderRelated(article.related_ids || []);
}

function renderBadges(article) {
    const container = document.getElementById('article-badges');
    const badges = [];
    
    if (article.is_breaking) {
        badges.push(`<span class="badge badge-breaking">🔴 Breaking News</span>`);
    }
    
    if (article.sentiment) {
        const sentimentEmoji = {
            'positive': '😊',
            'negative': '😟', 
            'neutral': '😐',
            'mixed': '🤔'
        };
        badges.push(`<span class="badge badge-${article.sentiment}">${sentimentEmoji[article.sentiment] || ''} ${article.sentiment}</span>`);
    }
    
    container.innerHTML = badges.join('');
}

function renderTopics(topics) {
    const container = document.getElementById('topics-cloud');
    container.innerHTML = topics.map(topic => 
        `<span class="topic-tag">${topic}</span>`
    ).join('');
}

function renderSentiment(sentiment, score) {
    const container = document.getElementById('sentiment-display');
    
    const sentimentConfig = {
        'positive': { emoji: '😊', color: 'positive', percent: 75 + (score || 0) * 25 },
        'negative': { emoji: '😟', color: 'negative', percent: 25 + (score || 0) * 25 },
        'neutral': { emoji: '😐', color: '', percent: 50 },
        'mixed': { emoji: '🤔', color: 'mixed', percent: 50 }
    };
    
    const config = sentimentConfig[sentiment] || sentimentConfig['neutral'];
    
    container.innerHTML = `
        <div class="sentiment-icon">${config.emoji}</div>
        <div class="sentiment-info">
            <div class="sentiment-label">${sentiment || 'Analyzing...'}</div>
            <div class="sentiment-bar">
                <div class="sentiment-fill ${config.color}" style="width: ${config.percent}%;"></div>
            </div>
        </div>
    `;
}

function renderBias(bias, explanation) {
    const biasPositions = {
        'left': 10,
        'center-left': 30,
        'center': 50,
        'center-right': 70,
        'right': 90,
        'factual': 50
    };
    
    const position = biasPositions[bias] || 50;
    
    document.querySelector('.bias-marker').style.left = `${position}%`;
    document.getElementById('bias-explanation').textContent = explanation || 'Analysis pending...';
}

async function renderRelated(relatedIds) {
    const container = document.getElementById('related-list');
    
    if (!relatedIds || relatedIds.length === 0) {
        container.innerHTML = '<p class="empty-state">No related articles found</p>';
        return;
    }
    
    container.innerHTML = '<p class="empty-state">Loading related articles...</p>';
    
    // Get related articles from sessionStorage (digest data) or fetch them
    const digestData = sessionStorage.getItem('digestArticles');
    let relatedArticles = [];
    
    if (digestData) {
        const allArticles = JSON.parse(digestData);
        relatedArticles = allArticles.filter(a => relatedIds.includes(a.id));
    }
    
    // If we couldn't find them in cache, try fetching
    if (relatedArticles.length === 0) {
        try {
            // Fetch each related article
            for (const id of relatedIds.slice(0, 3)) {
                try {
                    const article = await api.articles.get(id);
                    if (article) {
                        relatedArticles.push(article);
                    }
                } catch (e) {
                    console.log('Could not fetch related article:', id);
                }
            }
        } catch (e) {
            console.error('Error fetching related:', e);
        }
    }
    
    if (relatedArticles.length === 0) {
        container.innerHTML = '<p class="empty-state">Related articles not available</p>';
        return;
    }
    
    container.innerHTML = relatedArticles.slice(0, 3).map(article => `
        <a href="/article?id=${article.id}" class="related-item" onclick="sessionStorage.setItem('currentArticle', JSON.stringify(${JSON.stringify(article).replace(/"/g, '&quot;')}))">
            <div class="related-source">${article.source?.toUpperCase() || 'NEWS'}</div>
            <div class="related-title">${article.title}</div>
        </a>
    `).join('');
}

async function loadExplanation(level) {
    // Prevent switching tabs while loading
    if (isExplainLoading) return;
    
    currentExplainLevel = level;
    const container = document.getElementById('explain-content');
    
    // Update active tab and disable all tabs during loading
    document.querySelectorAll('.explain-tab').forEach(tab => {
        tab.classList.toggle('active', tab.dataset.level === level);
    });
    
    // Set loading state
    isExplainLoading = true;
    setTabsDisabled(true);
    
    container.innerHTML = `
        <div class="explain-loading">
            <div class="pulse-dot"></div>
            <span>AI is analyzing article...</span>
        </div>
    `;
    
    if (!articleData?.id) {
        isExplainLoading = false;
        setTabsDisabled(false);
        return;
    }
    
    try {
        const response = await api.explain.getExplanation(articleData.id, level);
        
        if (response.success) {
            container.innerHTML = renderMarkdown(response.explanation);
        } else {
            container.innerHTML = `<p style="color: var(--accent-warm);">Failed to generate explanation</p>`;
        }
    } catch (error) {
        container.innerHTML = `<p style="color: var(--accent-warm);">Error: ${error.message}</p>`;
    } finally {
        // Re-enable tabs
        isExplainLoading = false;
        setTabsDisabled(false);
    }
}

function setTabsDisabled(disabled) {
    document.querySelectorAll('.explain-tab').forEach(tab => {
        tab.disabled = disabled;
        tab.style.opacity = disabled ? '0.5' : '1';
        tab.style.cursor = disabled ? 'not-allowed' : 'pointer';
    });
}

// Markdown renderer
function renderMarkdown(text) {
    if (!text) return '';
    
    // Process line by line for better control
    const lines = text.split('\n');
    let html = '';
    let inList = false;
    
    for (let i = 0; i < lines.length; i++) {
        let line = lines[i];
        
        // Escape HTML
        line = line.replace(/</g, '&lt;').replace(/>/g, '&gt;');
        
        // Headers (must check longer patterns first)
        if (line.match(/^#{4,}\s+(.+)$/)) {
            if (inList) { html += '</ul>'; inList = false; }
            const content = line.replace(/^#{4,}\s+/, '');
            html += `<h4>${processInline(content)}</h4>`;
            continue;
        }
        if (line.match(/^###\s+(.+)$/)) {
            if (inList) { html += '</ul>'; inList = false; }
            const content = line.replace(/^###\s+/, '');
            html += `<h4>${processInline(content)}</h4>`;
            continue;
        }
        if (line.match(/^##\s+(.+)$/)) {
            if (inList) { html += '</ul>'; inList = false; }
            const content = line.replace(/^##\s+/, '');
            html += `<h3>${processInline(content)}</h3>`;
            continue;
        }
        if (line.match(/^#\s+(.+)$/)) {
            if (inList) { html += '</ul>'; inList = false; }
            const content = line.replace(/^#\s+/, '');
            html += `<h2>${processInline(content)}</h2>`;
            continue;
        }
        
        // Bullet points
        if (line.match(/^\s*[-*]\s+(.+)$/)) {
            if (!inList) { html += '<ul>'; inList = true; }
            const content = line.replace(/^\s*[-*]\s+/, '');
            html += `<li>${processInline(content)}</li>`;
            continue;
        }
        
        // Numbered lists
        if (line.match(/^\s*\d+\.\s+(.+)$/)) {
            if (!inList) { html += '<ol>'; inList = true; }
            const content = line.replace(/^\s*\d+\.\s+/, '');
            html += `<li>${processInline(content)}</li>`;
            continue;
        }
        
        // Close list if we hit a non-list line
        if (inList && line.trim() !== '') {
            html += '</ul>';
            inList = false;
        }
        
        // Empty line = paragraph break
        if (line.trim() === '') {
            if (inList) { html += '</ul>'; inList = false; }
            html += '<br><br>';
            continue;
        }
        
        // Regular text
        html += processInline(line) + '<br>';
    }
    
    // Close any open list
    if (inList) html += '</ul>';
    
    // Clean up excessive breaks
    html = html.replace(/(<br>){3,}/g, '<br><br>');
    html = html.replace(/^<br>+/, '').replace(/<br>+$/, '');
    
    return `<div class="markdown-content">${html}</div>`;
}

// Process inline markdown (bold, italic, code, links)
function processInline(text) {
    return text
        // Bold (must come before italic)
        .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
        .replace(/__(.+?)__/g, '<strong>$1</strong>')
        // Italic
        .replace(/\*([^*]+)\*/g, '<em>$1</em>')
        .replace(/_([^_]+)_/g, '<em>$1</em>')
        // Inline code
        .replace(/`([^`]+)`/g, '<code>$1</code>')
        // Links [text](url)
        .replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank">$1</a>');
}

function setupEventListeners() {
    // Explain tabs
    document.querySelectorAll('.explain-tab').forEach(tab => {
        tab.addEventListener('click', () => loadExplanation(tab.dataset.level));
    });
    
    // Chat FAB
    const chatFab = document.getElementById('chat-fab');
    const chatPanel = document.getElementById('chat-panel');
    const chatClose = document.getElementById('chat-close');
    const chatSend = document.getElementById('chat-send');
    const chatInput = document.getElementById('chat-input');
    
    chatFab.addEventListener('click', () => chatPanel.classList.add('open'));
    chatClose.addEventListener('click', () => chatPanel.classList.remove('open'));
    chatSend.addEventListener('click', sendChatMessage);
    chatInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendChatMessage();
        }
    });
    
    // Listen button
    document.getElementById('listen-btn').addEventListener('click', toggleAudio);
    
    // Like button
    document.getElementById('like-btn').addEventListener('click', async () => {
        const btn = document.getElementById('like-btn');
        btn.classList.toggle('active');
        if (articleData) {
            await api.interactions.record(articleData.id, 'like', articleData);
        }
    });
    
    // Dismiss button
    document.getElementById('dismiss-btn').addEventListener('click', async () => {
        if (articleData) {
            await api.interactions.record(articleData.id, 'dismiss', articleData);
            window.location.href = '/dashboard';
        }
    });
    
    // Save button
    document.getElementById('save-btn').addEventListener('click', async () => {
        const btn = document.getElementById('save-btn');
        btn.classList.toggle('active');
        if (articleData) {
            await api.interactions.record(articleData.id, 'save', articleData);
        }
    });
    
    // Audio controls
    document.getElementById('audio-play').addEventListener('click', togglePlayback);
    document.getElementById('audio-close').addEventListener('click', closeAudio);
}

async function sendChatMessage() {
    const chatInput = document.getElementById('chat-input');
    const chatMessages = document.getElementById('chat-messages');
    
    const message = chatInput.value.trim();
    if (!message) return;
    
    // Add user message
    addChatMessage('user', message);
    chatInput.value = '';
    
    // Show typing
    const typingEl = document.createElement('div');
    typingEl.className = 'chat-message assistant';
    typingEl.id = 'typing';
    typingEl.innerHTML = '<em>Thinking...</em>';
    chatMessages.appendChild(typingEl);
    chatMessages.scrollTop = chatMessages.scrollHeight;
    
    try {
        const response = await api.chat.send(message, conversationHistory, articleData?.id);
        document.getElementById('typing')?.remove();
        
        if (response.success) {
            addChatMessage('assistant', response.response);
            conversationHistory = response.conversation_history;
        }
    } catch (error) {
        document.getElementById('typing')?.remove();
        addChatMessage('assistant', `Error: ${error.message}`);
    }
}

function addChatMessage(role, content) {
    const chatMessages = document.getElementById('chat-messages');
    const msg = document.createElement('div');
    msg.className = `chat-message ${role}`;
    msg.innerHTML = `<p>${content.replace(/\n/g, '<br>')}</p>`;
    chatMessages.appendChild(msg);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function toggleAudio() {
    const audioBar = document.getElementById('audio-bar');
    audioBar.classList.add('show');
    generateAndPlay();
}

async function generateAndPlay() {
    if (!articleData) return;
    
    const audioTitle = document.querySelector('.audio-title');
    audioTitle.textContent = 'Generating audio...';
    
    try {
        const response = await api.audio.getArticle(articleData.id);
        
        if (response.success) {
            audioTitle.textContent = articleData.title;
            playAudio(response.script);
        }
    } catch (error) {
        audioTitle.textContent = 'Failed to generate';
    }
}

function playAudio(text) {
    if (!('speechSynthesis' in window)) return;
    
    window.speechSynthesis.cancel();
    
    speechUtterance = new SpeechSynthesisUtterance(text);
    speechUtterance.rate = parseFloat(document.getElementById('audio-speed').value);
    
    const playBtn = document.getElementById('audio-play');
    const progressBar = document.getElementById('audio-progress');
    
    speechUtterance.onstart = () => {
        isPlaying = true;
        playBtn.textContent = '⏸';
        playBtn.classList.add('playing');
    };
    
    speechUtterance.onend = () => {
        isPlaying = false;
        playBtn.textContent = '▶';
        playBtn.classList.remove('playing');
        progressBar.style.width = '100%';
    };
    
    speechUtterance.onboundary = (e) => {
        if (e.name === 'word') {
            const progress = (e.charIndex / text.length) * 100;
            progressBar.style.width = `${progress}%`;
        }
    };
    
    window.speechSynthesis.speak(speechUtterance);
}

function togglePlayback() {
    if (isPlaying) {
        window.speechSynthesis.pause();
        isPlaying = false;
        document.getElementById('audio-play').textContent = '▶';
    } else {
        window.speechSynthesis.resume();
        isPlaying = true;
        document.getElementById('audio-play').textContent = '⏸';
    }
}

function closeAudio() {
    window.speechSynthesis.cancel();
    document.getElementById('audio-bar').classList.remove('show');
    isPlaying = false;
}

function formatTimeAgo(dateString) {
    if (!dateString) return '';
    const date = new Date(dateString);
    const now = new Date();
    const diff = Math.floor((now - date) / 1000);
    
    if (diff < 60) return 'Just now';
    if (diff < 3600) return `${Math.floor(diff / 60)} minutes ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)} hours ago`;
    return date.toLocaleDateString();
}

function showError(message) {
    document.getElementById('article-title').textContent = message;
    document.getElementById('article-summary').textContent = 'Please go back and try again.';
}
