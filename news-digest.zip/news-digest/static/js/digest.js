/**
 * Dashboard/Digest page logic
 */

document.addEventListener('DOMContentLoaded', () => {
    // Check authentication
    if (!isLoggedIn()) {
        window.location.href = '/';
        return;
    }
    
    // Display username
    const user = getUser();
    const usernameEl = document.getElementById('username');
    if (usernameEl && user) {
        usernameEl.textContent = user.username;
    }
    
    // Logout button
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', () => {
            api.auth.logout();
        });
    }
    
    // Load digest
    loadDigest();
    
    // Refresh button
    const refreshBtn = document.getElementById('refresh-btn');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', () => loadDigest(true));
    }
});

let currentDigestDate = null;

async function loadDigest(refresh = false) {
    const container = document.getElementById('article-grid');
    const statusEl = document.getElementById('digest-status');
    
    if (!container) return;
    
    // If refreshing, use streaming for real-time updates
    if (refresh) {
        await loadDigestStreaming(container, statusEl);
        return;
    }
    
    // Show loading
    container.innerHTML = `
        <div class="loading" style="grid-column: 1 / -1;">
            <div class="spinner"></div>
            <p class="mt-2">Loading your personalized digest...</p>
        </div>
    `;
    
    try {
        const result = await api.digest.getToday(false);
        
        if (!result.success) {
            throw new Error(result.error || 'Failed to load digest');
        }
        
        const digest = result.digest;
        currentDigestDate = digest.date;
        
        // Update status
        if (statusEl) {
            const cached = result.cached ? ' (cached)' : ' (fresh)';
            statusEl.textContent = `${digest.article_count} articles${cached}`;
        }
        
        renderDigest(container, digest);
        
    } catch (error) {
        console.error('Error loading digest:', error);
        container.innerHTML = `
            <div class="empty-state" style="grid-column: 1 / -1;">
                <h3>Error loading digest</h3>
                <p>${error.message}</p>
                <button class="btn btn-primary mt-2" onclick="loadDigest()">Try Again</button>
            </div>
        `;
    }
}

async function loadDigestStreaming(container, statusEl) {
    // Show streaming progress UI
    container.innerHTML = `
        <div class="generation-progress" style="grid-column: 1 / -1;">
            <div class="progress-header">
                <div class="progress-icon">🤖</div>
                <h3>Generating Your Personalized Digest</h3>
            </div>
            <div class="progress-stages">
                <div class="stage" id="stage-fetching">
                    <div class="stage-icon">📡</div>
                    <div class="stage-info">
                        <div class="stage-title">Fetching News</div>
                        <div class="stage-detail" id="stage-fetching-detail">Connecting to RSS feeds...</div>
                    </div>
                    <div class="stage-status pending"></div>
                </div>
                <div class="stage" id="stage-processing">
                    <div class="stage-icon">🧠</div>
                    <div class="stage-info">
                        <div class="stage-title">AI Analysis</div>
                        <div class="stage-detail" id="stage-processing-detail">Waiting...</div>
                    </div>
                    <div class="stage-status pending"></div>
                </div>
                <div class="stage" id="stage-personalizing">
                    <div class="stage-icon">✨</div>
                    <div class="stage-info">
                        <div class="stage-title">Personalizing</div>
                        <div class="stage-detail" id="stage-personalizing-detail">Waiting...</div>
                    </div>
                    <div class="stage-status pending"></div>
                </div>
            </div>
            <div class="progress-bar-container">
                <div class="progress-bar-fill" id="progress-bar" style="width: 0%"></div>
            </div>
            <div class="progress-articles" id="progress-articles"></div>
        </div>
    `;
    
    const token = localStorage.getItem('token');
    
    try {
        const response = await fetch('/api/digest/today/stream', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let progressPercent = 0;
        
        while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            
            const text = decoder.decode(value);
            const lines = text.split('\n');
            
            for (const line of lines) {
                if (line.startsWith('data: ')) {
                    try {
                        const event = JSON.parse(line.slice(6));
                        handleStreamEvent(event, container, statusEl);
                        
                        // Update progress bar
                        if (event.phase === 'fetching') progressPercent = 15;
                        else if (event.phase === 'processing' || event.phase === 'ai_processing') progressPercent = 35;
                        else if (event.type === 'article_processed') {
                            progressPercent = 35 + (event.article_number / event.total) * 40;
                        }
                        else if (event.phase === 'personalizing') progressPercent = 80;
                        else if (event.phase === 'saving') progressPercent = 95;
                        else if (event.type === 'complete') progressPercent = 100;
                        
                        const progressBar = document.getElementById('progress-bar');
                        if (progressBar) {
                            progressBar.style.width = `${progressPercent}%`;
                        }
                        
                        if (event.type === 'complete') {
                            // Render the completed digest
                            setTimeout(() => {
                                const digest = event.digest;
                                currentDigestDate = digest.date;
                                if (statusEl) {
                                    statusEl.textContent = `${digest.article_count} articles (fresh)`;
                                }
                                renderDigest(container, digest);
                            }, 500);
                        }
                    } catch (e) {
                        console.error('Failed to parse event:', e);
                    }
                }
            }
        }
    } catch (error) {
        console.error('Streaming error:', error);
        // Fallback to regular loading
        container.innerHTML = `
            <div class="empty-state" style="grid-column: 1 / -1;">
                <h3>Generation Error</h3>
                <p>${error.message}</p>
                <button class="btn btn-primary mt-2" onclick="loadDigest()">Try Again</button>
            </div>
        `;
    }
}

function handleStreamEvent(event, container, statusEl) {
    const progressArticles = document.getElementById('progress-articles');
    
    if (event.phase === 'fetching') {
        updateStage('fetching', 'active', 'Connecting to news sources...');
    } else if (event.phase === 'processing' || event.phase === 'ai_processing') {
        updateStage('fetching', 'complete', 'Done');
        updateStage('processing', 'active', 'AI is analyzing articles...');
    } else if (event.type === 'article_processed') {
        updateStage('processing', 'active', `Processing ${event.article_number}/${event.total}`);
        
        // Show article being processed
        if (progressArticles) {
            const articleEl = document.createElement('div');
            articleEl.className = 'progress-article-item';
            articleEl.innerHTML = `<span class="check">✓</span> ${event.title}...`;
            progressArticles.appendChild(articleEl);
            
            // Keep only last 5
            while (progressArticles.children.length > 5) {
                progressArticles.removeChild(progressArticles.firstChild);
            }
        }
    } else if (event.phase === 'personalizing') {
        updateStage('processing', 'complete', 'Analysis complete');
        updateStage('personalizing', 'active', 'Ranking by your preferences...');
    } else if (event.phase === 'saving') {
        updateStage('personalizing', 'complete', 'Done');
    } else if (event.phase === 'fallback') {
        updateStage('processing', 'active', 'Using quick analysis...');
    } else if (event.type === 'status') {
        // Generic status update
        const detail = document.getElementById(`stage-${event.phase}-detail`);
        if (detail) {
            detail.textContent = event.message;
        }
    } else if (event.type === 'error') {
        container.innerHTML = `
            <div class="empty-state" style="grid-column: 1 / -1;">
                <h3>Error</h3>
                <p>${event.message}</p>
                <button class="btn btn-primary mt-2" onclick="loadDigest()">Try Again</button>
            </div>
        `;
    }
}

function updateStage(stageId, status, detail) {
    const stage = document.getElementById(`stage-${stageId}`);
    const detailEl = document.getElementById(`stage-${stageId}-detail`);
    
    if (stage) {
        const statusEl = stage.querySelector('.stage-status');
        statusEl.className = `stage-status ${status}`;
        
        if (status === 'active') {
            stage.classList.add('active');
        } else if (status === 'complete') {
            stage.classList.remove('active');
            stage.classList.add('complete');
        }
    }
    
    if (detailEl && detail) {
        detailEl.textContent = detail;
    }
}

function renderDigest(container, digest) {
    if (digest.articles.length === 0) {
        container.innerHTML = `
            <div class="empty-state" style="grid-column: 1 / -1;">
                <h3>No articles found</h3>
                <p>Try refreshing or check back later for new content.</p>
            </div>
        `;
        return;
    }
    
    // Store articles in sessionStorage for related article lookups
    sessionStorage.setItem('digestArticles', JSON.stringify(digest.articles));
    
    container.innerHTML = digest.articles.map(article => renderArticleCard(article)).join('');
    attachArticleActions();
}

function renderArticleCard(article) {
    const topics = (article.topics || []).map(t => 
        `<span class="topic-tag">${t}</span>`
    ).join('');
    
    const timeAgo = article.published ? formatTimeAgo(article.published) : '';
    const isTldrMode = document.getElementById('tldr-mode')?.checked || false;
    
    // Build badges
    const badges = [];
    
    // Breaking news badge
    if (article.is_breaking) {
        badges.push(`<span class="badge badge-breaking">🔴 Breaking</span>`);
    }
    
    // Sentiment badge
    if (article.sentiment) {
        const sentimentEmoji = {
            'positive': '😊',
            'negative': '😟',
            'neutral': '😐',
            'mixed': '🤔'
        };
        badges.push(`<span class="badge badge-${article.sentiment}">${sentimentEmoji[article.sentiment] || ''} ${article.sentiment}</span>`);
    }
    
    // Bias badge
    if (article.bias && article.bias !== 'center') {
        const biasLabels = {
            'left': '← Left',
            'center-left': '↙ Center-Left',
            'center': '○ Center',
            'center-right': '↗ Center-Right',
            'right': '→ Right',
            'factual': '✓ Factual'
        };
        badges.push(`<span class="badge badge-${article.bias}" title="${article.bias_explanation || ''}">${biasLabels[article.bias] || article.bias}</span>`);
    }
    
    const badgesHtml = badges.length > 0 ? `<div class="article-badges">${badges.join('')}</div>` : '';
    
    // Summary content - show TLDR or full summary based on mode
    const summaryContent = isTldrMode && article.tldr 
        ? `<p class="article-tldr">"${article.tldr}"</p>`
        : `<p class="article-summary">${article.summary}</p>`;
    
    // Related articles indicator
    const hasRelated = article.related_ids && article.related_ids.length > 0;
    const relatedBtn = hasRelated 
        ? `<button class="ai-action-btn" data-action="related" title="View related articles">🔗 Related (${article.related_ids.length})</button>`
        : '';
    
    const breakingClass = article.is_breaking ? 'breaking' : '';
    
    return `
        <article class="article-card ${breakingClass}" data-article-id="${article.id}" data-article='${JSON.stringify(article).replace(/'/g, "&#39;")}'>
            <div class="article-card-body">
                <span class="article-source">${article.source}</span>
                ${badgesHtml}
                <h3 class="article-title">
                    <a href="/article?id=${article.id}" 
                       onclick="openArticlePage('${article.id}', ${JSON.stringify(article).replace(/"/g, '&quot;')}); return true;"
                    >${article.title}</a>
                </h3>
                ${summaryContent}
                <div class="article-topics">${topics}</div>
                
                <!-- AI Actions -->
                <div class="ai-actions">
                    <button class="ai-action-btn" data-action="expand" title="Full article view">📖 Read More</button>
                    <button class="ai-action-btn" data-action="explain" title="Explain simply">💡 Explain</button>
                    <button class="ai-action-btn" data-action="audio" title="Listen to summary">🔊 Listen</button>
                    ${relatedBtn}
                </div>
                
                <div class="article-footer">
                    <div class="article-actions">
                        <button class="article-action" data-action="like" title="Like">
                            ♥
                        </button>
                        <button class="article-action" data-action="save" title="Save">
                            ★
                        </button>
                        <button class="article-action" data-action="dismiss" title="Not interested">
                            ✕
                        </button>
                    </div>
                    <span class="article-time">${timeAgo}</span>
                </div>
            </div>
        </article>
    `;
}

function attachArticleActions() {
    // Standard actions (like, save, dismiss)
    document.querySelectorAll('.article-action').forEach(btn => {
        btn.addEventListener('click', async (e) => {
            e.preventDefault();
            
            const card = btn.closest('.article-card');
            const articleId = card.dataset.articleId;
            const action = btn.dataset.action;
            
            // Get article data
            const title = card.querySelector('.article-title a').textContent;
            const source = card.querySelector('.article-source').textContent;
            const topics = Array.from(card.querySelectorAll('.topic-tag'))
                .map(t => t.textContent);
            
            try {
                await api.interactions.record(articleId, action, {
                    title, source, topics
                }, currentDigestDate);
                
                // Update UI
                if (action === 'like') {
                    btn.classList.toggle('liked');
                } else if (action === 'save') {
                    btn.classList.toggle('saved');
                } else if (action === 'dismiss') {
                    card.style.opacity = '0.5';
                    btn.classList.add('dismissed');
                }
                
                showToast(`Article ${action}ed`);
            } catch (error) {
                console.error('Error recording interaction:', error);
                showToast('Failed to record action', 'error');
            }
        });
    });
    
    // AI Actions (expand, explain, audio, related)
    document.querySelectorAll('.ai-action-btn').forEach(btn => {
        btn.addEventListener('click', async (e) => {
            e.preventDefault();
            const card = btn.closest('.article-card');
            const articleId = card.dataset.articleId;
            const action = btn.dataset.action;
            
            if (action === 'expand') {
                const article = JSON.parse(card.dataset.article);
                openArticlePage(articleId, article);
            } else if (action === 'explain') {
                showExplainModal(articleId);
            } else if (action === 'audio') {
                speakArticle(articleId, card);
            } else if (action === 'related') {
                showRelatedModal(articleId, card);
            }
        });
    });
}

// Open full article page
function openArticlePage(articleId, article) {
    // Store article data for the article page
    sessionStorage.setItem('currentArticle', JSON.stringify(article));
    // Record click
    api.interactions.record(articleId, 'click', article, currentDigestDate)
        .catch(err => console.error('Failed to record click:', err));
    // Navigate
    window.location.href = `/article?id=${articleId}`;
}

// TLDR toggle functionality
document.addEventListener('DOMContentLoaded', () => {
    const tldrToggle = document.getElementById('tldr-mode');
    if (tldrToggle) {
        tldrToggle.addEventListener('change', () => {
            // Re-render articles with new mode
            loadDigest(false);
        });
    }
});

// Explain modal
async function showExplainModal(articleId) {
    const modal = document.getElementById('explain-modal');
    const content = document.getElementById('explain-content');
    const title = document.getElementById('explain-title');
    
    modal.classList.add('show');
    content.innerHTML = '<div class="loading"><div class="spinner"></div><p>Generating explanation...</p></div>';
    
    try {
        const response = await api.explain.getExplanation(articleId, 'eli5');
        title.textContent = `Explain: ${response.article_title || 'Article'}`;
        content.innerHTML = `<p>${response.explanation}</p>`;
    } catch (error) {
        content.innerHTML = `<p style="color: var(--accent-danger);">Failed to generate explanation: ${error.message}</p>`;
    }
}

// Related modal
async function showRelatedModal(articleId, card) {
    const modal = document.getElementById('related-modal');
    const content = document.getElementById('related-content');
    
    modal.classList.add('show');
    content.innerHTML = '<div class="loading"><div class="spinner"></div><p>Finding related articles...</p></div>';
    
    try {
        // Get article data from card
        const article = JSON.parse(card.dataset.article);
        const relatedIds = article.related_ids || [];
        
        if (relatedIds.length === 0) {
            content.innerHTML = '<p>No related articles found.</p>';
            return;
        }
        
        // Find related articles in current digest
        const relatedArticles = [];
        document.querySelectorAll('.article-card').forEach(otherCard => {
            if (relatedIds.includes(otherCard.dataset.articleId)) {
                const relatedData = JSON.parse(otherCard.dataset.article);
                relatedArticles.push(relatedData);
            }
        });
        
        if (relatedArticles.length === 0) {
            content.innerHTML = '<p>Related articles not in current digest.</p>';
            return;
        }
        
        const html = relatedArticles.map(a => `
            <div class="related-article-item">
                <span class="related-source">[${a.source}]</span>
                <a href="${a.link}" target="_blank">${a.title}</a>
            </div>
        `).join('');
        
        content.innerHTML = html;
    } catch (error) {
        content.innerHTML = `<p style="color: var(--accent-danger);">Failed to load related articles: ${error.message}</p>`;
    }
}

// Close modal
function closeModal(modalId) {
    document.getElementById(modalId).classList.remove('show');
}

// Click outside modal to close
document.addEventListener('click', (e) => {
    if (e.target.classList.contains('modal-overlay')) {
        e.target.classList.remove('show');
    }
});

// Speak article using Web Speech API
function speakArticle(articleId, card) {
    const article = JSON.parse(card.dataset.article);
    const text = `${article.title}. From ${article.source}. ${article.tldr || article.summary}`;
    
    if ('speechSynthesis' in window) {
        // Stop any current speech
        window.speechSynthesis.cancel();
        
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.rate = parseFloat(document.getElementById('audio-speed')?.value || 1);
        utterance.onstart = () => {
            card.querySelector('[data-action="audio"]')?.classList.add('active');
        };
        utterance.onend = () => {
            card.querySelector('[data-action="audio"]')?.classList.remove('active');
        };
        
        window.speechSynthesis.speak(utterance);
        showToast('Playing article audio...');
    } else {
        showToast('Speech synthesis not supported', 'error');
    }
}

function recordClick(articleId, article) {
    api.interactions.record(articleId, 'click', article, currentDigestDate)
        .catch(err => console.error('Failed to record click:', err));
}

function formatTimeAgo(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const diff = Math.floor((now - date) / 1000);
    
    if (diff < 60) return 'Just now';
    if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
    if (diff < 604800) return `${Math.floor(diff / 86400)}d ago`;
    
    return date.toLocaleDateString();
}

function showToast(message, type = 'success') {
    let container = document.querySelector('.toast-container');
    if (!container) {
        container = document.createElement('div');
        container.className = 'toast-container';
        document.body.appendChild(container);
    }
    
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    container.appendChild(toast);
    
    setTimeout(() => {
        toast.remove();
    }, 3000);
}

// Expose for onclick handlers
window.loadDigest = loadDigest;
window.recordClick = recordClick;
window.openArticlePage = openArticlePage;
