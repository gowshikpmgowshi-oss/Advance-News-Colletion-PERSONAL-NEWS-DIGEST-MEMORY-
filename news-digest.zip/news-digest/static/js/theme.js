/**
 * Theme Manager - Handles light/dark mode switching
 */

const THEME_KEY = 'news-digest-theme';

// Get stored theme or default to light
function getStoredTheme() {
    return localStorage.getItem(THEME_KEY) || 'light';
}

// Set theme
function setTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem(THEME_KEY, theme);
    updateThemeToggleIcon(theme);
}

// Toggle between light and dark
function toggleTheme() {
    const current = getStoredTheme();
    const next = current === 'light' ? 'dark' : 'light';
    setTheme(next);
    return next;
}

// Update the toggle button icon
function updateThemeToggleIcon(theme) {
    const toggleBtns = document.querySelectorAll('.theme-toggle, .theme-toggle-nav');
    toggleBtns.forEach(btn => {
        if (theme === 'dark') {
            btn.innerHTML = '☀️';
            btn.title = 'Switch to Light Mode';
        } else {
            btn.innerHTML = '🌙';
            btn.title = 'Switch to Dark Mode';
        }
    });
}

// Initialize theme on page load
function initTheme() {
    const theme = getStoredTheme();
    document.documentElement.setAttribute('data-theme', theme);
    
    // Wait for DOM to be ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            updateThemeToggleIcon(theme);
            attachThemeToggleListeners();
        });
    } else {
        updateThemeToggleIcon(theme);
        attachThemeToggleListeners();
    }
}

// Attach click listeners to theme toggle buttons
function attachThemeToggleListeners() {
    const toggleBtns = document.querySelectorAll('.theme-toggle, .theme-toggle-nav');
    toggleBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            toggleTheme();
        });
    });
}

// Initialize immediately
initTheme();

// Export for use
window.toggleTheme = toggleTheme;
window.setTheme = setTheme;
window.getStoredTheme = getStoredTheme;
