/**
 * Authentication page logic
 */

function initAuth() {
    // If already logged in, redirect to dashboard
    if (isLoggedIn()) {
        window.location.href = '/dashboard';
        return;
    }
    
    // Tab switching
    const tabs = document.querySelectorAll('.auth-tab');
    const forms = document.querySelectorAll('.auth-form');
    
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const targetForm = tab.dataset.form;
            
            // Update tabs
            tabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            
            // Update forms
            forms.forEach(f => f.classList.remove('active'));
            document.getElementById(`${targetForm}-form`).classList.add('active');
        });
    });
    
    // Login form
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const email = document.getElementById('login-email').value;
            const password = document.getElementById('login-password').value;
            const submitBtn = loginForm.querySelector('button[type="submit"]');
            const errorDiv = document.getElementById('login-error');
            
            submitBtn.disabled = true;
            submitBtn.textContent = 'Signing in...';
            errorDiv.textContent = '';
            
            try {
                await api.auth.login(email, password);
                window.location.href = '/dashboard';
            } catch (error) {
                errorDiv.textContent = error.message;
                submitBtn.disabled = false;
                submitBtn.textContent = 'Sign In';
            }
        });
    }
    
    // Register form
    const registerForm = document.getElementById('register-form');
    if (registerForm) {
        registerForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const email = document.getElementById('register-email').value;
            const username = document.getElementById('register-username').value;
            const password = document.getElementById('register-password').value;
            const confirmPassword = document.getElementById('register-confirm').value;
            const submitBtn = registerForm.querySelector('button[type="submit"]');
            const errorDiv = document.getElementById('register-error');
            
            // Validate passwords match
            if (password !== confirmPassword) {
                errorDiv.textContent = 'Passwords do not match';
                return;
            }
            
            submitBtn.disabled = true;
            submitBtn.textContent = 'Creating account...';
            errorDiv.textContent = '';
            
            try {
                await api.auth.register(email, username, password);
                window.location.href = '/dashboard';
            } catch (error) {
                errorDiv.textContent = error.message;
                submitBtn.disabled = false;
                submitBtn.textContent = 'Create Account';
            }
        });
    }
}

// Initialize when DOM is ready (handle both cases: already loaded or still loading)
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initAuth);
} else {
    initAuth();
}
