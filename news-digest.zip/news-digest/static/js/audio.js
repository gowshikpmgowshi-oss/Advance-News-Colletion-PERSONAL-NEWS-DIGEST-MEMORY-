/**
 * Audio player functionality for TTS news digest
 */

let audioScript = null;
let isPlaying = false;
let speechUtterance = null;

document.addEventListener('DOMContentLoaded', () => {
    const audioPlayer = document.getElementById('audio-player');
    const audioPlayBtn = document.getElementById('audio-play-btn');
    const audioGenerateBtn = document.getElementById('audio-generate-btn');
    const audioSpeed = document.getElementById('audio-speed');
    const audioStatus = document.getElementById('audio-status');
    
    // Check if speech synthesis is available
    if ('speechSynthesis' in window) {
        if (audioPlayer) {
            audioPlayer.style.display = 'flex';
        }
    }
    
    // Generate audio script
    if (audioGenerateBtn) {
        audioGenerateBtn.addEventListener('click', async () => {
            audioGenerateBtn.disabled = true;
            audioGenerateBtn.textContent = '⏳ Generating...';
            audioStatus.textContent = 'Generating script...';
            
            try {
                const response = await api.audio.getToday('briefing');
                
                if (response.success) {
                    audioScript = response.script;
                    audioStatus.textContent = `Ready (${response.estimated_duration_minutes} min)`;
                    audioGenerateBtn.textContent = '✓ Ready';
                    audioPlayBtn.disabled = false;
                    showToast('Audio digest ready to play!');
                } else {
                    throw new Error(response.error || 'Failed to generate');
                }
            } catch (error) {
                audioStatus.textContent = 'Generation failed';
                audioGenerateBtn.textContent = '🔊 Retry';
                showToast(`Audio generation failed: ${error.message}`, 'error');
            }
            
            audioGenerateBtn.disabled = false;
        });
    }
    
    // Play/pause button
    if (audioPlayBtn) {
        audioPlayBtn.addEventListener('click', () => {
            if (!audioScript) {
                showToast('Generate audio first', 'error');
                return;
            }
            
            if (isPlaying) {
                stopAudio();
            } else {
                playAudio();
            }
        });
    }
    
    // Speed change
    if (audioSpeed) {
        audioSpeed.addEventListener('change', () => {
            if (speechUtterance && isPlaying) {
                // Restart with new speed
                const currentText = audioScript;
                stopAudio();
                setTimeout(() => {
                    audioScript = currentText;
                    playAudio();
                }, 100);
            }
        });
    }
});

function playAudio() {
    if (!audioScript || !('speechSynthesis' in window)) return;
    
    const audioPlayBtn = document.getElementById('audio-play-btn');
    const audioStatus = document.getElementById('audio-status');
    const audioSpeed = document.getElementById('audio-speed');
    
    // Cancel any existing speech
    window.speechSynthesis.cancel();
    
    // Create utterance
    speechUtterance = new SpeechSynthesisUtterance(audioScript);
    speechUtterance.rate = parseFloat(audioSpeed?.value || 1);
    speechUtterance.pitch = 1;
    
    // Get a good voice
    const voices = window.speechSynthesis.getVoices();
    const preferredVoice = voices.find(v => 
        v.name.includes('Samantha') || 
        v.name.includes('Google') ||
        v.name.includes('Microsoft')
    );
    if (preferredVoice) {
        speechUtterance.voice = preferredVoice;
    }
    
    speechUtterance.onstart = () => {
        isPlaying = true;
        audioPlayBtn.textContent = '⏸';
        audioPlayBtn.classList.add('playing');
        audioStatus.textContent = 'Playing...';
    };
    
    speechUtterance.onend = () => {
        isPlaying = false;
        audioPlayBtn.textContent = '▶';
        audioPlayBtn.classList.remove('playing');
        audioStatus.textContent = 'Finished';
    };
    
    speechUtterance.onerror = (e) => {
        isPlaying = false;
        audioPlayBtn.textContent = '▶';
        audioPlayBtn.classList.remove('playing');
        audioStatus.textContent = 'Error occurred';
        console.error('Speech error:', e);
    };
    
    // Track progress
    let wordCount = audioScript.split(' ').length;
    speechUtterance.onboundary = (e) => {
        if (e.name === 'word') {
            const progress = Math.round((e.charIndex / audioScript.length) * 100);
            audioStatus.textContent = `Playing... ${progress}%`;
        }
    };
    
    window.speechSynthesis.speak(speechUtterance);
}

function stopAudio() {
    const audioPlayBtn = document.getElementById('audio-play-btn');
    const audioStatus = document.getElementById('audio-status');
    
    window.speechSynthesis.cancel();
    isPlaying = false;
    audioPlayBtn.textContent = '▶';
    audioPlayBtn.classList.remove('playing');
    audioStatus.textContent = 'Paused';
}

// Headlines quick listen
async function playHeadlines() {
    if (!('speechSynthesis' in window)) {
        showToast('Speech synthesis not supported', 'error');
        return;
    }
    
    try {
        const response = await api.audio.getHeadlines(5);
        
        if (response.success) {
            window.speechSynthesis.cancel();
            const utterance = new SpeechSynthesisUtterance(response.script);
            utterance.rate = parseFloat(document.getElementById('audio-speed')?.value || 1);
            window.speechSynthesis.speak(utterance);
            showToast('Playing headlines...');
        }
    } catch (error) {
        showToast(`Failed: ${error.message}`, 'error');
    }
}

// Load voices when available
if ('speechSynthesis' in window) {
    window.speechSynthesis.onvoiceschanged = () => {
        // Voices are now loaded
    };
}

// Expose functions
window.playHeadlines = playHeadlines;
window.stopAudio = stopAudio;
