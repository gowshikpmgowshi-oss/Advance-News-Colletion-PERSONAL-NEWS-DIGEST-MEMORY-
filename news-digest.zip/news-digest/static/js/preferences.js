/**
 * Preferences page logic
 */

document.addEventListener('DOMContentLoaded', () => {
    // Check authentication
    if (!isLoggedIn()) {
        window.location.href = '/';
        return;
    }
    
    // Display username
    const user = getUser();
    const usernameEl = document.getElementById('username');
    if (usernameEl && user) {
        usernameEl.textContent = user.username;
    }
    
    // Logout button
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', () => {
            api.auth.logout();
        });
    }
    
    // Load preferences
    loadPreferences();
    
    // Reset button
    const resetBtn = document.getElementById('reset-btn');
    if (resetBtn) {
        resetBtn.addEventListener('click', resetPreferences);
    }
    
    // Add custom feed form
    const addFeedForm = document.getElementById('add-feed-form');
    if (addFeedForm) {
        addFeedForm.addEventListener('submit', addCustomFeed);
    }
});

async function loadPreferences() {
    try {
        const prefs = await api.preferences.get();
        renderPreferences(prefs);
    } catch (error) {
        console.error('Error loading preferences:', error);
        showToast('Failed to load preferences', 'error');
    }
}

function renderPreferences(prefs) {
    // Liked topics
    renderTopicBars('liked-topics', prefs.liked_topics, false);
    
    // Dismissed topics
    renderTopicBars('dismissed-topics', prefs.dismissed_topics, true);
    
    // Source weights
    renderTopicBars('source-weights', prefs.source_weights, false);
    
    // Blocked sources
    renderBlockedSources(prefs.blocked_sources);
    
    // Custom feeds
    renderCustomFeeds(prefs.custom_feeds);
}

function renderTopicBars(containerId, data, isDismissed) {
    const container = document.getElementById(containerId);
    if (!container) return;
    
    const entries = Object.entries(data || {}).sort((a, b) => b[1] - a[1]);
    
    if (entries.length === 0) {
        container.innerHTML = '<p class="text-muted">No data yet. Interact with articles to build preferences.</p>';
        return;
    }
    
    const maxValue = Math.max(...entries.map(e => e[1]), 1);
    
    container.innerHTML = entries.map(([name, value]) => `
        <div class="preference-bar">
            <div class="preference-bar-label">
                <span>${name}</span>
                <span>${value.toFixed(2)}</span>
            </div>
            <div class="preference-bar-track">
                <div class="preference-bar-fill ${isDismissed ? 'dismissed' : ''}" 
                     style="width: ${(value / maxValue) * 100}%"></div>
            </div>
        </div>
    `).join('');
}

function renderBlockedSources(sources) {
    const container = document.getElementById('blocked-sources');
    if (!container) return;
    
    if (!sources || sources.length === 0) {
        container.innerHTML = '<p class="text-muted">No blocked sources.</p>';
        return;
    }
    
    container.innerHTML = sources.map(source => `
        <div class="blocked-source">
            <span>${source}</span>
            <button onclick="unblockSource('${source}')" title="Unblock">✕</button>
        </div>
    `).join('');
}

function renderCustomFeeds(feeds) {
    const container = document.getElementById('custom-feeds');
    if (!container) return;
    
    const entries = Object.entries(feeds || {});
    
    if (entries.length === 0) {
        container.innerHTML = '<p class="text-muted">No custom feeds added.</p>';
        return;
    }
    
    container.innerHTML = entries.map(([name, url]) => `
        <div class="blocked-source">
            <span title="${url}">${name}</span>
            <button onclick="removeCustomFeed('${name}')" title="Remove">✕</button>
        </div>
    `).join('');
}

async function unblockSource(source) {
    try {
        await api.preferences.unblockSource(source);
        showToast(`Unblocked ${source}`);
        loadPreferences();
    } catch (error) {
        console.error('Error unblocking source:', error);
        showToast('Failed to unblock source', 'error');
    }
}

async function resetPreferences() {
    if (!confirm('Are you sure you want to reset all preferences? This cannot be undone.')) {
        return;
    }
    
    try {
        await api.preferences.reset();
        showToast('Preferences reset to defaults');
        loadPreferences();
    } catch (error) {
        console.error('Error resetting preferences:', error);
        showToast('Failed to reset preferences', 'error');
    }
}

async function addCustomFeed(e) {
    e.preventDefault();
    
    const nameInput = document.getElementById('feed-name');
    const urlInput = document.getElementById('feed-url');
    
    const name = nameInput.value.trim();
    const url = urlInput.value.trim();
    
    if (!name || !url) {
        showToast('Please enter both name and URL', 'error');
        return;
    }
    
    try {
        await api.preferences.addCustomFeed(name, url);
        showToast(`Added feed: ${name}`);
        nameInput.value = '';
        urlInput.value = '';
        loadPreferences();
    } catch (error) {
        console.error('Error adding custom feed:', error);
        showToast('Failed to add feed', 'error');
    }
}

async function removeCustomFeed(name) {
    try {
        await api.preferences.removeCustomFeed(name);
        showToast(`Removed feed: ${name}`);
        loadPreferences();
    } catch (error) {
        console.error('Error removing feed:', error);
        showToast('Failed to remove feed', 'error');
    }
}

function showToast(message, type = 'success') {
    let container = document.querySelector('.toast-container');
    if (!container) {
        container = document.createElement('div');
        container.className = 'toast-container';
        document.body.appendChild(container);
    }
    
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    container.appendChild(toast);
    
    setTimeout(() => {
        toast.remove();
    }, 3000);
}

// Expose for onclick handlers
window.unblockSource = unblockSource;
window.removeCustomFeed = removeCustomFeed;
