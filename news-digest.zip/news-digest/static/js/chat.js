/**
 * Chat sidebar functionality
 */

let conversationHistory = [];
let isChatting = false;

document.addEventListener('DOMContentLoaded', () => {
    const chatFab = document.getElementById('chat-fab');
    const chatSidebar = document.getElementById('chat-sidebar');
    const chatClose = document.getElementById('chat-close');
    const chatInput = document.getElementById('chat-input');
    const chatSend = document.getElementById('chat-send');
    const chatMessages = document.getElementById('chat-messages');
    
    // Toggle chat sidebar
    if (chatFab) {
        chatFab.addEventListener('click', () => {
            chatSidebar.classList.add('open');
            chatInput.focus();
        });
    }
    
    if (chatClose) {
        chatClose.addEventListener('click', () => {
            chatSidebar.classList.remove('open');
        });
    }
    
    // Send message
    if (chatSend) {
        chatSend.addEventListener('click', sendChatMessage);
    }
    
    // Enter to send
    if (chatInput) {
        chatInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendChatMessage();
            }
        });
    }
});

async function sendChatMessage() {
    const chatInput = document.getElementById('chat-input');
    const chatMessages = document.getElementById('chat-messages');
    
    const message = chatInput.value.trim();
    if (!message || isChatting) return;
    
    // Add user message to UI
    addChatMessage('user', message);
    chatInput.value = '';
    
    // Show typing indicator
    const typingEl = document.createElement('div');
    typingEl.className = 'chat-message assistant';
    typingEl.id = 'typing-indicator';
    typingEl.innerHTML = '<span class="typing">Thinking...</span>';
    chatMessages.appendChild(typingEl);
    chatMessages.scrollTop = chatMessages.scrollHeight;
    
    isChatting = true;
    
    try {
        const response = await api.chat.send(message, conversationHistory);
        
        // Remove typing indicator
        document.getElementById('typing-indicator')?.remove();
        
        if (response.success) {
            addChatMessage('assistant', response.response);
            conversationHistory = response.conversation_history;
        } else {
            addChatMessage('assistant', 'Sorry, I encountered an error. Please try again.');
        }
    } catch (error) {
        document.getElementById('typing-indicator')?.remove();
        addChatMessage('assistant', `Error: ${error.message}`);
    }
    
    isChatting = false;
}

function addChatMessage(role, content) {
    const chatMessages = document.getElementById('chat-messages');
    const messageEl = document.createElement('div');
    messageEl.className = `chat-message ${role}`;
    
    // Parse markdown-like formatting
    let formatted = content
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
        .replace(/\*(.*?)\*/g, '<em>$1</em>')
        .replace(/`(.*?)`/g, '<code>$1</code>')
        .replace(/\n/g, '<br>');
    
    messageEl.innerHTML = formatted;
    chatMessages.appendChild(messageEl);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

// Quick questions shortcuts
function askQuestion(question) {
    const chatInput = document.getElementById('chat-input');
    const chatSidebar = document.getElementById('chat-sidebar');
    
    chatSidebar.classList.add('open');
    chatInput.value = question;
    sendChatMessage();
}

// Clear chat
function clearChat() {
    conversationHistory = [];
    const chatMessages = document.getElementById('chat-messages');
    chatMessages.innerHTML = `
        <div class="chat-message assistant">
            Hi! I'm your news assistant. Ask me anything about today's digest - I can explain articles, find connections, or discuss the news with you.
        </div>
    `;
    api.chat.clearHistory().catch(console.error);
}

// Expose functions
window.askQuestion = askQuestion;
window.clearChat = clearChat;
