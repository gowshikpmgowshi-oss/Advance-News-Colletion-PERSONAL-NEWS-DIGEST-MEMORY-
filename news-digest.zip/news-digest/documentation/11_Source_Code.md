# 11. Source Code

## 11.1 SequentialAgent Configuration

The root agent orchestrates the nine-stage news processing pipeline using ADK SequentialAgent.

```python
"""
Root News Digest Agent - Orchestrates the news digest generation workflow.
"""
from google.adk.agents import SequentialAgent

from .sub_agents import (
    news_fetcher_agent,
    summarizer_agent,
    topic_classifier_agent,
    personalizer_agent,
    sentiment_analyzer_agent,
    bias_analyzer_agent,
    related_finder_agent,
    breaking_detector_agent,
    tldr_generator_agent,
)

# Create the root agent as a SequentialAgent
# This runs sub-agents in order: fetch -> summarize -> tldr -> classify -> 
# sentiment -> bias -> breaking -> related -> personalize
root_agent = SequentialAgent(
    name="NewsDigestAgent",
    sub_agents=[
        news_fetcher_agent,
        summarizer_agent,
        tldr_generator_agent,
        topic_classifier_agent,
        sentiment_analyzer_agent,
        bias_analyzer_agent,
        breaking_detector_agent,
        related_finder_agent,
        personalizer_agent,
    ],
    description="Fetches news from RSS feeds, summarizes articles, analyzes "
                "sentiment/bias, detects breaking news, finds related articles, "
                "and personalizes based on user preferences.",
)
```

## 11.2 LlmAgent Sub-Agent Definition

Each sub-agent is an LlmAgent with specific instructions and output keys.

```python
"""
Summarizer Agent - Creates concise summaries for news articles.
"""
from google.adk.agents import LlmAgent

from ..config import config
from ..prompt import SUMMARIZER_INSTRUCTION

summarizer_agent = LlmAgent(
    name="SummarizerAgent",
    model=config.summarizer_model,
    description="Creates concise 2-3 sentence summaries for news articles.",
    instruction=SUMMARIZER_INSTRUCTION,
    output_key="summarized_articles",
)
```

## 11.3 Personalizer Agent with Tools

The personalizer agent uses function tools for relevance scoring.

```python
"""
Personalizer Agent - Ranks and filters articles based on user preferences.
"""
from google.adk.agents import LlmAgent
from google.adk.tools import FunctionTool

from ..config import config
from ..prompt import PERSONALIZER_INSTRUCTION
from ..tools import score_article, rank_articles

personalizer_agent = LlmAgent(
    name="PersonalizerAgent",
    model=config.main_model,
    description="Ranks and filters articles based on user preferences.",
    instruction=PERSONALIZER_INSTRUCTION,
    tools=[
        FunctionTool(func=score_article),
        FunctionTool(func=rank_articles),
    ],
    output_key="personalized_digest",
)
```

## 11.4 RSS Feed Aggregation Tool

The fetch tool aggregates articles from multiple RSS sources.

```python
def fetch_rss_feed(feed_url: str, source_name: str = "unknown") -> Dict[str, Any]:
    """
    Fetches and parses an RSS feed, returning articles.
    """
    try:
        feed = feedparser.parse(feed_url)
        
        if feed.bozo and not feed.entries:
            return {
                "status": "error",
                "message": f"Failed to parse feed: {feed.bozo_exception}",
                "articles": []
            }
        
        articles = []
        for entry in feed.entries[:20]:  # Limit to 20 per feed
            # Parse publication date
            published = None
            if hasattr(entry, 'published_parsed') and entry.published_parsed:
                published = datetime.fromtimestamp(mktime(entry.published_parsed))
            elif hasattr(entry, 'updated_parsed') and entry.updated_parsed:
                published = datetime.fromtimestamp(mktime(entry.updated_parsed))
            else:
                published = datetime.utcnow()
            
            # Generate article ID from URL
            article_id = hashlib.md5(entry.link.encode()).hexdigest()[:12]
            
            # Get description/summary
            description = ""
            if hasattr(entry, 'summary'):
                description = BeautifulSoup(entry.summary, 'html.parser').get_text()[:500]
            elif hasattr(entry, 'description'):
                description = BeautifulSoup(entry.description, 'html.parser').get_text()[:500]
            
            # Extract header image
            image_url = extract_image_from_entry(entry)
            
            articles.append({
                "id": article_id,
                "title": entry.title if hasattr(entry, 'title') else "Untitled",
                "link": entry.link if hasattr(entry, 'link') else "",
                "source": source_name,
                "published": published.isoformat() if published else None,
                "description": description.strip(),
                "image_url": image_url,
            })
        
        return {
            "status": "success",
            "source": source_name,
            "article_count": len(articles),
            "articles": articles
        }
        
    except Exception as e:
        return {"status": "error", "message": str(e), "articles": []}
```

## 11.5 Relevance Scoring Algorithm

The scoring function calculates article relevance based on user preferences.

```python
def score_article(
    article: Dict[str, Any],
    preferences: Dict[str, Any]
) -> Dict[str, Any]:
    """
    Calculates relevance score for an article based on user preferences.
    """
    liked_topics = preferences.get("liked_topics", {})
    dismissed_topics = preferences.get("dismissed_topics", {})
    source_weights = preferences.get("source_weights", {})
    blocked_sources = preferences.get("blocked_sources", [])
    
    # Check if source is blocked
    if article.get("source") in blocked_sources:
        article["relevance_score"] = -1
        article["is_blocked"] = True
        return article
    
    # Calculate base score
    score = 1.0
    
    # Add topic preferences
    article_topics = article.get("topics", [])
    for topic in article_topics:
        score += liked_topics.get(topic, 0)
        score -= dismissed_topics.get(topic, 0) * 1.5  # 1.5x penalty
    
    # Add source preference
    score += source_weights.get(article.get("source", ""), 0)
    
    article["relevance_score"] = round(score, 2)
    article["is_blocked"] = False
    return article
```

## 11.6 Preference Learning Service

The preference service records interactions and updates weights.

```python
async def record_interaction(
    self,
    user_id: str,
    article_id: str,
    action: str,
    article_title: str = "",
    article_topics: List[str] = None,
    article_source: str = "",
    time_spent_seconds: int = None
) -> Dict[str, Any]:
    """
    Record a user interaction and update preferences accordingly.
    This is the core of the preference learning algorithm.
    """
    db = self._get_db()
    
    if article_topics is None:
        article_topics = []
    
    # Create interaction record
    interaction = InteractionModel(
        user_id=user_id,
        article_id=article_id,
        action=action,
        article_title=article_title,
        article_topics=article_topics,
        article_source=article_source,
        time_spent_seconds=time_spent_seconds
    )
    
    await db.interactions.insert_one(interaction.to_dict())
    
    # Get current preferences
    preferences = await self.get_or_create_preferences(user_id)
    
    # Calculate weight adjustments based on action
    weights = INTERACTION_WEIGHTS.get(action, {})
    
    updates = {}
    
    # Update liked_topics
    if "liked_topics" in weights:
        delta = weights["liked_topics"]
        liked = dict(preferences.liked_topics)
        for topic in article_topics:
            liked[topic] = min(liked.get(topic, 0) + delta, 2.0)  # Cap at 2.0
        updates["liked_topics"] = liked
    
    # Update dismissed_topics
    if "dismissed_topics" in weights:
        delta = weights["dismissed_topics"]
        dismissed = dict(preferences.dismissed_topics)
        for topic in article_topics:
            dismissed[topic] = min(dismissed.get(topic, 0) + delta, 2.0)
        updates["dismissed_topics"] = dismissed
    
    # Update source_weights
    if "source_weights" in weights and article_source:
        delta = weights["source_weights"]
        sources = dict(preferences.source_weights)
        sources[article_source] = min(sources.get(article_source, 0) + delta, 2.0)
        updates["source_weights"] = sources
    
    # Apply updates
    if updates:
        await self.update_preferences(user_id, updates)
    
    return {
        "success": True,
        "action": action,
        "article_id": article_id,
        "preferences_updated": bool(updates)
    }
```

## 11.7 MongoDB Connection with AsyncMongoClient

The database module manages async MongoDB connections.

```python
"""
MongoDB connection using PyMongo async API.
"""
from typing import Optional
from pymongo import AsyncMongoClient
from pymongo.database import Database
from pymongo.errors import ServerSelectionTimeoutError, ConnectionFailure

from app.config import settings

_client: Optional[AsyncMongoClient] = None
_database: Optional[Database] = None


async def init_db() -> None:
    """Initialize the MongoDB connection."""
    global _client, _database
    
    try:
        _client = AsyncMongoClient(
            settings.mongodb_uri,
            serverSelectionTimeoutMS=5000
        )
        _database = _client[settings.mongodb_database]
        
        # Test the connection
        await _client.admin.command('ping')
        
        # Create indexes
        await _create_indexes()
        
        print(f"Connected to MongoDB: {settings.mongodb_database}")
    except (ServerSelectionTimeoutError, ConnectionFailure) as e:
        print(f"WARNING: Could not connect to MongoDB: {e}")
        _client = None
        _database = None


def get_database() -> Database:
    """Get the database instance."""
    if _database is None:
        raise RuntimeError(
            "Database not initialized. MongoDB connection failed."
        )
    return _database
```

## 11.8 Agent Prompt Instructions

The prompts define agent behavior and output formats.

```python
SUMMARIZER_INSTRUCTION = """You are a News Summarizer Agent that creates 
concise, readable summaries.

## Your Task

Take the articles from `{raw_articles}` and create a 2-3 sentence summary 
for each one.

## Guidelines

1. Keep summaries informative but brief (2-3 sentences max)
2. Capture the key facts: who, what, when, where, why
3. Use clear, accessible language
4. Avoid editorializing - stay factual
5. If the description already serves as a good summary, use it directly

## Output Format

Return the articles with an added `summary` field in the `summarized_articles` 
state key. Each article should have: title, link, source, published, summary
"""

SENTIMENT_ANALYZER_INSTRUCTION = """You are a Sentiment Analysis Agent that 
evaluates the emotional tone of news articles.

## Sentiment Categories

- **positive**: Uplifting, good news, achievements, progress
- **negative**: Tragic, concerning, failures, conflicts, disasters
- **neutral**: Factual reporting without strong emotional tone
- **mixed**: Contains both positive and negative elements

## Output Format

For each article, add:
- `sentiment`: One of "positive", "negative", "neutral", "mixed"
- `sentiment_score`: Float from -1.0 (very negative) to 1.0 (very positive)

Return articles in the `sentiment_analyzed` state key.
"""
```
