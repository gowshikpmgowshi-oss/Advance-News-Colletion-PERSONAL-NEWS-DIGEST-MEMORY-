# 12. Screenshots

## 12.1 Landing Page

![Landing Page](screenshots/landing-page.png)

The landing page welcomes users with a modern glassmorphism design featuring animated gradient backgrounds that shift between complementary colors. The authentication forms for login and registration are centered on the page with smooth transitions between modes, providing clear input validation feedback and password visibility toggles for user convenience.

## 12.2 User Registration

![User Registration](screenshots/registration.png)

The registration form collects essential user information including email address, username, and password with confirmation. Real-time validation highlights input errors before submission, and successful registration automatically transitions users to the dashboard with their first personalized digest.

## 12.3 User Login

![User Login](screenshots/login.png)

The login interface presents a streamlined form for returning users to enter their credentials. Failed authentication attempts display clear error messages without revealing which field was incorrect, and a "forgot password" link provides account recovery options for users who need assistance accessing their accounts.

## 12.4 Dashboard Overview

![Dashboard](screenshots/dashboard.png)

The dashboard serves as the central hub for news consumption, displaying the personalized digest in a responsive card grid layout. Each article card shows the headline, source badge, topic tags, relevance score indicator, and a TLDR summary, enabling users to quickly scan their digest and identify articles of interest.

## 12.5 Article Cards with Metadata

![Article Cards](screenshots/article-cards.png)

Article cards display comprehensive metadata including sentiment indicators (positive, negative, neutral, mixed) as colored badges, bias ratings with explanatory tooltips, and breaking news flags for time-sensitive stories. Action buttons for like, dismiss, and save appear on hover, allowing users to interact without leaving the digest view.

## 12.6 Breaking News Indicator

![Breaking News](screenshots/breaking-news.png)

Breaking news articles receive prominent visual treatment with a pulsing red badge and elevated card styling to draw immediate attention. The breaking score determines visibility priority, ensuring users see important developing stories first regardless of their personalization settings.

## 12.7 Topic Filter Controls

![Topic Filters](screenshots/topic-filters.png)

The filter bar above the digest allows users to quickly filter by topic category, source, or sentiment. Active filters highlight visually, and combining multiple filters creates intersection queries that narrow the displayed articles to specific user interests.

## 12.8 Article Viewer

![Article Viewer](screenshots/article-viewer.png)

The article viewer presents the full summary with all analysis metadata in an immersive reading layout. The header displays the headline, source, and publication date, while the main content area shows the AI-generated summary, sentiment analysis with score visualization, and bias assessment with explanation.

## 12.9 Related Articles Section

![Related Articles](screenshots/related-articles.png)

The related articles panel appears below the main article content, suggesting connected stories that share events, topics, or perspectives. Each related article thumbnail links directly to its viewer, encouraging deeper exploration of news topics.

## 12.10 Audio Player Interface

![Audio Player](screenshots/audio-player.png)

The audio synthesis interface provides text-to-speech playback of article summaries with standard media controls. Users can play, pause, and scrub through the audio, with playback speed adjustment for faster or slower listening according to preference.

## 12.11 Chat Interface

![Chat Interface](screenshots/chat-interface.png)

The conversational chat panel enables users to ask questions about the current article or explore related topics through natural language dialogue. The AI assistant responds with contextually relevant information, drawing from the article content and broader knowledge to provide insightful answers.

## 12.12 Explain Feature

![Explain Feature](screenshots/explain-feature.png)

The explain feature generates in-depth analysis of articles, providing historical context, implications, and background information that enhances understanding. The expanded explanation appears in a modal overlay with scrollable content for longer analyses.

## 12.13 Preferences Dashboard

![Preferences Dashboard](screenshots/preferences-dashboard.png)

The preferences page visualizes learned topic weights as progress bars showing relative interest levels across categories. The interface displays source preference weights, lists blocked sources with unblock buttons, and shows custom RSS feeds with management controls for adding or removing personalized sources.

## 12.14 Custom Feed Management

![Custom Feeds](screenshots/custom-feeds.png)

The custom feed management section allows users to add personalized RSS sources by entering a feed name and URL. Added feeds integrate with the standard aggregation pipeline, receiving the same AI processing as default sources and contributing to the personalized digest.

## 12.15 Blocked Sources List

![Blocked Sources](screenshots/blocked-sources.png)

The blocked sources display shows all sources the user has chosen to exclude from their digest. Each blocked source appears with an unblock button, and removing a source immediately restores it to future digest generation without requiring preference reset.

## 12.16 Theme Toggle

![Theme Toggle](screenshots/theme-toggle.png)

The theme toggle in the navigation bar allows users to switch between light and dark modes with instant visual feedback. The selected theme persists across sessions and applies consistently to all pages, with smooth transition animations between modes.

## 12.17 Mobile Responsive View

![Mobile View](screenshots/mobile-view.png)

The responsive design adapts the dashboard layout for mobile devices, stacking article cards vertically and collapsing the navigation into a hamburger menu. Touch-friendly button sizes and swipe gestures provide a native app-like experience on smartphones and tablets.

## 12.18 Digest Generation Progress

![Generation Progress](screenshots/generation-progress.png)

During digest generation, a progress indicator displays the current processing stage as articles flow through the nine-agent pipeline. Status updates show which agent is active (fetching, summarizing, analyzing, personalizing), giving users visibility into the AI processing that creates their personalized digest.
