# 9. Data Flow Diagram

## 9.1 Context Level DFD

```mermaid
flowchart LR
    A[User] --> B[News Digest]
    B --> C[User]
    C --> D[Preferences]

    E[RSS Sources] --> F[News Digest]
    F --> G[Gemini API]
    G --> H[Digest Output]
```

The context-level data flow diagram illustrates the News Digest system's primary external interactions. Users interact with the system through authentication requests, digest generation requests, article interactions, and preference management commands. The system responds with personalized news digests, article analyses, and preference confirmations. Externally, the system consumes news content from multiple RSS feed sources and utilizes the Google Gemini API for all AI processing tasks including summarization, classification, and analysis. The output flows back to users as fully processed, personalized digest content with comprehensive metadata.

## 9.2 User Authentication DFD

```mermaid
flowchart LR
    A[Credentials] --> B[Auth Route]
    B --> C[Validate]
    C --> D[MongoDB]

    E[Password] --> F[bcrypt Hash]
    F --> G[Compare]
    G --> H[JWT Token]
```

The authentication data flow begins with user credentials submitted to the auth route endpoint. The route delegates to the validation process, which queries MongoDB to retrieve the stored user document. The submitted password passes through bcrypt hashing and comparison against the stored hash. Upon successful validation, the system generates a JWT token containing the user identifier and expiration timestamp. The token returns to the user for inclusion in subsequent authenticated requests, establishing a stateless session mechanism.

## 9.3 Digest Generation DFD

```mermaid
flowchart LR
    A[Request] --> B[Agent Service]
    B --> C[SequentialAgent]
    C --> D[Sub-Agents]

    E[User Prefs] --> F[Personalizer]
    F --> G[Ranked Digest]
    G --> H[Response]
```

The digest generation flow initiates when a user requests a fresh news digest. The agent service receives the request and invokes the ADK SequentialAgent with initial state. The sequential agent orchestrates sub-agents through the nine-stage pipeline, each agent processing articles and adding metadata. User preferences load from the database and flow into the Personalizer agent, which calculates relevance scores and ranks articles. The ranked digest returns through the service layer and formats as the API response delivered to the user.

## 9.4 RSS Aggregation DFD

```mermaid
flowchart LR
    A[Feed URLs] --> B[Fetch Tool]
    B --> C[Parse XML]
    C --> D[Articles]

    E[Extract Data] --> F[Image Search]
    F --> G[Generate IDs]
    G --> H[Sort by Date]
```

The RSS aggregation flow begins with configured feed URLs passed to the fetch tool function. The tool requests XML content from each feed source and parses responses using feedparser. Article entries extract into structured data objects containing title, link, description, and publication date. The extraction process searches for images in media elements, enclosures, and HTML content. Each article receives a unique identifier generated from the URL hash. Finally, all aggregated articles sort by publication date with newest items first.

## 9.5 Summarization DFD

```mermaid
flowchart LR
    A[Raw Articles] --> B[Summarizer]
    B --> C[Gemini API]
    C --> D[Summaries]

    E[Article Text] --> F[Prompt Build]
    F --> G[LLM Process]
    G --> H[Summary Field]
```

The summarization data flow transforms raw articles into summarized content. Raw articles from the fetcher agent pass to the Summarizer agent, which constructs prompts with article text and summarization instructions. The prompts submit to the Gemini API for language model processing. The model generates concise two-to-three sentence summaries capturing key facts. Summaries attach to their respective articles as a new field, and the enhanced articles flow to subsequent agents in the pipeline.

## 9.6 Preference Learning DFD

```mermaid
flowchart LR
    A[User Action] --> B[Record Event]
    B --> C[Get Weights]
    C --> D[Apply Delta]

    E[Topic List] --> F[Update Each]
    F --> G[Cap at 2.0]
    G --> H[Save to DB]
```

The preference learning flow captures user interactions and updates preference weights incrementally. User actions (click, like, dismiss, save, read) record as interaction events with article metadata. The service retrieves current preference weights from the database. Weight deltas apply based on the action type configuration. For each topic in the article, the corresponding weight updates with the delta value. All weights cap at 2.0 to prevent excessive amplification. Updated preferences persist to MongoDB for use in future digest personalization.

## 9.7 Sentiment Analysis DFD

```mermaid
flowchart LR
    A[Articles] --> B[Sentiment Agent]
    B --> C[Gemini API]
    C --> D[Analysis]

    E[Content Text] --> F[Tone Eval]
    F --> G[Score Calc]
    G --> H[Add Fields]
```

The sentiment analysis flow evaluates the emotional tone of each article in the digest. Articles pass to the Sentiment Analyzer agent, which prepares content for evaluation. The agent sends article text to the Gemini API with sentiment analysis instructions. The model evaluates tone and returns classification (positive, negative, neutral, mixed) along with a numerical score from -1.0 to 1.0. The sentiment category and score attach to each article as new metadata fields, enriching the article for user display.

## 9.8 Personalization DFD

```mermaid
flowchart LR
    A[Articles] --> B[Personalizer]
    B --> C[Score Tool]
    C --> D[Relevance]

    E[User Prefs] --> F[Apply Weights]
    F --> G[Rank Sort]
    G --> H[Top Articles]
```

The personalization flow ranks articles based on individual user preferences. Classified and analyzed articles flow to the Personalizer agent along with the user's preference document. The score_article tool calculates relevance for each article by applying topic weights and source preferences. Liked topics increase scores while dismissed topics apply penalties. The rank_articles tool sorts articles by relevance score in descending order. The top-ranked articles comprise the personalized digest returned to the user.

## 9.9 Article Viewer DFD

```mermaid
flowchart LR
    A[Article ID] --> B[Fetch Article]
    B --> C[Load Analysis]
    C --> D[Display Data]

    E[User Request] --> F[Audio/Explain]
    F --> G[AI Process]
    G --> H[Rich Content]
```

The article viewer flow delivers detailed article content with extended functionality. When a user selects an article, the ID passes to the fetch endpoint which retrieves the article with all analysis metadata including summary, sentiment, bias, and related articles. The frontend displays the article data in the viewer template. Users can request additional processing such as audio synthesis of the summary or deep explanation of the article. These requests invoke additional AI processing that returns rich content enhancing the article experience.
