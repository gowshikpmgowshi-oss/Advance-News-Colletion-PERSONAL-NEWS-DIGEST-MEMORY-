# 4. Software Description

## 4.1 ADK SequentialAgent Architecture

The News Digest system employs Google's Agent Development Kit SequentialAgent pattern to orchestrate a nine-stage processing pipeline. Unlike parallel or loop-based agents, the SequentialAgent ensures each sub-agent completes before the next begins, with shared state propagating through the pipeline.

### Agent Pipeline Configuration

```python
root_agent = SequentialAgent(
    name="NewsDigestAgent",
    sub_agents=[
        news_fetcher_agent,      # Stage 1: Fetch RSS
        summarizer_agent,        # Stage 2: Summarize
        tldr_generator_agent,    # Stage 3: TLDR
        topic_classifier_agent,  # Stage 4: Classify
        sentiment_analyzer_agent,# Stage 5: Sentiment
        bias_analyzer_agent,     # Stage 6: Bias
        breaking_detector_agent, # Stage 7: Breaking
        related_finder_agent,    # Stage 8: Related
        personalizer_agent,      # Stage 9: Personalize
    ]
)
```

### State Flow Between Agents

| Stage | Input State Key | Output State Key |
|-------|-----------------|------------------|
| Fetch | (initial) | raw_articles |
| Summarize | raw_articles | summarized_articles |
| TLDR | summarized_articles | tldr_generated |
| Classify | summarized_articles | classified_articles |
| Sentiment | classified_articles | sentiment_analyzed |
| Bias | sentiment_analyzed | bias_analyzed |
| Breaking | bias_analyzed | breaking_detected |
| Related | breaking_detected | related_mapped |
| Personalize | classified_articles, user_preferences | personalized_digest |

## 4.2 Preference Learning Algorithm

The preference learning system implements incremental weight adjustment based on user interactions. Each interaction type carries predefined weight deltas that modify topic and source preferences.

### Interaction Weight Configuration

```python
INTERACTION_WEIGHTS = {
    "click":   {"liked_topics": 0.1, "source_weights": 0.05},
    "like":    {"liked_topics": 0.3, "source_weights": 0.2},
    "dismiss": {"dismissed_topics": 0.2},
    "save":    {"liked_topics": 0.5, "source_weights": 0.1},
    "read":    {"liked_topics": 0.15, "source_weights": 0.05},
}
```

### Weight Update Formula

For each interaction on article `A` with topics `[t1, t2, ...]` and source `S`:

**Liked Topics Update:**
```
liked_topics[ti] = min(liked_topics[ti] + delta, 2.0)
```

**Dismissed Topics Update:**
```
dismissed_topics[ti] = min(dismissed_topics[ti] + delta, 2.0)
```

**Source Weight Update:**
```
source_weights[S] = min(source_weights[S] + delta, 2.0)
```

All weights are capped at 2.0 to prevent runaway preference amplification.

## 4.3 Relevance Scoring Algorithm

The relevance scoring algorithm calculates a composite score for each article based on user preferences.

### Scoring Formula

```
relevance_score = base_score + topic_bonus - dismissal_penalty + source_bonus

Where:
- base_score = 1.0
- topic_bonus = Σ(liked_topics[ti]) for ti in article.topics
- dismissal_penalty = Σ(dismissed_topics[ti] * 1.5) for ti in article.topics
- source_bonus = source_weights[article.source]
```

### Filtering and Ranking

```python
def score_article(article, preferences):
    # Check blocked sources
    if article["source"] in preferences["blocked_sources"]:
        return {"relevance_score": -1, "is_blocked": True}
    
    # Calculate base score
    score = 1.0
    
    # Apply topic preferences
    for topic in article.get("topics", []):
        score += preferences["liked_topics"].get(topic, 0)
        score -= preferences["dismissed_topics"].get(topic, 0) * 1.5
    
    # Apply source preference
    score += preferences["source_weights"].get(article["source"], 0)
    
    return {"relevance_score": round(score, 2), "is_blocked": False}
```

## 4.4 RSS Feed Aggregation

The news fetching system aggregates content from multiple RSS sources with robust parsing and error handling.

### Feed Parsing Pipeline

1. **Fetch**: Request RSS XML from feed URL
2. **Parse**: Use feedparser to extract entries
3. **Extract Metadata**: Title, link, description, publication date
4. **Extract Images**: Check media:content, media:thumbnail, enclosures, and HTML content
5. **Generate ID**: MD5 hash of article URL truncated to 12 characters
6. **Clean Content**: Strip HTML tags from descriptions
7. **Sort**: Order by publication date (newest first)

### Image Extraction Priority

```
1. media:content (Media RSS standard)
2. media:thumbnail
3. enclosure with image MIME type
4. links with image MIME type
5. First <img> tag in content/summary HTML
```

## 4.5 Sentiment Analysis Model

The sentiment analyzer evaluates emotional tone across a four-category classification:

| Category | Score Range | Description |
|----------|-------------|-------------|
| Positive | +0.5 to +1.0 | Uplifting, achievements, progress |
| Neutral | -0.3 to +0.3 | Factual reporting without emotional tone |
| Negative | -1.0 to -0.5 | Tragic, concerning, conflicts |
| Mixed | Variable | Contains both positive and negative elements |

## 4.6 Bias Detection Categories

The bias analyzer classifies articles on a political spectrum:

| Category | Description |
|----------|-------------|
| left | Progressive/liberal slant |
| center-left | Slightly progressive leaning |
| center | Balanced, neutral reporting |
| center-right | Slightly conservative leaning |
| right | Conservative slant |
| factual | Pure fact-based reporting |

The analyzer considers both source reputation and specific article content, looking for loaded language, omissions, and framing choices.

## 4.7 Breaking News Detection

The breaking detector evaluates articles on five criteria:

| Criterion | Weight | Description |
|-----------|--------|-------------|
| Recency | High | Published within hours |
| Impact | High | Affects many people |
| Urgency | Medium | Time-sensitive information |
| Novelty | Medium | First reports of major events |
| Keywords | Low | Contains "breaking", "urgent", etc. |

Articles scoring 0.7 or higher on the combined scale (0.0 to 1.0) receive breaking news designation.

## 4.8 JWT Authentication Flow

The authentication system implements stateless token-based security:

### Token Generation

```python
def create_access_token(user_id: str) -> str:
    payload = {
        "sub": user_id,
        "exp": datetime.utcnow() + timedelta(hours=24),
        "iat": datetime.utcnow()
    }
    return jwt.encode(payload, SECRET_KEY, algorithm="HS256")
```

### Token Validation

Protected routes extract and validate the Bearer token:
1. Extract token from Authorization header
2. Decode with secret key and algorithm
3. Verify expiration timestamp
4. Extract user_id from subject claim
5. Return authenticated user context

## 4.9 MongoDB Index Strategy

The database layer creates indexes for optimal query performance:

| Collection | Index Fields | Type |
|------------|--------------|------|
| users | email | Unique |
| users | username | Unique |
| preferences | user_id | Unique |
| articles | source | Standard |
| articles | published (desc) | Standard |
| articles | topics | Standard |
| interactions | user_id | Standard |
| interactions | user_id + created_at (desc) | Compound |
| interactions | article_id | Standard |
| digests | user_id | Standard |
| digests | user_id + date (desc) | Compound |
| digests | user_id + date | Unique |
