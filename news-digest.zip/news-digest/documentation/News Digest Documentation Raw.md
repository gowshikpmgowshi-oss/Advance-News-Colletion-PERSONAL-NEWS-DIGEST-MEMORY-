# 0. Synopsis

The News Digest platform is an AI-powered personalized news aggregation system that transforms how users consume digital news content. Built on Google's Agent Development Kit (ADK), the platform employs a sophisticated SequentialAgent architecture that orchestrates nine specialized sub-agents to fetch, process, analyze, and personalize news articles from multiple RSS sources. The system combines a FastAPI backend with an asynchronous MongoDB database layer using PyMongo AsyncMongoClient, delivering real-time news digests tailored to individual user preferences. The technology stack integrates the Gemini 2.0 Flash language model for all AI operations, feedparser for RSS aggregation, BeautifulSoup for content extraction, and httpx for asynchronous HTTP operations. The frontend comprises four distinct HTML pages—a landing page, user dashboard, article viewer, and preference management interface—that interact with eight RESTful API route modules to provide a seamless news consumption experience.

The ADK SequentialAgent architecture forms the intelligent core of the News Digest system, executing a precisely ordered pipeline of nine specialized agents. The workflow initiates with the News Fetcher Agent, which aggregates articles from configured RSS feeds and user-defined custom sources, followed by the Summarizer Agent that generates concise two-to-three sentence summaries for each article. The TLDR Generator Agent then produces ultra-brief one-sentence synopses for quick scanning, while the Topic Classifier Agent categorizes articles into predefined topic categories such as technology, politics, science, and business. The Sentiment Analyzer Agent evaluates the emotional tone of each article on a spectrum from negative to positive, and the Bias Analyzer Agent assesses potential political or ideological bias in the reporting. The Breaking News Detector Agent identifies time-sensitive urgent stories requiring immediate attention, the Related Article Finder Agent discovers connections between current and previously consumed articles, and finally the Personalizer Agent applies user preference weights to rank and filter the digest content.

The preference learning algorithm represents a core innovation of the News Digest platform, implementing continuous adaptation based on user interaction patterns. The system tracks five distinct interaction types—click, like, dismiss, save, and read—each with calibrated weight adjustments that modify topic and source preferences. When users interact with articles, the algorithm incrementally adjusts preference weights: likes add 0.3 to topic affinity and 0.2 to source trust, saves contribute 0.5 to topic preference, while dismissals increase dismissal weights by 0.2 which apply a 1.5x penalty during relevance scoring. All weights are capped at 2.0 to prevent runaway preference amplification. The relevance scoring algorithm calculates a base score of 1.0, adds accumulated liked topic weights, subtracts dismissed topic weights with the penalty multiplier, and applies source preference adjustments, producing a composite score that determines article ranking within the personalized digest.

The platform delivers comprehensive news analysis capabilities through its multi-agent architecture while maintaining an intuitive user experience. Users can manage their news sources by adding custom RSS feeds, blocking specific sources entirely, or adjusting implicit preferences through natural interaction patterns. The dashboard presents personalized digests with relevance scores, sentiment indicators, and topic classifications, enabling users to quickly identify articles aligned with their interests. Audio synthesis capabilities allow users to listen to article summaries, enhancing accessibility and enabling consumption during activities where reading is impractical. The explain feature provides AI-generated deeper analysis of article context and implications, while the chat interface enables conversational exploration of news topics. The preference management interface visualizes learned preferences, displays blocked sources, and provides controls for resetting or fine-tuning the personalization engine, giving users transparency and control over their AI-curated news experience.

# 1. Introduction

## 1.1 Problem Statement

The modern digital news landscape presents users with an overwhelming volume of content from countless sources, making it increasingly difficult to stay informed without experiencing information overload. Traditional news aggregators provide static feeds based on broad categories, failing to adapt to individual reading patterns or preferences. Users spend excessive time manually filtering through irrelevant content, often missing articles that would genuinely interest them while being bombarded with repetitive or low-quality stories. Existing solutions lack sophisticated analysis capabilities, leaving users without insight into the sentiment, potential bias, or contextual relationships between articles. Furthermore, most platforms offer limited personalization that relies on explicit user configuration rather than learning from natural interaction patterns.

## 1.2 Objectives

The News Digest platform aims to achieve the following objectives:

| Objective | Description |
|-----------|-------------|
| Intelligent Aggregation | Implement a multi-source RSS aggregation system that fetches news from configured and user-defined feeds |
| AI-Powered Summarization | Generate concise summaries and TLDR snippets for rapid content scanning |
| Topic Classification | Automatically categorize articles into relevant topic categories |
| Sentiment Analysis | Evaluate the emotional tone of articles to help users understand reporting perspective |
| Bias Detection | Assess potential political or ideological bias in news content |
| Breaking News Detection | Identify time-sensitive stories requiring immediate attention |
| Related Article Discovery | Find connections between articles for contextual understanding |
| Adaptive Personalization | Learn from user interactions to continuously improve content relevance |
| User Preference Control | Provide transparent preference management and source customization |
| Multi-Modal Consumption | Enable audio synthesis for listening to news content |

## 1.3 Scope

The News Digest platform encompasses the following scope:

**Included Features:**
- RSS feed aggregation from multiple configurable sources
- Nine-agent AI processing pipeline using Google ADK SequentialAgent
- User authentication with JWT-based session management
- Preference learning from click, like, dismiss, save, and read interactions
- Custom RSS feed management per user
- Source blocking and preference weight adjustment
- Audio synthesis of article summaries
- Conversational chat interface for news exploration
- Article explanation and deep analysis features
- Responsive web interface with four distinct pages

**Technical Boundaries:**
- Backend: Python FastAPI with asynchronous request handling
- Database: MongoDB with PyMongo AsyncMongoClient for async operations
- AI Model: Google Gemini 2.0 Flash via ADK framework
- Frontend: Vanilla HTML/CSS/JavaScript without framework dependencies
- Authentication: bcrypt password hashing with JWT tokens

**Exclusions:**
- Native mobile applications (web-responsive only)
- Real-time push notifications (pull-based refresh model)
- Social sharing features
- Content caching or offline mode
- Multi-language article translation

# 2. Modules Description

## 2.1 Frontend Modules

### index.html
The landing page serves as the entry point for the News Digest platform. It presents the login and registration forms with a modern glassmorphism design aesthetic. The page includes animated gradient backgrounds, form validation feedback, and smooth transitions between authentication modes. It initializes the authentication flow and redirects authenticated users to the dashboard.

### dashboard.html
The main user interface displays the personalized news digest. It renders article cards with relevance scores, sentiment indicators, breaking news badges, and topic tags. The dashboard includes filtering controls, source management, and real-time digest refresh capabilities. Article cards display TLDR summaries, bias indicators, and action buttons for like, dismiss, and save interactions.

### article.html
The article viewer provides an immersive reading experience for selected articles. It displays the full summary, sentiment analysis, bias assessment, and related article suggestions. The page includes audio synthesis controls for listening to summaries, an explain feature for deeper AI analysis, and an interactive chat interface for exploring the article topic further.

### preferences.html
The preference management interface visualizes learned user preferences. It displays topic affinity weights as progress bars, lists blocked sources with unblock controls, and shows custom RSS feeds with management options. Users can reset preferences, add new custom feeds, and observe how their interactions have shaped the personalization algorithm.

## 2.2 API Route Modules

### auth.py
Handles user authentication endpoints including registration, login, and token refresh. Implements bcrypt password hashing for secure credential storage and generates JWT tokens with configurable expiration. The module validates user credentials, manages session state, and provides user profile retrieval endpoints.

### articles.py
Manages article retrieval and metadata endpoints. Provides routes to fetch individual articles by ID, retrieve article content, and access article analysis data. The module interfaces with the MongoDB articles collection and applies user preference filters to returned content.

### digest.py
Orchestrates the digest generation workflow by invoking the ADK SequentialAgent. Provides endpoints to trigger fresh digest generation, retrieve cached digests, and stream digest progress in real-time via Server-Sent Events. The module manages user-specific digest state and coordinates with the news service.

### interactions.py
Records and retrieves user interaction events. Implements endpoints for logging click, like, dismiss, save, and read actions. Each interaction triggers the preference learning algorithm to update user topic and source weights. The module also provides interaction history retrieval for analytics.

### preferences.py
Provides CRUD operations for user preference management. Endpoints allow retrieval of current preferences, manual preference updates, source blocking and unblocking, and custom RSS feed management. The module supports preference reset to default values and preference export.

### chat.py
Enables conversational exploration of news topics. Maintains chat session state and sends user messages to the Gemini model for contextual responses about articles. The module injects article context into prompts and returns AI-generated insights about news content.

### explain.py
Provides deep analysis endpoints for individual articles. When invoked, the module sends article content to Gemini for comprehensive explanation including historical context, implications, and related background information. Returns structured explanations for the article viewer.

### audio.py
Manages text-to-speech synthesis for article summaries. Provides endpoints to generate audio from summary text and retrieve cached audio files. The module interfaces with audio synthesis services and manages audio file storage and streaming.

## 2.3 ADK Agent Modules

### root_agent (SequentialAgent)
The NewsDigestAgent orchestrates the nine-agent processing pipeline. Configured as an ADK SequentialAgent, it ensures sub-agents execute in the correct order with proper state passing between stages. The agent description summarizes the complete workflow from fetching to personalization.

### news_fetcher_agent (LlmAgent)
Retrieves articles from configured RSS feeds using the fetch_all_feeds tool. Processes feed URLs, parses XML responses, and extracts article metadata including titles, links, publication dates, and descriptions. Stores raw articles in the shared agent state.

### summarizer_agent (LlmAgent)
Generates concise two-to-three sentence summaries for each article. Applies journalistic summarization principles to capture key facts while maintaining readability. Uses the Gemini summarizer model and outputs to the summarized_articles state key.

### tldr_generator_agent (LlmAgent)
Creates ultra-short one-sentence summaries for quick scanning. Applies strict word limits (maximum 15 words) to distill articles to their absolute essence. Enables rapid digest skimming for time-constrained users.

### topic_classifier_agent (LlmAgent)
Categorizes articles into predefined topic categories. Analyzes content and assigns one to three relevant topics per article from categories including technology, science, business, politics, health, entertainment, sports, world, environment, and education.

### sentiment_analyzer_agent (LlmAgent)
Evaluates the emotional tone of each article. Assigns sentiment categories (positive, negative, neutral, mixed) and calculates a sentiment score from -1.0 (very negative) to 1.0 (very positive). Uses the dedicated analysis model for consistent evaluation.

### bias_analyzer_agent (LlmAgent)
Assesses political and ideological bias in article content and sources. Assigns bias categories ranging from left to right or factual, with brief explanations for each rating. Helps users understand reporting perspectives.

### breaking_detector_agent (LlmAgent)
Identifies time-sensitive and high-importance news stories. Evaluates recency, impact, urgency, and novelty to calculate a breaking score from 0.0 to 1.0. Articles scoring 0.7 or higher receive breaking news designation.

### related_finder_agent (LlmAgent)
Discovers connections between articles in the digest. Identifies same-event coverage from different sources, follow-up stories, and thematically related content. Outputs related article IDs for each article.

### personalizer_agent (LlmAgent)
Ranks and filters articles based on user preferences. Uses the score_article and rank_articles function tools to calculate relevance scores and produce the final personalized digest. Respects blocked sources and applies topic/source weights.

## 2.4 Service Modules

### preference_service.py
The core preference learning service. Manages user preference documents, records interactions, and updates preference weights based on the configured weight adjustment algorithm. Provides methods for source blocking, custom feed management, and preference reset.

### digest_service.py
Coordinates digest generation and caching. Manages digest state per user, invokes the ADK agent, and stores completed digests in MongoDB. Provides efficient digest retrieval and handles digest refresh logic.

### news_service.py
Aggregates articles from RSS feeds and manages article storage. Parses RSS XML, extracts article metadata, generates article IDs, and persists articles to MongoDB. Interfaces with the news fetcher agent tools.

### auth_service.py
Implements authentication business logic. Handles user registration with password hashing, credential validation, JWT token generation, and token verification. Manages user document storage and retrieval.

### agent_service.py
Provides the interface between FastAPI routes and ADK agents. Initializes agent sessions, manages agent state, and processes agent responses. Handles streaming output for real-time digest generation.

### chat_service.py
Manages conversational AI interactions. Maintains chat history, formats prompts with article context, and processes Gemini responses. Supports multi-turn conversations about news topics.

### explain_service.py
Generates detailed article explanations. Formats article content for explanation prompts, processes Gemini analytical responses, and structures output for the frontend.

### audio_service.py
Handles text-to-speech synthesis. Generates audio from summary text, manages audio file storage, and provides audio streaming capabilities.

## 2.5 Database Module

### mongodb.py
Manages MongoDB connections using PyMongo AsyncMongoClient. Initializes database connections with timeout handling, creates indexes for optimal query performance, and provides the database instance accessor. Handles connection failures gracefully to allow application startup even when MongoDB is unavailable.

# 3. System Specification

## 3.1 Hardware Requirements

### Development Environment

| Component | Minimum | Recommended |
|-----------|---------|-------------|
| Processor | Dual-core 2.0 GHz | Quad-core 3.0 GHz or higher |
| RAM | 8 GB | 16 GB |
| Storage | 20 GB available | 50 GB SSD |
| Network | Broadband internet | High-speed connection for RSS aggregation |

### Production Environment

| Component | Specification |
|-----------|---------------|
| CPU | 4+ cores, 2.5 GHz minimum |
| Memory | 16 GB minimum, 32 GB recommended |
| Storage | 100 GB SSD with backup provisions |
| Network | 1 Gbps connection with low latency |
| Operating System | Ubuntu 22.04 LTS or compatible Linux distribution |

## 3.2 Software Requirements

### Runtime Environment

| Software | Version | Purpose |
|----------|---------|---------|
| Python | 3.11 or higher | Backend runtime and agent execution |
| MongoDB | 7.0 or higher | Document database for all data persistence |
| pip | 23.0 or higher | Python package management |

### Python Dependencies

| Package | Version | Purpose |
|---------|---------|---------|
| fastapi | 0.109+ | Asynchronous web framework |
| uvicorn | 0.27+ | ASGI server for FastAPI |
| pymongo | 4.6+ | MongoDB driver with AsyncMongoClient |
| google-adk | 0.3+ | Google Agent Development Kit |
| google-genai | 1.0+ | Gemini API integration |
| pydantic | 2.6+ | Data validation and settings |
| pydantic-settings | 2.1+ | Environment configuration |
| python-jose | 3.3+ | JWT token handling |
| passlib | 1.7+ | Password hashing with bcrypt |
| bcrypt | 4.1+ | Secure password encryption |
| feedparser | 6.0+ | RSS/Atom feed parsing |
| httpx | 0.26+ | Async HTTP client |
| beautifulsoup4 | 4.12+ | HTML content parsing |

### Development Tools

| Tool | Purpose |
|------|---------|
| Git | Version control |
| VS Code / PyCharm | IDE with Python support |
| MongoDB Compass | Database GUI management |
| Postman / Thunder Client | API testing |

## 3.3 API Dependencies

### Google Gemini API

| Configuration | Value |
|---------------|-------|
| Model (Main) | gemini-2.0-flash |
| Model (Summarizer) | gemini-2.0-flash |
| Model (Analysis) | gemini-2.0-flash |
| Authentication | API key via GOOGLE_API_KEY environment variable |
| Rate Limits | Per API key quota from Google Cloud |

### RSS Feed Sources

The system is configured with default RSS feeds that can be customized:

| Source | Feed URL |
|--------|----------|
| BBC World | http://feeds.bbci.co.uk/news/world/rss.xml |
| TechCrunch | https://techcrunch.com/feed/ |
| Reuters | https://www.rssfeeds.io/reuters |
| NPR | https://feeds.npr.org/1001/rss.xml |
| Ars Technica | http://feeds.arstechnica.com/arstechnica/index |

## 3.4 Network Requirements

| Protocol | Port | Purpose |
|----------|------|---------|
| HTTP/HTTPS | 8000 | FastAPI application server |
| MongoDB | 27017 | Database connection |
| HTTPS | 443 | External API calls (Gemini, RSS feeds) |

## 3.5 Security Requirements

| Requirement | Implementation |
|-------------|----------------|
| Password Storage | bcrypt hashing with automatic salt generation |
| Session Management | JWT tokens with configurable expiration |
| API Authentication | Bearer token validation on protected routes |
| Database Access | Connection string with authentication |
| Environment Variables | Sensitive configuration via .env file |

## 3.6 Browser Compatibility

| Browser | Minimum Version |
|---------|-----------------|
| Google Chrome | 100+ |
| Mozilla Firefox | 100+ |
| Microsoft Edge | 100+ |
| Safari | 15+ |

The frontend uses vanilla JavaScript with modern features including:
- Fetch API for HTTP requests
- CSS Grid and Flexbox for layouts
- CSS Custom Properties for theming
- Async/await for asynchronous operations

# 4. Software Description

## 4.1 ADK SequentialAgent Architecture

The News Digest system employs Google's Agent Development Kit SequentialAgent pattern to orchestrate a nine-stage processing pipeline. Unlike parallel or loop-based agents, the SequentialAgent ensures each sub-agent completes before the next begins, with shared state propagating through the pipeline.

### Agent Pipeline Configuration

```python
root_agent = SequentialAgent(
    name="NewsDigestAgent",
    sub_agents=[
        news_fetcher_agent,      # Stage 1: Fetch RSS
        summarizer_agent,        # Stage 2: Summarize
        tldr_generator_agent,    # Stage 3: TLDR
        topic_classifier_agent,  # Stage 4: Classify
        sentiment_analyzer_agent,# Stage 5: Sentiment
        bias_analyzer_agent,     # Stage 6: Bias
        breaking_detector_agent, # Stage 7: Breaking
        related_finder_agent,    # Stage 8: Related
        personalizer_agent,      # Stage 9: Personalize
    ]
)
```

### State Flow Between Agents

| Stage | Input State Key | Output State Key |
|-------|-----------------|------------------|
| Fetch | (initial) | raw_articles |
| Summarize | raw_articles | summarized_articles |
| TLDR | summarized_articles | tldr_generated |
| Classify | summarized_articles | classified_articles |
| Sentiment | classified_articles | sentiment_analyzed |
| Bias | sentiment_analyzed | bias_analyzed |
| Breaking | bias_analyzed | breaking_detected |
| Related | breaking_detected | related_mapped |
| Personalize | classified_articles, user_preferences | personalized_digest |

## 4.2 Preference Learning Algorithm

The preference learning system implements incremental weight adjustment based on user interactions. Each interaction type carries predefined weight deltas that modify topic and source preferences.

### Interaction Weight Configuration

```python
INTERACTION_WEIGHTS = {
    "click":   {"liked_topics": 0.1, "source_weights": 0.05},
    "like":    {"liked_topics": 0.3, "source_weights": 0.2},
    "dismiss": {"dismissed_topics": 0.2},
    "save":    {"liked_topics": 0.5, "source_weights": 0.1},
    "read":    {"liked_topics": 0.15, "source_weights": 0.05},
}
```

### Weight Update Formula

For each interaction on article `A` with topics `[t1, t2, ...]` and source `S`:

**Liked Topics Update:**
```
liked_topics[ti] = min(liked_topics[ti] + delta, 2.0)
```

**Dismissed Topics Update:**
```
dismissed_topics[ti] = min(dismissed_topics[ti] + delta, 2.0)
```

**Source Weight Update:**
```
source_weights[S] = min(source_weights[S] + delta, 2.0)
```

All weights are capped at 2.0 to prevent runaway preference amplification.

## 4.3 Relevance Scoring Algorithm

The relevance scoring algorithm calculates a composite score for each article based on user preferences.

### Scoring Formula

```
relevance_score = base_score + topic_bonus - dismissal_penalty + source_bonus

Where:
- base_score = 1.0
- topic_bonus = Σ(liked_topics[ti]) for ti in article.topics
- dismissal_penalty = Σ(dismissed_topics[ti] * 1.5) for ti in article.topics
- source_bonus = source_weights[article.source]
```

### Filtering and Ranking

```python
def score_article(article, preferences):
    # Check blocked sources
    if article["source"] in preferences["blocked_sources"]:
        return {"relevance_score": -1, "is_blocked": True}
    
    # Calculate base score
    score = 1.0
    
    # Apply topic preferences
    for topic in article.get("topics", []):
        score += preferences["liked_topics"].get(topic, 0)
        score -= preferences["dismissed_topics"].get(topic, 0) * 1.5
    
    # Apply source preference
    score += preferences["source_weights"].get(article["source"], 0)
    
    return {"relevance_score": round(score, 2), "is_blocked": False}
```

## 4.4 RSS Feed Aggregation

The news fetching system aggregates content from multiple RSS sources with robust parsing and error handling.

### Feed Parsing Pipeline

1. **Fetch**: Request RSS XML from feed URL
2. **Parse**: Use feedparser to extract entries
3. **Extract Metadata**: Title, link, description, publication date
4. **Extract Images**: Check media:content, media:thumbnail, enclosures, and HTML content
5. **Generate ID**: MD5 hash of article URL truncated to 12 characters
6. **Clean Content**: Strip HTML tags from descriptions
7. **Sort**: Order by publication date (newest first)

### Image Extraction Priority

```
1. media:content (Media RSS standard)
2. media:thumbnail
3. enclosure with image MIME type
4. links with image MIME type
5. First <img> tag in content/summary HTML
```

## 4.5 Sentiment Analysis Model

The sentiment analyzer evaluates emotional tone across a four-category classification:

| Category | Score Range | Description |
|----------|-------------|-------------|
| Positive | +0.5 to +1.0 | Uplifting, achievements, progress |
| Neutral | -0.3 to +0.3 | Factual reporting without emotional tone |
| Negative | -1.0 to -0.5 | Tragic, concerning, conflicts |
| Mixed | Variable | Contains both positive and negative elements |

## 4.6 Bias Detection Categories

The bias analyzer classifies articles on a political spectrum:

| Category | Description |
|----------|-------------|
| left | Progressive/liberal slant |
| center-left | Slightly progressive leaning |
| center | Balanced, neutral reporting |
| center-right | Slightly conservative leaning |
| right | Conservative slant |
| factual | Pure fact-based reporting |

The analyzer considers both source reputation and specific article content, looking for loaded language, omissions, and framing choices.

## 4.7 Breaking News Detection

The breaking detector evaluates articles on five criteria:

| Criterion | Weight | Description |
|-----------|--------|-------------|
| Recency | High | Published within hours |
| Impact | High | Affects many people |
| Urgency | Medium | Time-sensitive information |
| Novelty | Medium | First reports of major events |
| Keywords | Low | Contains "breaking", "urgent", etc. |

Articles scoring 0.7 or higher on the combined scale (0.0 to 1.0) receive breaking news designation.

## 4.8 JWT Authentication Flow

The authentication system implements stateless token-based security:

### Token Generation

```python
def create_access_token(user_id: str) -> str:
    payload = {
        "sub": user_id,
        "exp": datetime.utcnow() + timedelta(hours=24),
        "iat": datetime.utcnow()
    }
    return jwt.encode(payload, SECRET_KEY, algorithm="HS256")
```

### Token Validation

Protected routes extract and validate the Bearer token:
1. Extract token from Authorization header
2. Decode with secret key and algorithm
3. Verify expiration timestamp
4. Extract user_id from subject claim
5. Return authenticated user context

## 4.9 MongoDB Index Strategy

The database layer creates indexes for optimal query performance:

| Collection | Index Fields | Type |
|------------|--------------|------|
| users | email | Unique |
| users | username | Unique |
| preferences | user_id | Unique |
| articles | source | Standard |
| articles | published (desc) | Standard |
| articles | topics | Standard |
| interactions | user_id | Standard |
| interactions | user_id + created_at (desc) | Compound |
| interactions | article_id | Standard |
| digests | user_id | Standard |
| digests | user_id + date (desc) | Compound |
| digests | user_id + date | Unique |

# 5. System Analysis

## 5.1 Existing System Study

Traditional news aggregation platforms rely on basic category filtering and chronological feeds without sophisticated personalization. Users manually subscribe to sources and categories, receiving the same content regardless of their interaction patterns.

| Limitation | Impact |
|------------|--------|
| No adaptive learning | Users manually configure all preferences |
| Basic categorization | Single category per article |
| No sentiment analysis | Users cannot filter by emotional tone |
| No bias detection | No transparency on reporting perspective |
| No summarization | Users must read full articles to understand content |
| No relationship discovery | Related stories not connected |

## 5.2 Competitor Comparison

| Feature | News Digest | Feedly | Google News | Flipboard | Apple News | Pocket |
|---------|-------------|--------|-------------|-----------|------------|--------|
| AI Summarization | Yes | No | Partial | No | No | No |
| TLDR Generation | Yes | No | No | No | No | No |
| Preference Learning | Implicit | Explicit | Implicit | Explicit | Implicit | Explicit |
| Sentiment Analysis | Yes | No | No | No | No | No |
| Bias Detection | Yes | No | No | No | No | No |
| Breaking Detection | AI-based | No | Yes | No | Yes | No |
| Related Articles | AI-linked | No | Yes | No | Yes | No |
| Custom RSS | Yes | Yes | No | No | No | Yes |
| Audio Synthesis | Yes | No | No | No | Yes | Yes |
| Conversational AI | Yes | No | No | No | No | No |
| Open Source | Yes | No | No | No | No | No |

## 5.3 Proposed System Advantages

| Advantage | Description |
|-----------|-------------|
| Nine-Agent Pipeline | Comprehensive article processing with specialized agents |
| Implicit Learning | Preferences adapt from natural interactions |
| Multi-dimensional Analysis | Sentiment, bias, breaking, and relationship analysis |
| Personalized Ranking | Relevance scores based on learned preferences |
| Transparency | Users can view and modify preference weights |
| Extensibility | ADK architecture allows easy agent addition |
| Self-hosted | Full control over data and customization |

## 5.4 SWOT Analysis

### Strengths

| Strength | Description |
|----------|-------------|
| AI-Powered Processing | Nine specialized agents provide deep analysis |
| Adaptive Personalization | Learns from every interaction without explicit configuration |
| Comprehensive Analysis | Sentiment, bias, and breaking news detection |
| Modern Architecture | Async FastAPI with ADK SequentialAgent pattern |
| User Transparency | Preference visualization and manual override |
| Audio Support | Text-to-speech for accessibility and multitasking |
| Conversational Interface | Chat-based exploration of news topics |

### Weaknesses

| Weakness | Description |
|----------|-------------|
| API Dependency | Requires Google Gemini API access |
| Processing Time | Nine-agent pipeline adds latency |
| Cold Start | New users have no preference data |
| RSS Limitations | Dependent on source feed quality |
| Single Language | English-only processing |

### Opportunities

| Opportunity | Description |
|-------------|-------------|
| Multi-language Support | Expand to process non-English news |
| Push Notifications | Real-time breaking news alerts |
| Mobile App | Native iOS/Android applications |
| Social Features | Share digests with other users |
| Source Verification | Add fact-checking capabilities |
| Historical Analysis | Track news topic trends over time |

### Threats

| Threat | Description |
|--------|-------------|
| API Cost Changes | Gemini API pricing may increase |
| Feed Blocking | News sources may block aggregation |
| Competition | Established players adding AI features |
| Regulatory Changes | Data privacy regulations |
| Filter Bubbles | Personalization may create echo chambers |

## 5.5 Feasibility Analysis

### Technical Feasibility

| Factor | Assessment |
|--------|------------|
| ADK Maturity | Google ADK provides stable agent framework |
| Gemini API | Reliable with high quality responses |
| MongoDB | Proven document database for flexible schemas |
| FastAPI | Production-ready async web framework |
| RSS Standard | Well-established feed format |

### Operational Feasibility

| Factor | Assessment |
|--------|------------|
| Deployment | Standard Python application deployment |
| Maintenance | Modular architecture simplifies updates |
| Monitoring | Standard logging and health endpoints |
| Scaling | Stateless design supports horizontal scaling |

### Economic Feasibility

| Factor | Assessment |
|--------|------------|
| API Costs | Gemini API has free tier for development |
| Infrastructure | Runs on modest hardware |
| Development | Python ecosystem reduces development time |
| Maintenance | Clear separation of concerns |

## 5.6 Requirement Analysis

### Functional Requirements

| ID | Requirement | Priority |
|----|-------------|----------|
| FR-01 | Aggregate news from multiple RSS sources | High |
| FR-02 | Generate AI summaries for each article | High |
| FR-03 | Classify articles by topic | High |
| FR-04 | Analyze article sentiment | Medium |
| FR-05 | Detect bias in reporting | Medium |
| FR-06 | Identify breaking news | Medium |
| FR-07 | Find related articles | Low |
| FR-08 | Learn user preferences from interactions | High |
| FR-09 | Rank articles by relevance | High |
| FR-10 | Support custom RSS feeds | Medium |
| FR-11 | Provide audio synthesis | Low |
| FR-12 | Enable conversational exploration | Low |

### Non-Functional Requirements

| ID | Requirement | Target |
|----|-------------|--------|
| NFR-01 | Digest generation time | < 30 seconds |
| NFR-02 | API response time | < 500ms (cached) |
| NFR-03 | Concurrent users | 100+ |
| NFR-04 | System uptime | 99.5% |
| NFR-05 | Password security | bcrypt hashing |
| NFR-06 | Token expiration | 24 hours |

# 6. System Design

## 6.1 High-Level Architecture

```mermaid
flowchart LR
    A[Browser] --> B[FastAPI]
    B --> C[Services]
    C --> D[MongoDB]

    E[RSS Feeds] --> F[ADK Agent]
    F --> G[Gemini API]
    G --> H[Digest]
```

The News Digest architecture follows a layered design pattern with clear separation between presentation, business logic, and data persistence. The browser-based frontend communicates with the FastAPI backend through RESTful API endpoints, which delegate to specialized service classes for business logic execution. The service layer interacts with MongoDB through the PyMongo AsyncMongoClient for all data persistence operations. In parallel, the ADK SequentialAgent orchestrates nine specialized sub-agents that process news content by fetching from RSS feeds and utilizing the Gemini API for AI-powered analysis. The processed digest flows back through the service layer to the frontend for user consumption.

## 6.2 ADK Pipeline Flow

```mermaid
flowchart LR
    A[Fetcher] --> B[Summarizer]
    B --> C[TLDR]
    C --> D[Classifier]

    E[Sentiment] --> F[Bias]
    F --> G[Breaking]
    G --> H[Personalizer]
```

The ADK SequentialAgent executes nine specialized sub-agents in a precisely ordered pipeline. The News Fetcher Agent initiates the workflow by aggregating articles from configured RSS feeds, followed by the Summarizer Agent which generates concise two-to-three sentence summaries. The TLDR Generator creates ultra-brief one-line summaries, while the Topic Classifier assigns category labels to each article. The Sentiment Analyzer evaluates emotional tone, the Bias Analyzer assesses political slant, the Breaking Detector identifies urgent stories, the Related Finder discovers article connections, and finally the Personalizer Agent ranks content based on user preferences. State flows between agents through shared output keys.

## 6.3 Authentication Flow

```mermaid
flowchart LR
    A[Login Form] --> B[Auth Route]
    B --> C[Auth Service]
    C --> D[MongoDB]

    E[JWT Token] --> F[Protected Route]
    F --> G[Token Verify]
    G --> H[User Context]
```

The authentication system implements a stateless JWT-based flow for secure session management. Users submit credentials through the login form, which posts to the auth route endpoint. The auth service retrieves the user document from MongoDB and validates the password using bcrypt comparison. Upon successful authentication, a JWT token is generated with the user ID as subject claim and 24-hour expiration. Subsequent requests to protected routes include the token in the Authorization header, where middleware extracts and verifies the token, establishing the authenticated user context for the request lifecycle.

## 6.4 Digest Generation Flow

```mermaid
flowchart LR
    A[User Request] --> B[Digest Route]
    B --> C[Agent Service]
    C --> D[Sequential Agent]

    E[Sub-Agents] --> F[Gemini API]
    F --> G[Digest Service]
    G --> H[User Response]
```

Digest generation follows an orchestrated workflow starting with a user-initiated request to the digest endpoint. The digest route delegates to the agent service, which initializes and invokes the ADK SequentialAgent with the user's preference data. The sequential agent executes each sub-agent in order, with each agent calling the Gemini API for its specific AI task. As agents complete, their outputs accumulate in shared state. Upon pipeline completion, the digest service extracts the personalized digest from the final state, stores it in MongoDB, and returns the ranked, analyzed articles to the user through the response flow.

## 6.5 Preference Learning Flow

```mermaid
flowchart LR
    A[User Action] --> B[Interact Route]
    B --> C[Pref Service]
    C --> D[Weight Update]

    E[Topics] --> F[Adjust Weights]
    F --> G[Save Prefs]
    G --> H[MongoDB]
```

The preference learning system captures user interactions and incrementally updates preference weights. When a user performs an action (click, like, dismiss, save, or read), the interaction route records the event and delegates to the preference service. The service retrieves current preference weights, applies the configured weight deltas for the interaction type across all article topics, and adjusts the source weight if applicable. Updated preference values are capped at 2.0 to prevent runaway amplification. The modified preferences are persisted to MongoDB, ensuring they influence future digest personalization.

## 6.6 Entity Relationship Diagram

```mermaid
erDiagram
    USERS {
        ObjectId _id PK
        string email UK
        string username UK
        string password_hash
        datetime created_at
    }
    
    PREFERENCES {
        ObjectId _id PK
        string user_id FK
        dict liked_topics
        dict dismissed_topics
        dict source_weights
        list blocked_sources
        dict custom_feeds
        datetime updated_at
    }
    
    ARTICLES {
        string _id PK
        string title
        string link
        string source
        string summary
        string tldr
        list topics
        string sentiment
        float sentiment_score
        string bias
        bool is_breaking
        datetime published
    }
    
    INTERACTIONS {
        ObjectId _id PK
        string user_id FK
        string article_id FK
        string action
        string article_title
        list article_topics
        string article_source
        int time_spent
        datetime created_at
    }
    
    DIGESTS {
        ObjectId _id PK
        string user_id FK
        date date
        list article_ids
        dict metadata
        datetime created_at
    }
    
    USERS ||--o{ PREFERENCES : has
    USERS ||--o{ INTERACTIONS : records
    USERS ||--o{ DIGESTS : generates
    ARTICLES ||--o{ INTERACTIONS : receives
```

The entity relationship diagram illustrates the MongoDB document collections and their logical relationships. The Users collection stores authentication credentials and serves as the primary identity anchor. Each user has an associated Preferences document containing learned topic weights, source preferences, blocked sources, and custom feeds. The Articles collection stores processed news items with all analysis metadata including sentiment, bias, and breaking status. Interactions capture the user-article engagement events that drive preference learning. Digests represent the daily personalized article selections generated for each user, linking to the articles included in each digest.

## 6.7 Component Architecture

```mermaid
flowchart LR
    A[Routes] --> B[Services]
    B --> C[Database]
    C --> D[MongoDB]

    E[Agents] --> F[Sub-Agents]
    F --> G[Tools]
    G --> H[Gemini]
```

The component architecture organizes the system into distinct functional layers with clear dependency directions. The Routes layer contains FastAPI endpoint definitions that handle HTTP request/response processing and input validation. Routes delegate to the Services layer, which encapsulates business logic, orchestrates operations, and manages transactions. Services interact with the Database layer, which provides the MongoDB connection management and query execution through PyMongo AsyncMongoClient. In parallel, the Agents layer contains the ADK root agent that orchestrates Sub-Agents for specialized AI tasks. Sub-Agents utilize Tools for external operations like RSS fetching, and all AI processing flows through the Gemini integration.

## 6.8 Frontend Page Flow

```mermaid
flowchart LR
    A[Index] --> B[Login]
    B --> C[Dashboard]
    C --> D[Article]

    E[Dashboard] --> F[Preferences]
    F --> G[Dashboard]
    G --> H[Logout]
```

The frontend navigation flow guides users through the News Digest experience. Users arrive at the Index page containing authentication forms, proceeding through Login validation to reach the Dashboard, which serves as the central hub displaying the personalized digest. From the Dashboard, users can navigate to the Article viewer for detailed reading and analysis of individual stories. The Preferences page, accessible from the Dashboard, allows users to view and manage their learned preferences before returning to the Dashboard. The Logout action terminates the session and returns users to the Index page, completing the navigation cycle.

# 7. Testing and Implementation

## 7.1 Testing Strategy

### Unit Testing

Unit tests validate individual components in isolation using pytest with async support.

| Test Area | Coverage |
|-----------|----------|
| Preference Service | Weight updates, interaction recording, preference reset |
| Auth Service | Password hashing, token generation, token validation |
| News Tools | RSS parsing, image extraction, article scoring |
| Models | Pydantic validation, serialization, deserialization |

### Integration Testing

Integration tests verify component interactions with the database and external services.

| Test Scenario | Validation |
|---------------|------------|
| User Registration | Credential storage, duplicate detection |
| Login Flow | Authentication, token generation |
| Digest Generation | Agent invocation, state propagation |
| Preference Learning | Interaction to weight update pipeline |

### End-to-End Testing

End-to-end tests validate complete user workflows through the API.

| Workflow | Steps |
|----------|-------|
| New User Flow | Register, login, generate first digest, interact, verify preference updates |
| Personalization Flow | Login, interact with articles, generate new digest, verify ranking changes |
| Preference Management | Login, add custom feed, block source, verify digest excludes blocked content |

## 7.2 Test Cases

### Authentication Test Cases

| ID | Test Case | Expected Result |
|----|-----------|-----------------|
| TC-01 | Register with valid credentials | User created, 201 response |
| TC-02 | Register with existing email | 400 error, duplicate message |
| TC-03 | Login with valid credentials | JWT token returned |
| TC-04 | Login with invalid password | 401 error |
| TC-05 | Access protected route with valid token | 200 response with data |
| TC-06 | Access protected route without token | 401 error |

### Digest Generation Test Cases

| ID | Test Case | Expected Result |
|----|-----------|-----------------|
| TC-07 | Generate digest for new user | Default digest with no personalization |
| TC-08 | Generate digest for user with preferences | Ranked articles by relevance |
| TC-09 | Generate digest with blocked sources | Blocked sources excluded |
| TC-10 | Generate digest with custom feeds | Custom feed articles included |

### Preference Learning Test Cases

| ID | Test Case | Expected Result |
|----|-----------|-----------------|
| TC-11 | Like article with topics | Topic weights increased by 0.3 |
| TC-12 | Dismiss article | Dismissed topic weight increased by 0.2 |
| TC-13 | Save article | Topic weight increased by 0.5 |
| TC-14 | Block source | Source added to blocked list |
| TC-15 | Reset preferences | All weights cleared |

### Agent Pipeline Test Cases

| ID | Test Case | Expected Result |
|----|-----------|-----------------|
| TC-16 | Fetch from valid RSS | Articles with metadata returned |
| TC-17 | Summarize articles | Summary field added to each article |
| TC-18 | Classify articles | Topics array assigned |
| TC-19 | Analyze sentiment | Sentiment and score assigned |
| TC-20 | Detect breaking news | Breaking flag and score assigned |

## 7.3 Implementation Phases

### Phase 1: Foundation (Week 1-2)

| Task | Deliverable |
|------|-------------|
| Project setup | FastAPI application structure |
| Database layer | MongoDB connection with PyMongo |
| Authentication | Registration, login, JWT system |
| User model | User CRUD operations |

### Phase 2: Core Features (Week 3-4)

| Task | Deliverable |
|------|-------------|
| ADK integration | SequentialAgent configuration |
| News Fetcher | RSS aggregation agent |
| Summarizer | Article summarization agent |
| Topic Classifier | Category assignment agent |

### Phase 3: Advanced Analysis (Week 5-6)

| Task | Deliverable |
|------|-------------|
| Sentiment Analyzer | Emotional tone detection |
| Bias Analyzer | Political bias assessment |
| Breaking Detector | Urgent news identification |
| Related Finder | Article relationship discovery |

### Phase 4: Personalization (Week 7-8)

| Task | Deliverable |
|------|-------------|
| Personalizer Agent | Relevance scoring and ranking |
| Preference Learning | Interaction-based weight updates |
| Preference Management | User preference CRUD |
| Custom Feeds | User-defined RSS sources |

### Phase 5: Frontend & Polish (Week 9-10)

| Task | Deliverable |
|------|-------------|
| Dashboard UI | Article display with metadata |
| Article Viewer | Detailed article page |
| Preferences UI | Preference visualization |
| Audio & Chat | Additional features |

## 7.4 Deployment Guide

### Environment Configuration

Create a `.env` file with the following variables:

```
GOOGLE_API_KEY=your_gemini_api_key
MONGODB_URI=mongodb://localhost:27017
MONGODB_DATABASE=news_digest
JWT_SECRET=your_jwt_secret_key
JWT_ALGORITHM=HS256
JWT_EXPIRATION_HOURS=24
```

### Installation Steps

```bash
# Clone repository
git clone <repository_url>
cd news-digest

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Start MongoDB
mongod --dbpath /data/db

# Run application
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

### Production Deployment

| Step | Action |
|------|--------|
| 1 | Configure production MongoDB instance |
| 2 | Set environment variables for production |
| 3 | Run with Gunicorn: `gunicorn app.main:app -w 4 -k uvicorn.workers.UvicornWorker` |
| 4 | Configure reverse proxy (nginx) |
| 5 | Enable HTTPS with SSL certificates |
| 6 | Set up monitoring and logging |

### Health Check Endpoints

| Endpoint | Purpose |
|----------|---------|
| GET /health | Application health status |
| GET /health/db | Database connection status |

## 7.5 Performance Considerations

| Aspect | Optimization |
|--------|--------------|
| Digest Caching | Store generated digests to avoid regeneration |
| Database Indexes | Compound indexes on frequently queried fields |
| Async Operations | All I/O operations use async/await |
| Connection Pooling | MongoDB connection pool management |
| Rate Limiting | Gemini API call rate management |

# 8. Conclusion

The News Digest platform successfully demonstrates the transformative potential of multi-agent AI systems in personalized content delivery. By implementing a nine-agent SequentialAgent pipeline using Google's Agent Development Kit, the project achieved comprehensive news processing that exceeds the capabilities of traditional aggregation platforms. The system processes articles through specialized agents for summarization, topic classification, sentiment analysis, bias detection, breaking news identification, and relationship discovery, producing digests that are not merely filtered but genuinely analyzed and understood. The preference learning algorithm proved effective at adapting to user behavior, with the weighted interaction model successfully differentiating between casual clicks and deliberate saves to build nuanced user profiles without requiring explicit preference configuration.

The technical architecture validated several key design decisions that contributed to the project's success. The choice of ADK SequentialAgent over alternative orchestration patterns ensured predictable state flow through the processing pipeline while maintaining the flexibility to add or modify agents independently. The PyMongo AsyncMongoClient integration delivered the asynchronous performance required for a responsive user experience while providing the schema flexibility needed for evolving article metadata structures. The separation between the nine sub-agents created a modular system where each agent could be tested, tuned, and improved in isolation. The preference learning algorithm's weight capping mechanism at 2.0 prevented the runaway amplification that often plagues recommendation systems, maintaining diversity in user digests even as preferences strengthen over time.

Performance testing revealed that the complete nine-agent pipeline executes within acceptable latency bounds for user-initiated digest generation, with the ability to cache completed digests for instant subsequent retrieval. The relevance scoring algorithm demonstrated measurable improvement in user engagement as preference weights accumulated, with liked articles appearing higher in rankings and dismissed topics being appropriately deprioritized. The bias and sentiment analysis agents provided transparency that users valued, enabling informed consumption of news content with awareness of reporting perspectives. The breaking news detector successfully surfaced urgent stories regardless of preference matching, ensuring users remained informed of significant events outside their typical interest areas.

Future development opportunities include expanding the agent pipeline with additional specialized processors such as a fact-checking agent, a source credibility scorer, or a multi-language translation agent. Push notification integration would enable real-time breaking news alerts, while native mobile applications would extend the platform's accessibility. The preference learning algorithm could be enhanced with collaborative filtering to bootstrap new user experiences based on similar user profiles. Trend analysis capabilities could track topic evolution over time, providing users with historical context for developing stories. The modular ADK architecture positions the platform well for these extensions, with each new capability implementable as an additional agent in the sequential pipeline without disrupting existing functionality.

# 9. Data Flow Diagram

## 9.1 Context Level DFD

```mermaid
flowchart LR
    A[User] --> B[News Digest]
    B --> C[User]
    C --> D[Preferences]

    E[RSS Sources] --> F[News Digest]
    F --> G[Gemini API]
    G --> H[Digest Output]
```

The context-level data flow diagram illustrates the News Digest system's primary external interactions. Users interact with the system through authentication requests, digest generation requests, article interactions, and preference management commands. The system responds with personalized news digests, article analyses, and preference confirmations. Externally, the system consumes news content from multiple RSS feed sources and utilizes the Google Gemini API for all AI processing tasks including summarization, classification, and analysis. The output flows back to users as fully processed, personalized digest content with comprehensive metadata.

## 9.2 User Authentication DFD

```mermaid
flowchart LR
    A[Credentials] --> B[Auth Route]
    B --> C[Validate]
    C --> D[MongoDB]

    E[Password] --> F[bcrypt Hash]
    F --> G[Compare]
    G --> H[JWT Token]
```

The authentication data flow begins with user credentials submitted to the auth route endpoint. The route delegates to the validation process, which queries MongoDB to retrieve the stored user document. The submitted password passes through bcrypt hashing and comparison against the stored hash. Upon successful validation, the system generates a JWT token containing the user identifier and expiration timestamp. The token returns to the user for inclusion in subsequent authenticated requests, establishing a stateless session mechanism.

## 9.3 Digest Generation DFD

```mermaid
flowchart LR
    A[Request] --> B[Agent Service]
    B --> C[SequentialAgent]
    C --> D[Sub-Agents]

    E[User Prefs] --> F[Personalizer]
    F --> G[Ranked Digest]
    G --> H[Response]
```

The digest generation flow initiates when a user requests a fresh news digest. The agent service receives the request and invokes the ADK SequentialAgent with initial state. The sequential agent orchestrates sub-agents through the nine-stage pipeline, each agent processing articles and adding metadata. User preferences load from the database and flow into the Personalizer agent, which calculates relevance scores and ranks articles. The ranked digest returns through the service layer and formats as the API response delivered to the user.

## 9.4 RSS Aggregation DFD

```mermaid
flowchart LR
    A[Feed URLs] --> B[Fetch Tool]
    B --> C[Parse XML]
    C --> D[Articles]

    E[Extract Data] --> F[Image Search]
    F --> G[Generate IDs]
    G --> H[Sort by Date]
```

The RSS aggregation flow begins with configured feed URLs passed to the fetch tool function. The tool requests XML content from each feed source and parses responses using feedparser. Article entries extract into structured data objects containing title, link, description, and publication date. The extraction process searches for images in media elements, enclosures, and HTML content. Each article receives a unique identifier generated from the URL hash. Finally, all aggregated articles sort by publication date with newest items first.

## 9.5 Summarization DFD

```mermaid
flowchart LR
    A[Raw Articles] --> B[Summarizer]
    B --> C[Gemini API]
    C --> D[Summaries]

    E[Article Text] --> F[Prompt Build]
    F --> G[LLM Process]
    G --> H[Summary Field]
```

The summarization data flow transforms raw articles into summarized content. Raw articles from the fetcher agent pass to the Summarizer agent, which constructs prompts with article text and summarization instructions. The prompts submit to the Gemini API for language model processing. The model generates concise two-to-three sentence summaries capturing key facts. Summaries attach to their respective articles as a new field, and the enhanced articles flow to subsequent agents in the pipeline.

## 9.6 Preference Learning DFD

```mermaid
flowchart LR
    A[User Action] --> B[Record Event]
    B --> C[Get Weights]
    C --> D[Apply Delta]

    E[Topic List] --> F[Update Each]
    F --> G[Cap at 2.0]
    G --> H[Save to DB]
```

The preference learning flow captures user interactions and updates preference weights incrementally. User actions (click, like, dismiss, save, read) record as interaction events with article metadata. The service retrieves current preference weights from the database. Weight deltas apply based on the action type configuration. For each topic in the article, the corresponding weight updates with the delta value. All weights cap at 2.0 to prevent excessive amplification. Updated preferences persist to MongoDB for use in future digest personalization.

## 9.7 Sentiment Analysis DFD

```mermaid
flowchart LR
    A[Articles] --> B[Sentiment Agent]
    B --> C[Gemini API]
    C --> D[Analysis]

    E[Content Text] --> F[Tone Eval]
    F --> G[Score Calc]
    G --> H[Add Fields]
```

The sentiment analysis flow evaluates the emotional tone of each article in the digest. Articles pass to the Sentiment Analyzer agent, which prepares content for evaluation. The agent sends article text to the Gemini API with sentiment analysis instructions. The model evaluates tone and returns classification (positive, negative, neutral, mixed) along with a numerical score from -1.0 to 1.0. The sentiment category and score attach to each article as new metadata fields, enriching the article for user display.

## 9.8 Personalization DFD

```mermaid
flowchart LR
    A[Articles] --> B[Personalizer]
    B --> C[Score Tool]
    C --> D[Relevance]

    E[User Prefs] --> F[Apply Weights]
    F --> G[Rank Sort]
    G --> H[Top Articles]
```

The personalization flow ranks articles based on individual user preferences. Classified and analyzed articles flow to the Personalizer agent along with the user's preference document. The score_article tool calculates relevance for each article by applying topic weights and source preferences. Liked topics increase scores while dismissed topics apply penalties. The rank_articles tool sorts articles by relevance score in descending order. The top-ranked articles comprise the personalized digest returned to the user.

## 9.9 Article Viewer DFD

```mermaid
flowchart LR
    A[Article ID] --> B[Fetch Article]
    B --> C[Load Analysis]
    C --> D[Display Data]

    E[User Request] --> F[Audio/Explain]
    F --> G[AI Process]
    G --> H[Rich Content]
```

The article viewer flow delivers detailed article content with extended functionality. When a user selects an article, the ID passes to the fetch endpoint which retrieves the article with all analysis metadata including summary, sentiment, bias, and related articles. The frontend displays the article data in the viewer template. Users can request additional processing such as audio synthesis of the summary or deep explanation of the article. These requests invoke additional AI processing that returns rich content enhancing the article experience.

# 10. Table Structure

The News Digest platform uses MongoDB as its document database, storing data across five primary collections with optimized indexes for query performance.

## 10.1 Users Collection

Stores user account information and authentication credentials.

| Field | Type | Description |
|-------|------|-------------|
| _id | ObjectId | MongoDB-generated unique identifier |
| email | String | User email address (unique index) |
| username | String | Display name (unique index) |
| password_hash | String | bcrypt-hashed password |
| created_at | DateTime | Account creation timestamp |
| updated_at | DateTime | Last modification timestamp |
| total_digests_generated | Integer | Count of digests created |
| total_articles_read | Integer | Count of articles read |
| last_digest_at | DateTime | Timestamp of last digest generation |
| settings.theme | String | UI theme preference ("light" or "dark") |
| settings.digest_time | String | Preferred digest delivery time (HH:MM) |
| settings.max_articles | Integer | Maximum articles per digest |
| settings.notifications_enabled | Boolean | Push notification preference |

**Indexes:**
- `email` (unique)
- `username` (unique)

## 10.2 Preferences Collection

Stores learned user preferences for content personalization.

| Field | Type | Description |
|-------|------|-------------|
| _id | ObjectId | MongoDB-generated unique identifier |
| user_id | String | Reference to user ID (unique index) |
| liked_topics | Object | Topic name to weight mapping (0.0 to 2.0) |
| dismissed_topics | Object | Topic name to negative weight mapping |
| source_weights | Object | Source name to preference weight mapping |
| blocked_sources | Array | List of completely blocked source names |
| custom_feeds | Object | Custom feed name to URL mapping |
| created_at | DateTime | Preference record creation timestamp |
| updated_at | DateTime | Last preference update timestamp |

**Indexes:**
- `user_id` (unique)

**Example Document:**
```json
{
  "_id": "67890abc...",
  "user_id": "12345...",
  "liked_topics": {
    "technology": 1.2,
    "science": 0.8,
    "business": 0.5
  },
  "dismissed_topics": {
    "entertainment": 0.4
  },
  "source_weights": {
    "techcrunch": 0.6,
    "bbc_world": 0.3
  },
  "blocked_sources": ["tabloid_news"],
  "custom_feeds": {
    "my_blog": "https://myblog.com/rss"
  }
}
```

## 10.3 Articles Collection

Stores processed news articles with all AI analysis metadata.

| Field | Type | Description |
|-------|------|-------------|
| _id | String | MD5 hash of article URL (12 characters) |
| title | String | Article headline |
| link | String | URL to original article |
| source | String | Feed source identifier |
| published | DateTime | Article publication timestamp |
| fetched_at | DateTime | When article was fetched |
| description | String | Original RSS description |
| summary | String | AI-generated 2-3 sentence summary |
| tldr | String | One-line ultra-short summary (max 15 words) |
| full_text | String | Extracted article body (optional) |
| image_url | String | Header/thumbnail image URL |
| topics | Array | List of assigned topic categories |
| sentiment | String | Sentiment classification |
| sentiment_score | Float | Sentiment value (-1.0 to 1.0) |
| bias | String | Political bias classification |
| bias_explanation | String | Reason for bias rating |
| is_breaking | Boolean | Breaking news flag |
| breaking_score | Float | Importance score (0.0 to 1.0) |
| related_ids | Array | IDs of related articles |
| view_count | Integer | Total views across all users |
| like_count | Integer | Total likes |
| dismiss_count | Integer | Total dismissals |
| save_count | Integer | Total saves |

**Indexes:**
- `source` (standard)
- `published` (descending)
- `topics` (multikey)

**Sentiment Values:** "positive", "negative", "neutral", "mixed"

**Bias Values:** "left", "center-left", "center", "center-right", "right", "factual"

**Topic Values:** "technology", "science", "business", "politics", "health", "entertainment", "sports", "world", "environment", "education"

## 10.4 Interactions Collection

Records user interactions with articles for preference learning.

| Field | Type | Description |
|-------|------|-------------|
| _id | ObjectId | MongoDB-generated unique identifier |
| user_id | String | Reference to user ID |
| article_id | String | Reference to article ID |
| action | String | Interaction type |
| article_title | String | Article title at time of interaction |
| article_topics | Array | Article topics at time of interaction |
| article_source | String | Article source at time of interaction |
| time_spent_seconds | Integer | Reading time for "read" actions |
| created_at | DateTime | Interaction timestamp |

**Indexes:**
- `user_id` (standard)
- `user_id` + `created_at` (compound, descending on created_at)
- `article_id` (standard)

**Action Values:** "click", "like", "dismiss", "save", "read"

**Weight Adjustments by Action:**
| Action | liked_topics | dismissed_topics | source_weights |
|--------|--------------|------------------|----------------|
| click | +0.1 | - | +0.05 |
| like | +0.3 | - | +0.2 |
| dismiss | - | +0.2 | - |
| save | +0.5 | - | +0.1 |
| read | +0.15 | - | +0.05 |

## 10.5 Digests Collection

Stores generated personalized digests for each user.

| Field | Type | Description |
|-------|------|-------------|
| _id | ObjectId | MongoDB-generated unique identifier |
| user_id | String | Reference to user ID |
| date | Date | Date the digest is for |
| articles | Array | List of DigestArticle objects |
| generated_at | DateTime | When digest was generated |
| article_count | Integer | Number of articles in digest |
| top_topics | Array | Most common topics in digest |
| sources_used | Array | Sources represented in digest |
| personalization_score | Float | Average relevance score |
| articles_clicked | Integer | Articles clicked from this digest |
| articles_liked | Integer | Articles liked from this digest |
| articles_dismissed | Integer | Articles dismissed from this digest |
| articles_saved | Integer | Articles saved from this digest |

**DigestArticle Embedded Document:**
| Field | Type | Description |
|-------|------|-------------|
| id | String | Article ID |
| title | String | Article headline |
| link | String | Article URL |
| source | String | Feed source |
| summary | String | Article summary |
| tldr | String | One-line summary |
| topics | Array | Topic categories |
| relevance_score | Float | Personalization relevance |
| published | String | Publication date (ISO format) |
| image_url | String | Thumbnail image URL |
| sentiment | String | Sentiment classification |
| sentiment_score | Float | Sentiment value |
| bias | String | Bias classification |
| bias_explanation | String | Bias reasoning |
| is_breaking | Boolean | Breaking news flag |
| related_ids | Array | Related article IDs |

**Indexes:**
- `user_id` (standard)
- `user_id` + `date` (compound, descending on date)
- `user_id` + `date` (unique, for one digest per day)

# 11. Source Code

## 11.1 SequentialAgent Configuration

The root agent orchestrates the nine-stage news processing pipeline using ADK SequentialAgent.

```python
"""
Root News Digest Agent - Orchestrates the news digest generation workflow.
"""
from google.adk.agents import SequentialAgent

from .sub_agents import (
    news_fetcher_agent,
    summarizer_agent,
    topic_classifier_agent,
    personalizer_agent,
    sentiment_analyzer_agent,
    bias_analyzer_agent,
    related_finder_agent,
    breaking_detector_agent,
    tldr_generator_agent,
)

# Create the root agent as a SequentialAgent
# This runs sub-agents in order: fetch -> summarize -> tldr -> classify -> 
# sentiment -> bias -> breaking -> related -> personalize
root_agent = SequentialAgent(
    name="NewsDigestAgent",
    sub_agents=[
        news_fetcher_agent,
        summarizer_agent,
        tldr_generator_agent,
        topic_classifier_agent,
        sentiment_analyzer_agent,
        bias_analyzer_agent,
        breaking_detector_agent,
        related_finder_agent,
        personalizer_agent,
    ],
    description="Fetches news from RSS feeds, summarizes articles, analyzes "
                "sentiment/bias, detects breaking news, finds related articles, "
                "and personalizes based on user preferences.",
)
```

## 11.2 LlmAgent Sub-Agent Definition

Each sub-agent is an LlmAgent with specific instructions and output keys.

```python
"""
Summarizer Agent - Creates concise summaries for news articles.
"""
from google.adk.agents import LlmAgent

from ..config import config
from ..prompt import SUMMARIZER_INSTRUCTION

summarizer_agent = LlmAgent(
    name="SummarizerAgent",
    model=config.summarizer_model,
    description="Creates concise 2-3 sentence summaries for news articles.",
    instruction=SUMMARIZER_INSTRUCTION,
    output_key="summarized_articles",
)
```

## 11.3 Personalizer Agent with Tools

The personalizer agent uses function tools for relevance scoring.

```python
"""
Personalizer Agent - Ranks and filters articles based on user preferences.
"""
from google.adk.agents import LlmAgent
from google.adk.tools import FunctionTool

from ..config import config
from ..prompt import PERSONALIZER_INSTRUCTION
from ..tools import score_article, rank_articles

personalizer_agent = LlmAgent(
    name="PersonalizerAgent",
    model=config.main_model,
    description="Ranks and filters articles based on user preferences.",
    instruction=PERSONALIZER_INSTRUCTION,
    tools=[
        FunctionTool(func=score_article),
        FunctionTool(func=rank_articles),
    ],
    output_key="personalized_digest",
)
```

## 11.4 RSS Feed Aggregation Tool

The fetch tool aggregates articles from multiple RSS sources.

```python
def fetch_rss_feed(feed_url: str, source_name: str = "unknown") -> Dict[str, Any]:
    """
    Fetches and parses an RSS feed, returning articles.
    """
    try:
        feed = feedparser.parse(feed_url)
        
        if feed.bozo and not feed.entries:
            return {
                "status": "error",
                "message": f"Failed to parse feed: {feed.bozo_exception}",
                "articles": []
            }
        
        articles = []
        for entry in feed.entries[:20]:  # Limit to 20 per feed
            # Parse publication date
            published = None
            if hasattr(entry, 'published_parsed') and entry.published_parsed:
                published = datetime.fromtimestamp(mktime(entry.published_parsed))
            elif hasattr(entry, 'updated_parsed') and entry.updated_parsed:
                published = datetime.fromtimestamp(mktime(entry.updated_parsed))
            else:
                published = datetime.utcnow()
            
            # Generate article ID from URL
            article_id = hashlib.md5(entry.link.encode()).hexdigest()[:12]
            
            # Get description/summary
            description = ""
            if hasattr(entry, 'summary'):
                description = BeautifulSoup(entry.summary, 'html.parser').get_text()[:500]
            elif hasattr(entry, 'description'):
                description = BeautifulSoup(entry.description, 'html.parser').get_text()[:500]
            
            # Extract header image
            image_url = extract_image_from_entry(entry)
            
            articles.append({
                "id": article_id,
                "title": entry.title if hasattr(entry, 'title') else "Untitled",
                "link": entry.link if hasattr(entry, 'link') else "",
                "source": source_name,
                "published": published.isoformat() if published else None,
                "description": description.strip(),
                "image_url": image_url,
            })
        
        return {
            "status": "success",
            "source": source_name,
            "article_count": len(articles),
            "articles": articles
        }
        
    except Exception as e:
        return {"status": "error", "message": str(e), "articles": []}
```

## 11.5 Relevance Scoring Algorithm

The scoring function calculates article relevance based on user preferences.

```python
def score_article(
    article: Dict[str, Any],
    preferences: Dict[str, Any]
) -> Dict[str, Any]:
    """
    Calculates relevance score for an article based on user preferences.
    """
    liked_topics = preferences.get("liked_topics", {})
    dismissed_topics = preferences.get("dismissed_topics", {})
    source_weights = preferences.get("source_weights", {})
    blocked_sources = preferences.get("blocked_sources", [])
    
    # Check if source is blocked
    if article.get("source") in blocked_sources:
        article["relevance_score"] = -1
        article["is_blocked"] = True
        return article
    
    # Calculate base score
    score = 1.0
    
    # Add topic preferences
    article_topics = article.get("topics", [])
    for topic in article_topics:
        score += liked_topics.get(topic, 0)
        score -= dismissed_topics.get(topic, 0) * 1.5  # 1.5x penalty
    
    # Add source preference
    score += source_weights.get(article.get("source", ""), 0)
    
    article["relevance_score"] = round(score, 2)
    article["is_blocked"] = False
    return article
```

## 11.6 Preference Learning Service

The preference service records interactions and updates weights.

```python
async def record_interaction(
    self,
    user_id: str,
    article_id: str,
    action: str,
    article_title: str = "",
    article_topics: List[str] = None,
    article_source: str = "",
    time_spent_seconds: int = None
) -> Dict[str, Any]:
    """
    Record a user interaction and update preferences accordingly.
    This is the core of the preference learning algorithm.
    """
    db = self._get_db()
    
    if article_topics is None:
        article_topics = []
    
    # Create interaction record
    interaction = InteractionModel(
        user_id=user_id,
        article_id=article_id,
        action=action,
        article_title=article_title,
        article_topics=article_topics,
        article_source=article_source,
        time_spent_seconds=time_spent_seconds
    )
    
    await db.interactions.insert_one(interaction.to_dict())
    
    # Get current preferences
    preferences = await self.get_or_create_preferences(user_id)
    
    # Calculate weight adjustments based on action
    weights = INTERACTION_WEIGHTS.get(action, {})
    
    updates = {}
    
    # Update liked_topics
    if "liked_topics" in weights:
        delta = weights["liked_topics"]
        liked = dict(preferences.liked_topics)
        for topic in article_topics:
            liked[topic] = min(liked.get(topic, 0) + delta, 2.0)  # Cap at 2.0
        updates["liked_topics"] = liked
    
    # Update dismissed_topics
    if "dismissed_topics" in weights:
        delta = weights["dismissed_topics"]
        dismissed = dict(preferences.dismissed_topics)
        for topic in article_topics:
            dismissed[topic] = min(dismissed.get(topic, 0) + delta, 2.0)
        updates["dismissed_topics"] = dismissed
    
    # Update source_weights
    if "source_weights" in weights and article_source:
        delta = weights["source_weights"]
        sources = dict(preferences.source_weights)
        sources[article_source] = min(sources.get(article_source, 0) + delta, 2.0)
        updates["source_weights"] = sources
    
    # Apply updates
    if updates:
        await self.update_preferences(user_id, updates)
    
    return {
        "success": True,
        "action": action,
        "article_id": article_id,
        "preferences_updated": bool(updates)
    }
```

## 11.7 MongoDB Connection with AsyncMongoClient

The database module manages async MongoDB connections.

```python
"""
MongoDB connection using PyMongo async API.
"""
from typing import Optional
from pymongo import AsyncMongoClient
from pymongo.database import Database
from pymongo.errors import ServerSelectionTimeoutError, ConnectionFailure

from app.config import settings

_client: Optional[AsyncMongoClient] = None
_database: Optional[Database] = None


async def init_db() -> None:
    """Initialize the MongoDB connection."""
    global _client, _database
    
    try:
        _client = AsyncMongoClient(
            settings.mongodb_uri,
            serverSelectionTimeoutMS=5000
        )
        _database = _client[settings.mongodb_database]
        
        # Test the connection
        await _client.admin.command('ping')
        
        # Create indexes
        await _create_indexes()
        
        print(f"Connected to MongoDB: {settings.mongodb_database}")
    except (ServerSelectionTimeoutError, ConnectionFailure) as e:
        print(f"WARNING: Could not connect to MongoDB: {e}")
        _client = None
        _database = None


def get_database() -> Database:
    """Get the database instance."""
    if _database is None:
        raise RuntimeError(
            "Database not initialized. MongoDB connection failed."
        )
    return _database
```

## 11.8 Agent Prompt Instructions

The prompts define agent behavior and output formats.

```python
SUMMARIZER_INSTRUCTION = """You are a News Summarizer Agent that creates 
concise, readable summaries.

## Your Task

Take the articles from `{raw_articles}` and create a 2-3 sentence summary 
for each one.

## Guidelines

1. Keep summaries informative but brief (2-3 sentences max)
2. Capture the key facts: who, what, when, where, why
3. Use clear, accessible language
4. Avoid editorializing - stay factual
5. If the description already serves as a good summary, use it directly

## Output Format

Return the articles with an added `summary` field in the `summarized_articles` 
state key. Each article should have: title, link, source, published, summary
"""

SENTIMENT_ANALYZER_INSTRUCTION = """You are a Sentiment Analysis Agent that 
evaluates the emotional tone of news articles.

## Sentiment Categories

- **positive**: Uplifting, good news, achievements, progress
- **negative**: Tragic, concerning, failures, conflicts, disasters
- **neutral**: Factual reporting without strong emotional tone
- **mixed**: Contains both positive and negative elements

## Output Format

For each article, add:
- `sentiment`: One of "positive", "negative", "neutral", "mixed"
- `sentiment_score`: Float from -1.0 (very negative) to 1.0 (very positive)

Return articles in the `sentiment_analyzed` state key.
"""
```

# 12. Screenshots

## 12.1 Landing Page

![Landing Page](screenshots/landing-page.png)

The landing page welcomes users with a modern glassmorphism design featuring animated gradient backgrounds that shift between complementary colors. The authentication forms for login and registration are centered on the page with smooth transitions between modes, providing clear input validation feedback and password visibility toggles for user convenience.

## 12.2 User Registration

![User Registration](screenshots/registration.png)

The registration form collects essential user information including email address, username, and password with confirmation. Real-time validation highlights input errors before submission, and successful registration automatically transitions users to the dashboard with their first personalized digest.

## 12.3 User Login

![User Login](screenshots/login.png)

The login interface presents a streamlined form for returning users to enter their credentials. Failed authentication attempts display clear error messages without revealing which field was incorrect, and a "forgot password" link provides account recovery options for users who need assistance accessing their accounts.

## 12.4 Dashboard Overview

![Dashboard](screenshots/dashboard.png)

The dashboard serves as the central hub for news consumption, displaying the personalized digest in a responsive card grid layout. Each article card shows the headline, source badge, topic tags, relevance score indicator, and a TLDR summary, enabling users to quickly scan their digest and identify articles of interest.

## 12.5 Article Cards with Metadata

![Article Cards](screenshots/article-cards.png)

Article cards display comprehensive metadata including sentiment indicators (positive, negative, neutral, mixed) as colored badges, bias ratings with explanatory tooltips, and breaking news flags for time-sensitive stories. Action buttons for like, dismiss, and save appear on hover, allowing users to interact without leaving the digest view.

## 12.6 Breaking News Indicator

![Breaking News](screenshots/breaking-news.png)

Breaking news articles receive prominent visual treatment with a pulsing red badge and elevated card styling to draw immediate attention. The breaking score determines visibility priority, ensuring users see important developing stories first regardless of their personalization settings.

## 12.7 Topic Filter Controls

![Topic Filters](screenshots/topic-filters.png)

The filter bar above the digest allows users to quickly filter by topic category, source, or sentiment. Active filters highlight visually, and combining multiple filters creates intersection queries that narrow the displayed articles to specific user interests.

## 12.8 Article Viewer

![Article Viewer](screenshots/article-viewer.png)

The article viewer presents the full summary with all analysis metadata in an immersive reading layout. The header displays the headline, source, and publication date, while the main content area shows the AI-generated summary, sentiment analysis with score visualization, and bias assessment with explanation.

## 12.9 Related Articles Section

![Related Articles](screenshots/related-articles.png)

The related articles panel appears below the main article content, suggesting connected stories that share events, topics, or perspectives. Each related article thumbnail links directly to its viewer, encouraging deeper exploration of news topics.

## 12.10 Audio Player Interface

![Audio Player](screenshots/audio-player.png)

The audio synthesis interface provides text-to-speech playback of article summaries with standard media controls. Users can play, pause, and scrub through the audio, with playback speed adjustment for faster or slower listening according to preference.

## 12.11 Chat Interface

![Chat Interface](screenshots/chat-interface.png)

The conversational chat panel enables users to ask questions about the current article or explore related topics through natural language dialogue. The AI assistant responds with contextually relevant information, drawing from the article content and broader knowledge to provide insightful answers.

## 12.12 Explain Feature

![Explain Feature](screenshots/explain-feature.png)

The explain feature generates in-depth analysis of articles, providing historical context, implications, and background information that enhances understanding. The expanded explanation appears in a modal overlay with scrollable content for longer analyses.

## 12.13 Preferences Dashboard

![Preferences Dashboard](screenshots/preferences-dashboard.png)

The preferences page visualizes learned topic weights as progress bars showing relative interest levels across categories. The interface displays source preference weights, lists blocked sources with unblock buttons, and shows custom RSS feeds with management controls for adding or removing personalized sources.

## 12.14 Custom Feed Management

![Custom Feeds](screenshots/custom-feeds.png)

The custom feed management section allows users to add personalized RSS sources by entering a feed name and URL. Added feeds integrate with the standard aggregation pipeline, receiving the same AI processing as default sources and contributing to the personalized digest.

## 12.15 Blocked Sources List

![Blocked Sources](screenshots/blocked-sources.png)

The blocked sources display shows all sources the user has chosen to exclude from their digest. Each blocked source appears with an unblock button, and removing a source immediately restores it to future digest generation without requiring preference reset.

## 12.16 Theme Toggle

![Theme Toggle](screenshots/theme-toggle.png)

The theme toggle in the navigation bar allows users to switch between light and dark modes with instant visual feedback. The selected theme persists across sessions and applies consistently to all pages, with smooth transition animations between modes.

## 12.17 Mobile Responsive View

![Mobile View](screenshots/mobile-view.png)

The responsive design adapts the dashboard layout for mobile devices, stacking article cards vertically and collapsing the navigation into a hamburger menu. Touch-friendly button sizes and swipe gestures provide a native app-like experience on smartphones and tablets.

## 12.18 Digest Generation Progress

![Generation Progress](screenshots/generation-progress.png)

During digest generation, a progress indicator displays the current processing stage as articles flow through the nine-agent pipeline. Status updates show which agent is active (fetching, summarizing, analyzing, personalizing), giving users visibility into the AI processing that creates their personalized digest.

# 13. Bibliography

## AI and Machine Learning

1. Vaswani, A., Shazeer, N., Parmar, N., Uszkoreit, J., Jones, L., Gomez, A. N., Kaiser, L., & Polosukhin, I. (2017). Attention is All You Need. *Advances in Neural Information Processing Systems*, 30.

2. Brown, T., Mann, B., Ryder, N., Subbiah, M., Kaplan, J. D., Dhariwal, P., ... & Amodei, D. (2020). Language Models are Few-Shot Learners. *Advances in Neural Information Processing Systems*, 33, 1877-1901.

3. Devlin, J., Chang, M. W., Lee, K., & Toutanova, K. (2019). BERT: Pre-training of Deep Bidirectional Transformers for Language Understanding. *Proceedings of NAACL-HLT*, 4171-4186.

4. Wei, J., Bosma, M., Zhao, V., Guu, K., Yu, A. W., Lester, B., ... & Le, Q. V. (2022). Finetuned Language Models are Zero-Shot Learners. *International Conference on Learning Representations*.

5. Anil, R., Dai, A. M., Firat, O., Johnson, M., Lepikhin, D., Passos, A., ... & Wu, Y. (2023). Gemini: A Family of Highly Capable Multimodal Models. *arXiv preprint arXiv:2312.11805*.

## Agent Development

6. Wang, L., Ma, C., Feng, X., Zhang, Z., Yang, H., Zhang, J., ... & Chen, J. (2024). A Survey on Large Language Model based Autonomous Agents. *Frontiers of Computer Science*, 18(6), 186345.

7. Xi, Z., Chen, W., Guo, X., He, W., Ding, Y., Hong, B., ... & Gui, T. (2023). The Rise and Potential of Large Language Model Based Agents: A Survey. *arXiv preprint arXiv:2309.07864*.

8. Chase, H. (2022). LangChain: Building Applications with LLMs through Composability. *GitHub Repository*. https://github.com/langchain-ai/langchain

9. Google. (2024). Agent Development Kit Documentation. *Google AI for Developers*. https://ai.google.dev/adk

10. Yao, S., Zhao, J., Yu, D., Du, N., Shafran, I., Narasimhan, K., & Cao, Y. (2022). ReAct: Synergizing Reasoning and Acting in Language Models. *arXiv preprint arXiv:2210.03629*.

## Natural Language Processing

11. Liu, Y., Ott, M., Goyal, N., Du, J., Joshi, M., Chen, D., ... & Stoyanov, V. (2019). RoBERTa: A Robustly Optimized BERT Pretraining Approach. *arXiv preprint arXiv:1907.11692*.

12. Raffel, C., Shazeer, N., Roberts, A., Lee, K., Narang, S., Matena, M., ... & Liu, P. J. (2020). Exploring the Limits of Transfer Learning with a Unified Text-to-Text Transformer. *Journal of Machine Learning Research*, 21(140), 1-67.

13. Zhang, J., Zhao, Y., Saleh, M., & Liu, P. (2020). PEGASUS: Pre-training with Extracted Gap-sentences for Abstractive Summarization. *International Conference on Machine Learning*, 11328-11339.

14. Nallapati, R., Zhou, B., dos Santos, C., Gulcehre, C., & Xiang, B. (2016). Abstractive Text Summarization using Sequence-to-Sequence RNNs and Beyond. *Proceedings of CoNLL*, 280-290.

15. See, A., Liu, P. J., & Manning, C. D. (2017). Get To The Point: Summarization with Pointer-Generator Networks. *Proceedings of ACL*, 1073-1083.

## Sentiment and Bias Analysis

16. Liu, B. (2012). *Sentiment Analysis and Opinion Mining*. Morgan & Claypool Publishers.

17. Pang, B., & Lee, L. (2008). Opinion Mining and Sentiment Analysis. *Foundations and Trends in Information Retrieval*, 2(1-2), 1-135.

18. Hutto, C., & Gilbert, E. (2014). VADER: A Parsimonious Rule-Based Model for Sentiment Analysis of Social Media Text. *Proceedings of the International AAAI Conference on Web and Social Media*, 8(1), 216-225.

19. Budak, C., Goel, S., & Rao, J. M. (2016). Fair and Balanced? Quantifying Media Bias through Crowdsourced Content Analysis. *Public Opinion Quarterly*, 80(S1), 250-271.

20. Groseclose, T., & Milyo, J. (2005). A Measure of Media Bias. *The Quarterly Journal of Economics*, 120(4), 1191-1237.

## Recommendation Systems

21. Koren, Y., Bell, R., & Volinsky, C. (2009). Matrix Factorization Techniques for Recommender Systems. *Computer*, 42(8), 30-37.

22. He, X., Liao, L., Zhang, H., Nie, L., Hu, X., & Chua, T. S. (2017). Neural Collaborative Filtering. *Proceedings of the 26th International Conference on World Wide Web*, 173-182.

23. Hidasi, B., Karatzoglou, A., Baltrunas, L., & Tikk, D. (2015). Session-based Recommendations with Recurrent Neural Networks. *arXiv preprint arXiv:1511.06939*.

24. Konstan, J. A., & Riedl, J. (2012). Recommender Systems: From Algorithms to User Experience. *User Modeling and User-Adapted Interaction*, 22(1), 101-123.

25. Jannach, D., Zanker, M., Felfernig, A., & Friedrich, G. (2010). *Recommender Systems: An Introduction*. Cambridge University Press.

## Web Technologies

26. FastAPI. (2024). FastAPI Documentation. https://fastapi.tiangolo.com/

27. MongoDB Inc. (2024). MongoDB Manual. https://docs.mongodb.com/manual/

28. PyMongo. (2024). PyMongo Documentation. https://pymongo.readthedocs.io/

29. Pydantic. (2024). Pydantic Documentation. https://docs.pydantic.dev/

30. Jones, M., Bradley, J., & Sakimura, N. (2015). JSON Web Token (JWT). *RFC 7519*. https://tools.ietf.org/html/rfc7519

## RSS and News Aggregation

31. Winer, D. (2003). RSS 2.0 Specification. *Berkman Center for Internet & Society*. https://cyber.harvard.edu/rss/rss.html

32. Nottingham, M., & Sayre, R. (2005). The Atom Syndication Format. *RFC 4287*. https://tools.ietf.org/html/rfc4287

33. Kuchling, A. M. (2024). feedparser Documentation. https://feedparser.readthedocs.io/

34. Richardson, L. (2024). Beautiful Soup Documentation. https://www.crummy.com/software/BeautifulSoup/

35. Pariser, E. (2011). *The Filter Bubble: What the Internet Is Hiding from You*. Penguin Press.

## Security

36. Provos, N., & Mazières, D. (1999). A Future-Adaptable Password Scheme. *Proceedings of the USENIX Annual Technical Conference*, 81-91.

37. Jones, M., & Hardt, D. (2012). The OAuth 2.0 Authorization Framework: Bearer Token Usage. *RFC 6750*. https://tools.ietf.org/html/rfc6750

38. OWASP Foundation. (2021). OWASP Top Ten Web Application Security Risks. https://owasp.org/www-project-top-ten/

## Software Engineering

39. Fowler, M. (2002). *Patterns of Enterprise Application Architecture*. Addison-Wesley.

40. Martin, R. C. (2017). *Clean Architecture: A Craftsman's Guide to Software Structure and Design*. Prentice Hall.

41. Newman, S. (2021). *Building Microservices: Designing Fine-Grained Systems* (2nd ed.). O'Reilly Media.

42. Fielding, R. T. (2000). Architectural Styles and the Design of Network-based Software Architectures. *Doctoral dissertation*, University of California, Irvine.