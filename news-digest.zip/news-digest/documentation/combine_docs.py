"""
Combine all documentation markdown files into a single Total.md file.
"""
import os
import re

def combine_docs():
    """Read all numbered markdown files and combine into Total.md."""
    # Get the directory where this script is located
    script_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Find all numbered markdown files
    md_files = []
    for filename in os.listdir(script_dir):
        if filename.endswith('.md') and filename[0].isdigit():
            # Extract the number prefix for sorting
            match = re.match(r'^(\d+)', filename)
            if match:
                num = int(match.group(1))
                md_files.append((num, filename))
    
    # Sort by number
    md_files.sort(key=lambda x: x[0])
    
    # Combine contents
    combined_content = []
    for num, filename in md_files:
        filepath = os.path.join(script_dir, filename)
        print(f"[+] Reading: {filename}")
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read().strip()
            combined_content.append(content)
    
    # Write to Total.md
    output_path = os.path.join(script_dir, 'Total.md')
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write('\n\n'.join(combined_content))
    
    print(f"\n[+] Combined {len(md_files)} files into Total.md")
    print(f"[+] Output: {output_path}")

if __name__ == '__main__':
    combine_docs()
