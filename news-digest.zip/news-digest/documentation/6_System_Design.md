# 6. System Design

## 6.1 High-Level Architecture

```mermaid
flowchart LR
    A[Browser] --> B[FastAPI]
    B --> C[Services]
    C --> D[MongoDB]

    E[RSS Feeds] --> F[ADK Agent]
    F --> G[Gemini API]
    G --> H[Digest]
```

The News Digest architecture follows a layered design pattern with clear separation between presentation, business logic, and data persistence. The browser-based frontend communicates with the FastAPI backend through RESTful API endpoints, which delegate to specialized service classes for business logic execution. The service layer interacts with MongoDB through the PyMongo AsyncMongoClient for all data persistence operations. In parallel, the ADK SequentialAgent orchestrates nine specialized sub-agents that process news content by fetching from RSS feeds and utilizing the Gemini API for AI-powered analysis. The processed digest flows back through the service layer to the frontend for user consumption.

## 6.2 ADK Pipeline Flow

```mermaid
flowchart LR
    A[Fetcher] --> B[Summarizer]
    B --> C[TLDR]
    C --> D[Classifier]

    E[Sentiment] --> F[Bias]
    F --> G[Breaking]
    G --> H[Personalizer]
```

The ADK SequentialAgent executes nine specialized sub-agents in a precisely ordered pipeline. The News Fetcher Agent initiates the workflow by aggregating articles from configured RSS feeds, followed by the Summarizer Agent which generates concise two-to-three sentence summaries. The TLDR Generator creates ultra-brief one-line summaries, while the Topic Classifier assigns category labels to each article. The Sentiment Analyzer evaluates emotional tone, the Bias Analyzer assesses political slant, the Breaking Detector identifies urgent stories, the Related Finder discovers article connections, and finally the Personalizer Agent ranks content based on user preferences. State flows between agents through shared output keys.

## 6.3 Authentication Flow

```mermaid
flowchart LR
    A[Login Form] --> B[Auth Route]
    B --> C[Auth Service]
    C --> D[MongoDB]

    E[JWT Token] --> F[Protected Route]
    F --> G[Token Verify]
    G --> H[User Context]
```

The authentication system implements a stateless JWT-based flow for secure session management. Users submit credentials through the login form, which posts to the auth route endpoint. The auth service retrieves the user document from MongoDB and validates the password using bcrypt comparison. Upon successful authentication, a JWT token is generated with the user ID as subject claim and 24-hour expiration. Subsequent requests to protected routes include the token in the Authorization header, where middleware extracts and verifies the token, establishing the authenticated user context for the request lifecycle.

## 6.4 Digest Generation Flow

```mermaid
flowchart LR
    A[User Request] --> B[Digest Route]
    B --> C[Agent Service]
    C --> D[Sequential Agent]

    E[Sub-Agents] --> F[Gemini API]
    F --> G[Digest Service]
    G --> H[User Response]
```

Digest generation follows an orchestrated workflow starting with a user-initiated request to the digest endpoint. The digest route delegates to the agent service, which initializes and invokes the ADK SequentialAgent with the user's preference data. The sequential agent executes each sub-agent in order, with each agent calling the Gemini API for its specific AI task. As agents complete, their outputs accumulate in shared state. Upon pipeline completion, the digest service extracts the personalized digest from the final state, stores it in MongoDB, and returns the ranked, analyzed articles to the user through the response flow.

## 6.5 Preference Learning Flow

```mermaid
flowchart LR
    A[User Action] --> B[Interact Route]
    B --> C[Pref Service]
    C --> D[Weight Update]

    E[Topics] --> F[Adjust Weights]
    F --> G[Save Prefs]
    G --> H[MongoDB]
```

The preference learning system captures user interactions and incrementally updates preference weights. When a user performs an action (click, like, dismiss, save, or read), the interaction route records the event and delegates to the preference service. The service retrieves current preference weights, applies the configured weight deltas for the interaction type across all article topics, and adjusts the source weight if applicable. Updated preference values are capped at 2.0 to prevent runaway amplification. The modified preferences are persisted to MongoDB, ensuring they influence future digest personalization.

## 6.6 Entity Relationship Diagram

```mermaid
erDiagram
    USERS {
        ObjectId _id PK
        string email UK
        string username UK
        string password_hash
        datetime created_at
    }
    
    PREFERENCES {
        ObjectId _id PK
        string user_id FK
        dict liked_topics
        dict dismissed_topics
        dict source_weights
        list blocked_sources
        dict custom_feeds
        datetime updated_at
    }
    
    ARTICLES {
        string _id PK
        string title
        string link
        string source
        string summary
        string tldr
        list topics
        string sentiment
        float sentiment_score
        string bias
        bool is_breaking
        datetime published
    }
    
    INTERACTIONS {
        ObjectId _id PK
        string user_id FK
        string article_id FK
        string action
        string article_title
        list article_topics
        string article_source
        int time_spent
        datetime created_at
    }
    
    DIGESTS {
        ObjectId _id PK
        string user_id FK
        date date
        list article_ids
        dict metadata
        datetime created_at
    }
    
    USERS ||--o{ PREFERENCES : has
    USERS ||--o{ INTERACTIONS : records
    USERS ||--o{ DIGESTS : generates
    ARTICLES ||--o{ INTERACTIONS : receives
```

The entity relationship diagram illustrates the MongoDB document collections and their logical relationships. The Users collection stores authentication credentials and serves as the primary identity anchor. Each user has an associated Preferences document containing learned topic weights, source preferences, blocked sources, and custom feeds. The Articles collection stores processed news items with all analysis metadata including sentiment, bias, and breaking status. Interactions capture the user-article engagement events that drive preference learning. Digests represent the daily personalized article selections generated for each user, linking to the articles included in each digest.

## 6.7 Component Architecture

```mermaid
flowchart LR
    A[Routes] --> B[Services]
    B --> C[Database]
    C --> D[MongoDB]

    E[Agents] --> F[Sub-Agents]
    F --> G[Tools]
    G --> H[Gemini]
```

The component architecture organizes the system into distinct functional layers with clear dependency directions. The Routes layer contains FastAPI endpoint definitions that handle HTTP request/response processing and input validation. Routes delegate to the Services layer, which encapsulates business logic, orchestrates operations, and manages transactions. Services interact with the Database layer, which provides the MongoDB connection management and query execution through PyMongo AsyncMongoClient. In parallel, the Agents layer contains the ADK root agent that orchestrates Sub-Agents for specialized AI tasks. Sub-Agents utilize Tools for external operations like RSS fetching, and all AI processing flows through the Gemini integration.

## 6.8 Frontend Page Flow

```mermaid
flowchart LR
    A[Index] --> B[Login]
    B --> C[Dashboard]
    C --> D[Article]

    E[Dashboard] --> F[Preferences]
    F --> G[Dashboard]
    G --> H[Logout]
```

The frontend navigation flow guides users through the News Digest experience. Users arrive at the Index page containing authentication forms, proceeding through Login validation to reach the Dashboard, which serves as the central hub displaying the personalized digest. From the Dashboard, users can navigate to the Article viewer for detailed reading and analysis of individual stories. The Preferences page, accessible from the Dashboard, allows users to view and manage their learned preferences before returning to the Dashboard. The Logout action terminates the session and returns users to the Index page, completing the navigation cycle.
