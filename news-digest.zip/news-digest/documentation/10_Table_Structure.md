# 10. Table Structure

The News Digest platform uses MongoDB as its document database, storing data across five primary collections with optimized indexes for query performance.

## 10.1 Users Collection

Stores user account information and authentication credentials.

| Field | Type | Description |
|-------|------|-------------|
| _id | ObjectId | MongoDB-generated unique identifier |
| email | String | User email address (unique index) |
| username | String | Display name (unique index) |
| password_hash | String | bcrypt-hashed password |
| created_at | DateTime | Account creation timestamp |
| updated_at | DateTime | Last modification timestamp |
| total_digests_generated | Integer | Count of digests created |
| total_articles_read | Integer | Count of articles read |
| last_digest_at | DateTime | Timestamp of last digest generation |
| settings.theme | String | UI theme preference ("light" or "dark") |
| settings.digest_time | String | Preferred digest delivery time (HH:MM) |
| settings.max_articles | Integer | Maximum articles per digest |
| settings.notifications_enabled | Boolean | Push notification preference |

**Indexes:**
- `email` (unique)
- `username` (unique)

## 10.2 Preferences Collection

Stores learned user preferences for content personalization.

| Field | Type | Description |
|-------|------|-------------|
| _id | ObjectId | MongoDB-generated unique identifier |
| user_id | String | Reference to user ID (unique index) |
| liked_topics | Object | Topic name to weight mapping (0.0 to 2.0) |
| dismissed_topics | Object | Topic name to negative weight mapping |
| source_weights | Object | Source name to preference weight mapping |
| blocked_sources | Array | List of completely blocked source names |
| custom_feeds | Object | Custom feed name to URL mapping |
| created_at | DateTime | Preference record creation timestamp |
| updated_at | DateTime | Last preference update timestamp |

**Indexes:**
- `user_id` (unique)

**Example Document:**
```json
{
  "_id": "67890abc...",
  "user_id": "12345...",
  "liked_topics": {
    "technology": 1.2,
    "science": 0.8,
    "business": 0.5
  },
  "dismissed_topics": {
    "entertainment": 0.4
  },
  "source_weights": {
    "techcrunch": 0.6,
    "bbc_world": 0.3
  },
  "blocked_sources": ["tabloid_news"],
  "custom_feeds": {
    "my_blog": "https://myblog.com/rss"
  }
}
```

## 10.3 Articles Collection

Stores processed news articles with all AI analysis metadata.

| Field | Type | Description |
|-------|------|-------------|
| _id | String | MD5 hash of article URL (12 characters) |
| title | String | Article headline |
| link | String | URL to original article |
| source | String | Feed source identifier |
| published | DateTime | Article publication timestamp |
| fetched_at | DateTime | When article was fetched |
| description | String | Original RSS description |
| summary | String | AI-generated 2-3 sentence summary |
| tldr | String | One-line ultra-short summary (max 15 words) |
| full_text | String | Extracted article body (optional) |
| image_url | String | Header/thumbnail image URL |
| topics | Array | List of assigned topic categories |
| sentiment | String | Sentiment classification |
| sentiment_score | Float | Sentiment value (-1.0 to 1.0) |
| bias | String | Political bias classification |
| bias_explanation | String | Reason for bias rating |
| is_breaking | Boolean | Breaking news flag |
| breaking_score | Float | Importance score (0.0 to 1.0) |
| related_ids | Array | IDs of related articles |
| view_count | Integer | Total views across all users |
| like_count | Integer | Total likes |
| dismiss_count | Integer | Total dismissals |
| save_count | Integer | Total saves |

**Indexes:**
- `source` (standard)
- `published` (descending)
- `topics` (multikey)

**Sentiment Values:** "positive", "negative", "neutral", "mixed"

**Bias Values:** "left", "center-left", "center", "center-right", "right", "factual"

**Topic Values:** "technology", "science", "business", "politics", "health", "entertainment", "sports", "world", "environment", "education"

## 10.4 Interactions Collection

Records user interactions with articles for preference learning.

| Field | Type | Description |
|-------|------|-------------|
| _id | ObjectId | MongoDB-generated unique identifier |
| user_id | String | Reference to user ID |
| article_id | String | Reference to article ID |
| action | String | Interaction type |
| article_title | String | Article title at time of interaction |
| article_topics | Array | Article topics at time of interaction |
| article_source | String | Article source at time of interaction |
| time_spent_seconds | Integer | Reading time for "read" actions |
| created_at | DateTime | Interaction timestamp |

**Indexes:**
- `user_id` (standard)
- `user_id` + `created_at` (compound, descending on created_at)
- `article_id` (standard)

**Action Values:** "click", "like", "dismiss", "save", "read"

**Weight Adjustments by Action:**
| Action | liked_topics | dismissed_topics | source_weights |
|--------|--------------|------------------|----------------|
| click | +0.1 | - | +0.05 |
| like | +0.3 | - | +0.2 |
| dismiss | - | +0.2 | - |
| save | +0.5 | - | +0.1 |
| read | +0.15 | - | +0.05 |

## 10.5 Digests Collection

Stores generated personalized digests for each user.

| Field | Type | Description |
|-------|------|-------------|
| _id | ObjectId | MongoDB-generated unique identifier |
| user_id | String | Reference to user ID |
| date | Date | Date the digest is for |
| articles | Array | List of DigestArticle objects |
| generated_at | DateTime | When digest was generated |
| article_count | Integer | Number of articles in digest |
| top_topics | Array | Most common topics in digest |
| sources_used | Array | Sources represented in digest |
| personalization_score | Float | Average relevance score |
| articles_clicked | Integer | Articles clicked from this digest |
| articles_liked | Integer | Articles liked from this digest |
| articles_dismissed | Integer | Articles dismissed from this digest |
| articles_saved | Integer | Articles saved from this digest |

**DigestArticle Embedded Document:**
| Field | Type | Description |
|-------|------|-------------|
| id | String | Article ID |
| title | String | Article headline |
| link | String | Article URL |
| source | String | Feed source |
| summary | String | Article summary |
| tldr | String | One-line summary |
| topics | Array | Topic categories |
| relevance_score | Float | Personalization relevance |
| published | String | Publication date (ISO format) |
| image_url | String | Thumbnail image URL |
| sentiment | String | Sentiment classification |
| sentiment_score | Float | Sentiment value |
| bias | String | Bias classification |
| bias_explanation | String | Bias reasoning |
| is_breaking | Boolean | Breaking news flag |
| related_ids | Array | Related article IDs |

**Indexes:**
- `user_id` (standard)
- `user_id` + `date` (compound, descending on date)
- `user_id` + `date` (unique, for one digest per day)
