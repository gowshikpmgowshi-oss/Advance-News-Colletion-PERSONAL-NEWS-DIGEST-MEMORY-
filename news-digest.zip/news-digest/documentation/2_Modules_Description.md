# 2. Modules Description

## 2.1 Frontend Modules

### index.html
The landing page serves as the entry point for the News Digest platform. It presents the login and registration forms with a modern glassmorphism design aesthetic. The page includes animated gradient backgrounds, form validation feedback, and smooth transitions between authentication modes. It initializes the authentication flow and redirects authenticated users to the dashboard.

### dashboard.html
The main user interface displays the personalized news digest. It renders article cards with relevance scores, sentiment indicators, breaking news badges, and topic tags. The dashboard includes filtering controls, source management, and real-time digest refresh capabilities. Article cards display TLDR summaries, bias indicators, and action buttons for like, dismiss, and save interactions.

### article.html
The article viewer provides an immersive reading experience for selected articles. It displays the full summary, sentiment analysis, bias assessment, and related article suggestions. The page includes audio synthesis controls for listening to summaries, an explain feature for deeper AI analysis, and an interactive chat interface for exploring the article topic further.

### preferences.html
The preference management interface visualizes learned user preferences. It displays topic affinity weights as progress bars, lists blocked sources with unblock controls, and shows custom RSS feeds with management options. Users can reset preferences, add new custom feeds, and observe how their interactions have shaped the personalization algorithm.

## 2.2 API Route Modules

### auth.py
Handles user authentication endpoints including registration, login, and token refresh. Implements bcrypt password hashing for secure credential storage and generates JWT tokens with configurable expiration. The module validates user credentials, manages session state, and provides user profile retrieval endpoints.

### articles.py
Manages article retrieval and metadata endpoints. Provides routes to fetch individual articles by ID, retrieve article content, and access article analysis data. The module interfaces with the MongoDB articles collection and applies user preference filters to returned content.

### digest.py
Orchestrates the digest generation workflow by invoking the ADK SequentialAgent. Provides endpoints to trigger fresh digest generation, retrieve cached digests, and stream digest progress in real-time via Server-Sent Events. The module manages user-specific digest state and coordinates with the news service.

### interactions.py
Records and retrieves user interaction events. Implements endpoints for logging click, like, dismiss, save, and read actions. Each interaction triggers the preference learning algorithm to update user topic and source weights. The module also provides interaction history retrieval for analytics.

### preferences.py
Provides CRUD operations for user preference management. Endpoints allow retrieval of current preferences, manual preference updates, source blocking and unblocking, and custom RSS feed management. The module supports preference reset to default values and preference export.

### chat.py
Enables conversational exploration of news topics. Maintains chat session state and sends user messages to the Gemini model for contextual responses about articles. The module injects article context into prompts and returns AI-generated insights about news content.

### explain.py
Provides deep analysis endpoints for individual articles. When invoked, the module sends article content to Gemini for comprehensive explanation including historical context, implications, and related background information. Returns structured explanations for the article viewer.

### audio.py
Manages text-to-speech synthesis for article summaries. Provides endpoints to generate audio from summary text and retrieve cached audio files. The module interfaces with audio synthesis services and manages audio file storage and streaming.

## 2.3 ADK Agent Modules

### root_agent (SequentialAgent)
The NewsDigestAgent orchestrates the nine-agent processing pipeline. Configured as an ADK SequentialAgent, it ensures sub-agents execute in the correct order with proper state passing between stages. The agent description summarizes the complete workflow from fetching to personalization.

### news_fetcher_agent (LlmAgent)
Retrieves articles from configured RSS feeds using the fetch_all_feeds tool. Processes feed URLs, parses XML responses, and extracts article metadata including titles, links, publication dates, and descriptions. Stores raw articles in the shared agent state.

### summarizer_agent (LlmAgent)
Generates concise two-to-three sentence summaries for each article. Applies journalistic summarization principles to capture key facts while maintaining readability. Uses the Gemini summarizer model and outputs to the summarized_articles state key.

### tldr_generator_agent (LlmAgent)
Creates ultra-short one-sentence summaries for quick scanning. Applies strict word limits (maximum 15 words) to distill articles to their absolute essence. Enables rapid digest skimming for time-constrained users.

### topic_classifier_agent (LlmAgent)
Categorizes articles into predefined topic categories. Analyzes content and assigns one to three relevant topics per article from categories including technology, science, business, politics, health, entertainment, sports, world, environment, and education.

### sentiment_analyzer_agent (LlmAgent)
Evaluates the emotional tone of each article. Assigns sentiment categories (positive, negative, neutral, mixed) and calculates a sentiment score from -1.0 (very negative) to 1.0 (very positive). Uses the dedicated analysis model for consistent evaluation.

### bias_analyzer_agent (LlmAgent)
Assesses political and ideological bias in article content and sources. Assigns bias categories ranging from left to right or factual, with brief explanations for each rating. Helps users understand reporting perspectives.

### breaking_detector_agent (LlmAgent)
Identifies time-sensitive and high-importance news stories. Evaluates recency, impact, urgency, and novelty to calculate a breaking score from 0.0 to 1.0. Articles scoring 0.7 or higher receive breaking news designation.

### related_finder_agent (LlmAgent)
Discovers connections between articles in the digest. Identifies same-event coverage from different sources, follow-up stories, and thematically related content. Outputs related article IDs for each article.

### personalizer_agent (LlmAgent)
Ranks and filters articles based on user preferences. Uses the score_article and rank_articles function tools to calculate relevance scores and produce the final personalized digest. Respects blocked sources and applies topic/source weights.

## 2.4 Service Modules

### preference_service.py
The core preference learning service. Manages user preference documents, records interactions, and updates preference weights based on the configured weight adjustment algorithm. Provides methods for source blocking, custom feed management, and preference reset.

### digest_service.py
Coordinates digest generation and caching. Manages digest state per user, invokes the ADK agent, and stores completed digests in MongoDB. Provides efficient digest retrieval and handles digest refresh logic.

### news_service.py
Aggregates articles from RSS feeds and manages article storage. Parses RSS XML, extracts article metadata, generates article IDs, and persists articles to MongoDB. Interfaces with the news fetcher agent tools.

### auth_service.py
Implements authentication business logic. Handles user registration with password hashing, credential validation, JWT token generation, and token verification. Manages user document storage and retrieval.

### agent_service.py
Provides the interface between FastAPI routes and ADK agents. Initializes agent sessions, manages agent state, and processes agent responses. Handles streaming output for real-time digest generation.

### chat_service.py
Manages conversational AI interactions. Maintains chat history, formats prompts with article context, and processes Gemini responses. Supports multi-turn conversations about news topics.

### explain_service.py
Generates detailed article explanations. Formats article content for explanation prompts, processes Gemini analytical responses, and structures output for the frontend.

### audio_service.py
Handles text-to-speech synthesis. Generates audio from summary text, manages audio file storage, and provides audio streaming capabilities.

## 2.5 Database Module

### mongodb.py
Manages MongoDB connections using PyMongo AsyncMongoClient. Initializes database connections with timeout handling, creates indexes for optimal query performance, and provides the database instance accessor. Handles connection failures gracefully to allow application startup even when MongoDB is unavailable.
