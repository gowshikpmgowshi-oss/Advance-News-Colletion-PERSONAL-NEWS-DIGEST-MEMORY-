"""
News Digest Agent - ADK-powered news curation agent.
"""
from .agent import root_agent

__all__ = ["root_agent"]
