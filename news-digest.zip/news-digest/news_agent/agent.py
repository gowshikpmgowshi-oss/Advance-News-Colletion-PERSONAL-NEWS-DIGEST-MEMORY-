"""
Root News Digest Agent - Orchestrates the news digest generation workflow.
"""
import json
import re
from typing import Dict, Any

from google.adk.agents import SequentialAgent

from .config import config
from .prompt import ROOT_AGENT_INSTRUCTION
from .sub_agents import (
    news_fetcher_agent,
    summarizer_agent,
    topic_classifier_agent,
    personalizer_agent,
    sentiment_analyzer_agent,
    bias_analyzer_agent,
    related_finder_agent,
    breaking_detector_agent,
    tldr_generator_agent,
)


# Create the root agent as a SequentialAgent
# This runs sub-agents in order: fetch -> summarize -> tldr -> classify -> sentiment -> bias -> breaking -> related -> personalize
root_agent = SequentialAgent(
    name="NewsDigestAgent",
    sub_agents=[
        news_fetcher_agent,
        summarizer_agent,
        tldr_generator_agent,
        topic_classifier_agent,
        sentiment_analyzer_agent,
        bias_analyzer_agent,
        breaking_detector_agent,
        related_finder_agent,
        personalizer_agent,
    ],
    description="Fetches news from RSS feeds, summarizes articles, analyzes sentiment/bias, detects breaking news, finds related articles, and personalizes based on user preferences.",
)


def parse_json_response(response: str, default: Any = None) -> Any:
    """
    Parse a JSON response, handling common issues.
    
    Args:
        response: String that should contain JSON
        default: Default value if parsing fails
        
    Returns:
        Parsed JSON or default value
    """
    if not response:
        return default
    
    # Try direct parsing
    try:
        return json.loads(response)
    except json.JSONDecodeError:
        pass
    
    # Try to extract from code blocks
    code_match = re.search(r'```(?:json)?\s*([\s\S]*?)\s*```', response)
    if code_match:
        try:
            return json.loads(code_match.group(1))
        except json.JSONDecodeError:
            pass
    
    # Try to find array pattern
    array_match = re.search(r'\[[\s\S]*\]', response)
    if array_match:
        try:
            return json.loads(array_match.group())
        except json.JSONDecodeError:
            pass
    
    # Try to find object pattern
    obj_match = re.search(r'\{[\s\S]*\}', response)
    if obj_match:
        try:
            return json.loads(obj_match.group())
        except json.JSONDecodeError:
            pass
    
    return default
