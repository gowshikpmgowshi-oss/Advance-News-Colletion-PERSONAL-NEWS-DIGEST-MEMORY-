"""
Related Finder Agent - Identifies connections between news articles.
"""
from google.adk.agents import LlmAgent

from ..config import config
from ..prompt import RELATED_FINDER_INSTRUCTION


related_finder_agent = LlmAgent(
    name="RelatedFinderAgent",
    model=config.analysis_model,
    description="Finds semantic connections and relationships between news articles.",
    instruction=RELATED_FINDER_INSTRUCTION,
    output_key="related_mapped",
)
