"""
Summarizer Agent - Creates concise summaries for news articles.
"""
from google.adk.agents import LlmAgent

from ..config import config
from ..prompt import SUMMARIZER_INSTRUCTION


summarizer_agent = LlmAgent(
    name="SummarizerAgent",
    model=config.summarizer_model,
    description="Creates concise 2-3 sentence summaries for news articles.",
    instruction=SUMMARIZER_INSTRUCTION,
    output_key="summarized_articles",
)
