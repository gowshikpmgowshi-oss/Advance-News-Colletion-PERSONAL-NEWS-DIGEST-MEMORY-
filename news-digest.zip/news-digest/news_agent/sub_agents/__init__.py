"""
Sub-agents for the News Digest system.
"""
from .news_fetcher import news_fetcher_agent
from .summarizer import summarizer_agent
from .personalizer import personalizer_agent
from .topic_classifier import topic_classifier_agent
from .sentiment_analyzer import sentiment_analyzer_agent
from .bias_analyzer import bias_analyzer_agent
from .related_finder import related_finder_agent
from .breaking_detector import breaking_detector_agent
from .tldr_generator import tldr_generator_agent

__all__ = [
    "news_fetcher_agent",
    "summarizer_agent",
    "personalizer_agent",
    "topic_classifier_agent",
    "sentiment_analyzer_agent",
    "bias_analyzer_agent",
    "related_finder_agent",
    "breaking_detector_agent",
    "tldr_generator_agent",
]
