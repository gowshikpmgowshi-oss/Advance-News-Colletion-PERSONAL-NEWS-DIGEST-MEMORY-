"""
Topic Classifier Agent - Categorizes articles by topic.
"""
from google.adk.agents import LlmAgent

from ..config import config
from ..prompt import TOPIC_CLASSIFIER_INSTRUCTION


topic_classifier_agent = LlmAgent(
    name="TopicClassifierAgent",
    model=config.main_model,
    description="Classifies news articles into topic categories.",
    instruction=TOPIC_CLASSIFIER_INSTRUCTION,
    output_key="classified_articles",
)
