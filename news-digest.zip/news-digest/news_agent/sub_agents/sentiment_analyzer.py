"""
Sentiment Analyzer Agent - Evaluates emotional tone of news articles.
"""
from google.adk.agents import LlmAgent

from ..config import config
from ..prompt import SENTIMENT_ANALYZER_INSTRUCTION


sentiment_analyzer_agent = LlmAgent(
    name="SentimentAnalyzerAgent",
    model=config.analysis_model,
    description="Analyzes sentiment and emotional tone of news articles.",
    instruction=SENTIMENT_ANALYZER_INSTRUCTION,
    output_key="sentiment_analyzed",
)
