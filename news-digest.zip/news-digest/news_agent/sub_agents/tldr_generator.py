"""
TLDR Generator Agent - Creates ultra-short one-line summaries.
"""
from google.adk.agents import LlmAgent

from ..config import config
from ..prompt import TLDR_GENERATOR_INSTRUCTION


tldr_generator_agent = LlmAgent(
    name="TLDRGeneratorAgent",
    model=config.summarizer_model,
    description="Generates one-line TLDR summaries for quick scanning.",
    instruction=TLDR_GENERATOR_INSTRUCTION,
    output_key="tldr_generated",
)
