"""
Personalizer Agent - Ranks and filters articles based on user preferences.
"""
from google.adk.agents import LlmAgent
from google.adk.tools import FunctionTool

from ..config import config
from ..prompt import PERSONALIZER_INSTRUCTION
from ..tools import score_article, rank_articles


personalizer_agent = LlmAgent(
    name="PersonalizerAgent",
    model=config.main_model,
    description="Ranks and filters articles based on user preferences.",
    instruction=PERSONALIZER_INSTRUCTION,
    tools=[
        FunctionTool(func=score_article),
        FunctionTool(func=rank_articles),
    ],
    output_key="personalized_digest",
)
