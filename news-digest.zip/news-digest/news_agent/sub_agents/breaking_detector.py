"""
Breaking News Detector Agent - Identifies important developing stories.
"""
from google.adk.agents import LlmAgent

from ..config import config
from ..prompt import BREAKING_DETECTOR_INSTRUCTION


breaking_detector_agent = LlmAgent(
    name="BreakingDetectorAgent",
    model=config.analysis_model,
    description="Detects breaking and particularly important news stories.",
    instruction=BREAKING_DETECTOR_INSTRUCTION,
    output_key="breaking_detected",
)
