"""
Bias Analyzer Agent - Detects political/ideological bias in news.
"""
from google.adk.agents import LlmAgent

from ..config import config
from ..prompt import BIAS_ANALYZER_INSTRUCTION


bias_analyzer_agent = LlmAgent(
    name="BiasAnalyzerAgent",
    model=config.analysis_model,
    description="Analyzes political and ideological bias in news sources and content.",
    instruction=BIAS_ANALYZER_INSTRUCTION,
    output_key="bias_analyzed",
)
