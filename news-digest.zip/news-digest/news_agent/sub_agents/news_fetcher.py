"""
News Fetcher Agent - Retrieves articles from RSS feeds.
"""
from google.adk.agents import LlmAgent
from google.adk.tools import FunctionTool

from ..config import config
from ..prompt import NEWS_FETCHER_INSTRUCTION
from ..tools import fetch_all_feeds, fetch_rss_feed


news_fetcher_agent = LlmAgent(
    name="NewsFetcherAgent",
    model=config.main_model,
    description="Fetches the latest news articles from configured RSS feeds.",
    instruction=NEWS_FETCHER_INSTRUCTION,
    tools=[
        FunctionTool(func=fetch_all_feeds),
        FunctionTool(func=fetch_rss_feed),
    ],
    output_key="raw_articles",
)
