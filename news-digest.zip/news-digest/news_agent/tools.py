"""
Tools for the News Digest agent.
"""
import hashlib
from datetime import datetime
from typing import Dict, List, Any, Optional
from time import mktime

import feedparser
import httpx
from bs4 import BeautifulSoup

from .config import config


def extract_image_from_entry(entry) -> Optional[str]:
    """
    Extracts the header/thumbnail image from an RSS entry.
    
    Checks multiple sources in order of preference:
    1. media:content or media:thumbnail (Media RSS)
    2. enclosure (standard RSS media)
    3. Image in content/description HTML
    4. og:image if available
    """
    # 1. Check media:content (most common for news sites)
    if hasattr(entry, 'media_content') and entry.media_content:
        for media in entry.media_content:
            if media.get('medium') == 'image' or media.get('type', '').startswith('image/'):
                return media.get('url')
        # Sometimes media_content doesn't have type, just return first one
        if entry.media_content[0].get('url'):
            return entry.media_content[0]['url']
    
    # 2. Check media:thumbnail
    if hasattr(entry, 'media_thumbnail') and entry.media_thumbnail:
        return entry.media_thumbnail[0].get('url')
    
    # 3. Check enclosure (standard RSS for media attachments)
    if hasattr(entry, 'enclosures') and entry.enclosures:
        for enclosure in entry.enclosures:
            if enclosure.get('type', '').startswith('image/'):
                return enclosure.get('href') or enclosure.get('url')
    
    # 4. Check for image in links
    if hasattr(entry, 'links'):
        for link in entry.links:
            if link.get('type', '').startswith('image/'):
                return link.get('href')
    
    # 5. Try to extract from content/summary HTML
    content_html = ""
    if hasattr(entry, 'content') and entry.content:
        content_html = entry.content[0].get('value', '')
    elif hasattr(entry, 'summary'):
        content_html = entry.summary
    elif hasattr(entry, 'description'):
        content_html = entry.description
    
    if content_html:
        soup = BeautifulSoup(content_html, 'html.parser')
        img_tag = soup.find('img')
        if img_tag and img_tag.get('src'):
            img_url = img_tag['src']
            # Skip tiny tracking pixels
            if 'pixel' not in img_url.lower() and 'tracking' not in img_url.lower():
                return img_url
    
    return None


def fetch_rss_feed(feed_url: str, source_name: str = "unknown") -> Dict[str, Any]:
    """
    Fetches and parses an RSS feed, returning articles.
    
    Args:
        feed_url: URL of the RSS feed to fetch
        source_name: Name identifier for this source
        
    Returns:
        Dictionary with status and list of articles
    """
    try:
        feed = feedparser.parse(feed_url)
        
        if feed.bozo and not feed.entries:
            return {
                "status": "error",
                "message": f"Failed to parse feed: {feed.bozo_exception}",
                "articles": []
            }
        
        articles = []
        for entry in feed.entries[:20]:  # Limit to 20 per feed
            # Parse publication date
            published = None
            if hasattr(entry, 'published_parsed') and entry.published_parsed:
                published = datetime.fromtimestamp(mktime(entry.published_parsed))
            elif hasattr(entry, 'updated_parsed') and entry.updated_parsed:
                published = datetime.fromtimestamp(mktime(entry.updated_parsed))
            else:
                published = datetime.utcnow()
            
            # Generate article ID from URL
            article_id = hashlib.md5(entry.link.encode()).hexdigest()[:12]
            
            # Get description/summary
            description = ""
            if hasattr(entry, 'summary'):
                description = BeautifulSoup(entry.summary, 'html.parser').get_text()[:500]
            elif hasattr(entry, 'description'):
                description = BeautifulSoup(entry.description, 'html.parser').get_text()[:500]
            
            # Extract header image
            image_url = extract_image_from_entry(entry)
            
            articles.append({
                "id": article_id,
                "title": entry.title if hasattr(entry, 'title') else "Untitled",
                "link": entry.link if hasattr(entry, 'link') else "",
                "source": source_name,
                "published": published.isoformat() if published else None,
                "description": description.strip(),
                "image_url": image_url,
            })
        
        return {
            "status": "success",
            "source": source_name,
            "article_count": len(articles),
            "articles": articles
        }
        
    except Exception as e:
        return {
            "status": "error",
            "message": str(e),
            "articles": []
        }


def fetch_all_feeds(feed_urls: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
    """
    Fetches articles from all configured RSS feeds.
    
    Args:
        feed_urls: Optional dictionary of {source_name: feed_url}. 
                   If not provided, uses default feeds from config.
                   
    Returns:
        Dictionary with all articles from all sources
    """
    feeds = feed_urls or config.default_feeds
    all_articles = []
    feed_stats = {}
    
    for source_name, feed_url in feeds.items():
        result = fetch_rss_feed(feed_url, source_name)
        feed_stats[source_name] = {
            "status": result["status"],
            "count": result.get("article_count", 0)
        }
        if result["status"] == "success":
            all_articles.extend(result["articles"])
    
    # Sort by publication date (newest first)
    all_articles.sort(
        key=lambda x: x.get("published", ""),
        reverse=True
    )
    
    return {
        "status": "success",
        "total_articles": len(all_articles),
        "feed_stats": feed_stats,
        "articles": all_articles
    }


def score_article(
    article: Dict[str, Any],
    preferences: Dict[str, Any]
) -> Dict[str, Any]:
    """
    Calculates relevance score for an article based on user preferences.
    
    Args:
        article: Article dict with topics and source
        preferences: User preference dict with liked_topics, dismissed_topics, etc.
        
    Returns:
        Article with added relevance_score
    """
    liked_topics = preferences.get("liked_topics", {})
    dismissed_topics = preferences.get("dismissed_topics", {})
    source_weights = preferences.get("source_weights", {})
    blocked_sources = preferences.get("blocked_sources", [])
    
    # Check if source is blocked
    if article.get("source") in blocked_sources:
        article["relevance_score"] = -1
        article["is_blocked"] = True
        return article
    
    # Calculate base score
    score = 1.0
    
    # Add topic preferences
    article_topics = article.get("topics", [])
    for topic in article_topics:
        score += liked_topics.get(topic, 0)
        score -= dismissed_topics.get(topic, 0) * 1.5
    
    # Add source preference
    score += source_weights.get(article.get("source", ""), 0)
    
    article["relevance_score"] = round(score, 2)
    article["is_blocked"] = False
    return article


def rank_articles(
    articles: List[Dict[str, Any]],
    preferences: Dict[str, Any],
    max_articles: int = 15
) -> List[Dict[str, Any]]:
    """
    Ranks and filters articles based on user preferences.
    
    Args:
        articles: List of articles to rank
        preferences: User preference dictionary
        max_articles: Maximum number of articles to return
        
    Returns:
        Sorted list of top articles
    """
    # Score all articles
    scored_articles = [
        score_article(article.copy(), preferences)
        for article in articles
    ]
    
    # Filter out blocked articles
    filtered = [a for a in scored_articles if not a.get("is_blocked", False)]
    
    # Sort by relevance score
    filtered.sort(key=lambda x: x.get("relevance_score", 0), reverse=True)
    
    return filtered[:max_articles]


async def extract_article_text(url: str) -> Dict[str, Any]:
    """
    Extracts the main text content from an article URL.
    
    Args:
        url: URL of the article to extract
        
    Returns:
        Dictionary with extracted text or error
    """
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.get(url, follow_redirects=True)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Remove script and style elements
            for element in soup(['script', 'style', 'nav', 'footer', 'header']):
                element.decompose()
            
            # Try to find main content
            main_content = (
                soup.find('article') or 
                soup.find('main') or 
                soup.find(class_=['content', 'article-content', 'post-content']) or
                soup.find('body')
            )
            
            if main_content:
                # Get text and clean it
                text = main_content.get_text(separator='\n', strip=True)
                # Limit to first 5000 characters
                text = text[:5000]
                
                return {
                    "status": "success",
                    "url": url,
                    "text": text,
                    "word_count": len(text.split())
                }
            
            return {
                "status": "error",
                "message": "Could not find main content",
                "url": url
            }
            
    except Exception as e:
        return {
            "status": "error",
            "message": str(e),
            "url": url
        }
