"""
Agent configuration settings.
"""
import os
from dataclasses import dataclass, field
from typing import Dict


@dataclass
class AgentConfig:
    """Configuration for ADK agents."""
    
    # Model settings
    main_model: str = "gemini-2.5-flash"
    summarizer_model: str = "gemini-2.5-flash"
    analysis_model: str = "gemini-2.5-flash"  # For sentiment, bias, related, breaking
    
    # RSS Feed sources
    default_feeds: Dict[str, str] = field(default_factory=lambda: {
        "bbc_world": "http://feeds.bbci.co.uk/news/world/rss.xml",
        "bbc_tech": "http://feeds.bbci.co.uk/news/technology/rss.xml",
        "bbc_science": "http://feeds.bbci.co.uk/news/science_and_environment/rss.xml",
        "techcrunch": "https://techcrunch.com/feed/",
        "verge": "https://www.theverge.com/rss/index.xml",
        "ars_technica": "https://feeds.arstechnica.com/arstechnica/index",
        "npr_news": "https://feeds.npr.org/1001/rss.xml",
        "wired": "https://www.wired.com/feed/rss",
    })
    
    # Topic categories for classification
    topic_categories: list = field(default_factory=lambda: [
        "technology",
        "science",
        "business",
        "politics",
        "health",
        "entertainment",
        "sports",
        "world",
        "environment",
        "education",
    ])
    
    # Digest settings
    max_articles_per_digest: int = 15
    min_articles_per_digest: int = 5
    summary_max_sentences: int = 3
    
    # API Key
    @property
    def api_key(self) -> str:
        return os.getenv("GOOGLE_API_KEY", "")


config = AgentConfig()
