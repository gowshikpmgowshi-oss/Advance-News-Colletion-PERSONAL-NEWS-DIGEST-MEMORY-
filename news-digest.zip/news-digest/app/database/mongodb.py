"""
MongoDB connection using PyMongo async API.
"""
from typing import Optional
from pymongo import AsyncMongoClient
from pymongo.database import Database
from pymongo.errors import ServerSelectionTimeoutError, ConnectionFailure, DuplicateKeyError
import logging

from app.config import settings

logger = logging.getLogger(__name__)

# Global database client and database instance
_client: Optional[AsyncMongoClient] = None
_database: Optional[Database] = None


async def init_db() -> None:
    """Initialize the MongoDB connection."""
    global _client, _database
    
    try:
        _client = AsyncMongoClient(
            settings.mongodb_uri,
            serverSelectionTimeoutMS=5000
        )
        _database = _client[settings.mongodb_database]
        
        # Test the connection
        await _client.admin.command('ping')
        
        # Create indexes
        await _create_indexes()
        
        logger.info(f"Connected to MongoDB: {settings.mongodb_database}")
        print(f"✓ Connected to MongoDB: {settings.mongodb_database}")
    except (ServerSelectionTimeoutError, ConnectionFailure) as e:
        logger.warning(
            f"Failed to connect to MongoDB at {settings.mongodb_uri}. "
            f"Error: {e}"
        )
        print(f"⚠ WARNING: Could not connect to MongoDB at {settings.mongodb_uri}")
        print("  The application will start, but database operations will fail.")
        _client = None
        _database = None


async def _create_indexes() -> None:
    """Create database indexes for optimal query performance."""
    if _database is None:
        return
    
    async def safe_create_index(collection, keys, **kwargs):
        """Create an index, ignoring errors if it already exists."""
        try:
            await collection.create_index(keys, **kwargs)
        except DuplicateKeyError:
            # Index might conflict with existing data, skip
            logger.warning(f"Skipping index {keys} on {collection.name} due to duplicate key")
        except Exception as e:
            if "already exists" not in str(e).lower():
                logger.warning(f"Index creation warning for {keys}: {e}")
    
    try:
        # Users indexes
        await safe_create_index(_database.users, "email", unique=True)
        await safe_create_index(_database.users, "username", unique=True)
        
        # Preferences indexes
        await safe_create_index(_database.preferences, "user_id", unique=True)
        
        # Articles indexes (_id is automatically indexed by MongoDB)
        await safe_create_index(_database.articles, "source")
        await safe_create_index(_database.articles, [("published", -1)])
        await safe_create_index(_database.articles, "topics")
        
        # Interactions indexes
        await safe_create_index(_database.interactions, "user_id")
        await safe_create_index(_database.interactions, [("user_id", 1), ("created_at", -1)])
        await safe_create_index(_database.interactions, "article_id")
        
        # Digests indexes
        await safe_create_index(_database.digests, "user_id")
        await safe_create_index(_database.digests, [("user_id", 1), ("date", -1)])
        await safe_create_index(_database.digests, [("user_id", 1), ("date", 1)], unique=True)
        
        logger.info("Database indexes created successfully")
    except Exception as e:
        logger.error(f"Failed to create database indexes: {e}")
        # Don't raise - allow app to start even if some indexes fail


async def close_db() -> None:
    """Close the MongoDB connection."""
    global _client, _database
    
    if _client is not None:
        await _client.close()
        _client = None
        _database = None
        print("MongoDB connection closed")


def get_database() -> Database:
    """Get the database instance."""
    if _database is None:
        raise RuntimeError(
            "Database not initialized. MongoDB connection failed during startup. "
            "Please ensure MongoDB is running and accessible."
        )
    return _database
