"""
Article routes for browsing and searching articles.
"""
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status, Query

from app.middleware import require_auth
from app.services.news_service import NewsService


router = APIRouter(prefix="/api/articles", tags=["Articles"])
news_service = NewsService()


@router.get("")
async def get_articles(
    limit: int = Query(default=50, le=100),
    source: Optional[str] = None,
    topics: Optional[List[str]] = Query(default=None),
    current_user: dict = Depends(require_auth)
):
    """Get recent articles with optional filtering."""
    articles = await news_service.get_recent_articles(
        limit=limit,
        source=source,
        topics=topics
    )
    
    return {
        "articles": [a.to_response() for a in articles],
        "count": len(articles)
    }


@router.get("/search")
async def search_articles(
    q: str = Query(..., min_length=2),
    limit: int = Query(default=20, le=50),
    current_user: dict = Depends(require_auth)
):
    """Search articles by title or description."""
    articles = await news_service.search_articles(
        query=q,
        limit=limit
    )
    
    return {
        "query": q,
        "articles": [a.to_response() for a in articles],
        "count": len(articles)
    }


@router.get("/{article_id}")
async def get_article(
    article_id: str,
    current_user: dict = Depends(require_auth)
):
    """Get a specific article by ID."""
    article = await news_service.get_article(article_id)
    
    if not article:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Article not found"
        )
    
    return article.to_response()
