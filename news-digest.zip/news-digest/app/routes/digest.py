"""
Digest routes for generating and retrieving news digests.
"""
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import StreamingResponse
import json

from app.middleware import require_auth
from app.services.agent_service import AgentService
from app.services.digest_service import DigestService


router = APIRouter(prefix="/api/digest", tags=["Digest"])
agent_service = AgentService()
digest_service = DigestService()


@router.get("/today")
async def get_today_digest(
    refresh: bool = False,
    current_user: dict = Depends(require_auth)
):
    """
    Get today's personalized news digest.
    
    If refresh=True, regenerate the digest even if one exists.
    """
    result = await agent_service.generate_digest(
        user_id=current_user["user_id"],
        force_refresh=refresh
    )
    
    if not result["success"]:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=result.get("error", "Failed to generate digest")
        )
    
    return result


@router.get("/today/stream")
async def get_today_digest_stream(
    current_user: dict = Depends(require_auth)
):
    """
    Generate today's digest with streaming progress updates.
    
    Returns Server-Sent Events (SSE) with progress information.
    """
    async def event_generator():
        async for event in agent_service.generate_digest_streaming(
            user_id=current_user["user_id"]
        ):
            yield f"data: {json.dumps(event)}\n\n"
    
    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
        }
    )


@router.get("/history")
async def get_digest_history(
    limit: int = 30,
    current_user: dict = Depends(require_auth)
):
    """Get user's digest history."""
    digests = await digest_service.get_digest_history(
        user_id=current_user["user_id"],
        limit=limit
    )
    
    return {
        "digests": [d.to_response() for d in digests],
        "count": len(digests)
    }


@router.get("/stats")
async def get_digest_stats(
    current_user: dict = Depends(require_auth)
):
    """Get aggregate statistics about user's digests."""
    stats = await digest_service.get_digest_stats(
        user_id=current_user["user_id"]
    )
    
    return stats
