"""
Preferences routes for managing user preferences.
"""
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel

from app.middleware import require_auth
from app.services.preference_service import PreferenceService


router = APIRouter(prefix="/api/preferences", tags=["Preferences"])
preference_service = PreferenceService()


class UpdatePreferencesRequest(BaseModel):
    liked_topics: Optional[dict] = None
    dismissed_topics: Optional[dict] = None
    source_weights: Optional[dict] = None


class BlockSourceRequest(BaseModel):
    source: str


class CustomFeedRequest(BaseModel):
    name: str
    url: str


@router.get("")
async def get_preferences(
    current_user: dict = Depends(require_auth)
):
    """Get current user's preferences."""
    preferences = await preference_service.get_or_create_preferences(
        user_id=current_user["user_id"]
    )
    
    return preferences.to_response()


@router.put("")
async def update_preferences(
    request: UpdatePreferencesRequest,
    current_user: dict = Depends(require_auth)
):
    """Update user preferences manually."""
    updates = {}
    
    if request.liked_topics is not None:
        updates["liked_topics"] = request.liked_topics
    if request.dismissed_topics is not None:
        updates["dismissed_topics"] = request.dismissed_topics
    if request.source_weights is not None:
        updates["source_weights"] = request.source_weights
    
    if not updates:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No updates provided"
        )
    
    success = await preference_service.update_preferences(
        user_id=current_user["user_id"],
        updates=updates
    )
    
    if not success:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update preferences"
        )
    
    # Return updated preferences
    preferences = await preference_service.get_preferences(
        user_id=current_user["user_id"]
    )
    
    return preferences.to_response()


@router.post("/reset")
async def reset_preferences(
    current_user: dict = Depends(require_auth)
):
    """Reset all preferences to default values."""
    success = await preference_service.reset_preferences(
        user_id=current_user["user_id"]
    )
    
    return {"success": success, "message": "Preferences reset to defaults"}


@router.post("/block-source")
async def block_source(
    request: BlockSourceRequest,
    current_user: dict = Depends(require_auth)
):
    """Block a news source from appearing in digests."""
    success = await preference_service.block_source(
        user_id=current_user["user_id"],
        source=request.source
    )
    
    return {"success": success, "source": request.source, "action": "blocked"}


@router.post("/unblock-source")
async def unblock_source(
    request: BlockSourceRequest,
    current_user: dict = Depends(require_auth)
):
    """Unblock a previously blocked news source."""
    success = await preference_service.unblock_source(
        user_id=current_user["user_id"],
        source=request.source
    )
    
    return {"success": success, "source": request.source, "action": "unblocked"}


@router.post("/custom-feed")
async def add_custom_feed(
    request: CustomFeedRequest,
    current_user: dict = Depends(require_auth)
):
    """Add a custom RSS feed."""
    success = await preference_service.add_custom_feed(
        user_id=current_user["user_id"],
        feed_name=request.name,
        feed_url=request.url
    )
    
    return {"success": success, "feed_name": request.name, "action": "added"}


@router.delete("/custom-feed/{feed_name}")
async def remove_custom_feed(
    feed_name: str,
    current_user: dict = Depends(require_auth)
):
    """Remove a custom RSS feed."""
    success = await preference_service.remove_custom_feed(
        user_id=current_user["user_id"],
        feed_name=feed_name
    )
    
    return {"success": success, "feed_name": feed_name, "action": "removed"}
