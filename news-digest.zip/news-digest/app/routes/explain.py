"""
Explain routes for ELI5 (Explain Like I'm 5) article explanations.
"""
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from typing import Optional

from app.middleware import require_auth
from app.services.explain_service import ExplainService


router = APIRouter(prefix="/api/explain", tags=["Explain"])
explain_service = ExplainService()


class ExplainRequest(BaseModel):
    """Request for explanation."""
    complexity_level: str = "eli5"  # eli5, simple, detailed


@router.get("/{article_id}")
async def explain_article(
    article_id: str,
    level: str = "eli5",
    current_user: dict = Depends(require_auth)
):
    """
    Get a simplified explanation of an article.
    
    Levels:
    - eli5: Explain Like I'm 5 (very simple)
    - simple: Plain language, no jargon
    - detailed: Full explanation with background
    """
    result = await explain_service.explain_article(
        article_id=article_id,
        user_id=current_user["user_id"],
        level=level
    )
    
    if not result["success"]:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=result.get("error", "Failed to generate explanation")
        )
    
    return result


@router.post("/{article_id}/topic")
async def explain_topic(
    article_id: str,
    topic: str,
    current_user: dict = Depends(require_auth)
):
    """
    Explain a specific topic or term mentioned in an article.
    """
    result = await explain_service.explain_topic(
        article_id=article_id,
        topic=topic,
        user_id=current_user["user_id"]
    )
    
    if not result["success"]:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=result.get("error", "Failed to explain topic")
        )
    
    return result
