"""
Audio routes for TTS (Text-to-Speech) news summaries.
"""
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import Optional

from app.middleware import require_auth
from app.services.audio_service import AudioService


router = APIRouter(prefix="/api/audio", tags=["Audio"])
audio_service = AudioService()


class AudioRequest(BaseModel):
    """Request for audio generation."""
    style: str = "briefing"  # briefing, casual, detailed


@router.get("/today")
async def get_audio_digest(
    style: str = "briefing",
    current_user: dict = Depends(require_auth)
):
    """
    Get a spoken audio script for today's news digest.
    
    Styles:
    - briefing: Professional news briefing style
    - casual: Casual, conversational tone
    - detailed: More thorough coverage
    
    Returns the text script that can be used with Web Speech API
    or other TTS services on the client side.
    """
    result = await audio_service.generate_audio_script(
        user_id=current_user["user_id"],
        style=style
    )
    
    if not result["success"]:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=result.get("error", "Failed to generate audio script")
        )
    
    return result


@router.get("/article/{article_id}")
async def get_article_audio(
    article_id: str,
    current_user: dict = Depends(require_auth)
):
    """
    Get a spoken summary of a specific article.
    """
    result = await audio_service.generate_article_audio(
        article_id=article_id,
        user_id=current_user["user_id"]
    )
    
    if not result["success"]:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=result.get("error", "Failed to generate article audio")
        )
    
    return result


@router.get("/headlines")
async def get_headlines_audio(
    count: int = 5,
    current_user: dict = Depends(require_auth)
):
    """
    Get a quick audio summary of top headlines.
    """
    result = await audio_service.generate_headlines_audio(
        user_id=current_user["user_id"],
        count=count
    )
    
    if not result["success"]:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=result.get("error", "Failed to generate headlines audio")
        )
    
    return result
