"""
Chat routes for conversational Q&A about news articles.
"""
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from typing import List, Optional
import json

from app.middleware import require_auth
from app.services.chat_service import ChatService
from app.services.digest_service import DigestService


router = APIRouter(prefix="/api/chat", tags=["Chat"])
chat_service = ChatService()
digest_service = DigestService()


class ChatMessage(BaseModel):
    """Single chat message."""
    role: str  # "user" or "assistant"
    content: str


class ChatRequest(BaseModel):
    """Chat request with conversation history."""
    message: str
    conversation_history: List[ChatMessage] = []
    article_id: Optional[str] = None  # Context to a specific article


class ChatResponse(BaseModel):
    """Chat response."""
    response: str
    conversation_history: List[ChatMessage]


@router.post("")
async def chat(
    request: ChatRequest,
    current_user: dict = Depends(require_auth)
):
    """
    Chat with the AI about today's news digest.
    
    The AI has context of:
    - Today's personalized digest
    - Specific article if article_id is provided
    - Previous conversation history
    """
    result = await chat_service.chat(
        user_id=current_user["user_id"],
        message=request.message,
        conversation_history=[m.model_dump() for m in request.conversation_history],
        article_id=request.article_id
    )
    
    if not result["success"]:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=result.get("error", "Chat failed")
        )
    
    return result


@router.post("/stream")
async def chat_stream(
    request: ChatRequest,
    current_user: dict = Depends(require_auth)
):
    """
    Stream chat response for real-time typing effect.
    """
    async def event_generator():
        async for chunk in chat_service.chat_streaming(
            user_id=current_user["user_id"],
            message=request.message,
            conversation_history=[m.model_dump() for m in request.conversation_history],
            article_id=request.article_id
        ):
            yield f"data: {json.dumps(chunk)}\n\n"
    
    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
        }
    )


@router.delete("/history")
async def clear_chat_history(
    current_user: dict = Depends(require_auth)
):
    """Clear the user's chat history."""
    await chat_service.clear_history(user_id=current_user["user_id"])
    return {"success": True, "message": "Chat history cleared"}
