"""
Interaction routes for tracking user interactions with articles.
"""
from typing import List, Literal
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel

from app.middleware import require_auth
from app.services.preference_service import PreferenceService
from app.services.digest_service import DigestService


router = APIRouter(prefix="/api/interactions", tags=["Interactions"])
preference_service = PreferenceService()
digest_service = DigestService()


class InteractionRequest(BaseModel):
    article_id: str
    action: Literal["click", "like", "dismiss", "save", "read"]
    article_title: str = ""
    article_topics: List[str] = []
    article_source: str = ""
    time_spent_seconds: int = None
    digest_date: str = None  # For updating digest stats


@router.post("")
async def record_interaction(
    request: InteractionRequest,
    current_user: dict = Depends(require_auth)
):
    """
    Record a user interaction with an article.
    
    This updates user preferences based on the interaction type:
    - click: Small boost to topic interest
    - like: Medium boost to topic and source
    - dismiss: Increases dismissed topic weight
    - save: Large boost to topic interest
    - read: Small boost similar to click
    """
    result = await preference_service.record_interaction(
        user_id=current_user["user_id"],
        article_id=request.article_id,
        action=request.action,
        article_title=request.article_title,
        article_topics=request.article_topics,
        article_source=request.article_source,
        time_spent_seconds=request.time_spent_seconds
    )
    
    # Update digest stats if digest_date provided
    if request.digest_date:
        await digest_service.update_digest_stats(
            user_id=current_user["user_id"],
            digest_date=request.digest_date,
            action=request.action
        )
    
    return result


@router.get("/history")
async def get_interaction_history(
    limit: int = 50,
    current_user: dict = Depends(require_auth)
):
    """Get user's recent interaction history."""
    interactions = await preference_service.get_interaction_history(
        user_id=current_user["user_id"],
        limit=limit
    )
    
    return {
        "interactions": interactions,
        "count": len(interactions)
    }
