"""
API routes for the News Digest application.
"""
from .auth import router as auth_router
from .digest import router as digest_router
from .articles import router as articles_router
from .preferences import router as preferences_router
from .interactions import router as interactions_router
from .chat import router as chat_router
from .explain import router as explain_router
from .audio import router as audio_router

__all__ = [
    "auth_router",
    "digest_router",
    "articles_router",
    "preferences_router",
    "interactions_router",
    "chat_router",
    "explain_router",
    "audio_router",
]
