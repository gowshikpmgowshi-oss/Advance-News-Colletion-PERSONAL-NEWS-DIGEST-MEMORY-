"""
News Digest - FastAPI Application.
"""
