"""
Authentication service for user management.
"""
from datetime import datetime, timedelta
from typing import Optional, Dict, Any

import bcrypt
from jose import jwt, JWTError

from app.config import settings
from app.database import get_database
from app.models.user import UserModel
from app.models.preference import PreferenceModel


class AuthService:
    """Service for authentication and user management."""
    
    def __init__(self):
        self.db = None
    
    def _get_db(self):
        if self.db is None:
            self.db = get_database()
        return self.db
    
    def hash_password(self, password: str) -> str:
        """Hash a password using bcrypt."""
        hashed = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
        return hashed.decode('utf-8')
    
    def verify_password(self, plain_password: str, hashed_password: str) -> bool:
        """Verify a password against its hash."""
        return bcrypt.checkpw(
            plain_password.encode('utf-8'),
            hashed_password.encode('utf-8')
        )
    
    def create_access_token(self, user_id: str, email: str) -> str:
        """Create a JWT access token."""
        expire = datetime.utcnow() + timedelta(hours=settings.jwt_expiration_hours)
        payload = {
            "sub": user_id,
            "email": email,
            "exp": expire,
            "iat": datetime.utcnow()
        }
        return jwt.encode(
            payload,
            settings.jwt_secret_key,
            algorithm=settings.jwt_algorithm
        )
    
    def verify_token(self, token: str) -> Optional[Dict[str, Any]]:
        """Verify and decode a JWT token."""
        try:
            payload = jwt.decode(
                token,
                settings.jwt_secret_key,
                algorithms=[settings.jwt_algorithm]
            )
            return payload
        except JWTError:
            return None
    
    async def register_user(
        self,
        email: str,
        username: str,
        password: str
    ) -> Dict[str, Any]:
        """Register a new user."""
        db = self._get_db()
        
        # Check if email already exists
        existing_email = await db.users.find_one({"email": email})
        if existing_email:
            return {"success": False, "error": "Email already registered"}
        
        # Check if username already exists
        existing_username = await db.users.find_one({"username": username})
        if existing_username:
            return {"success": False, "error": "Username already taken"}
        
        # Create user
        user = UserModel(
            email=email,
            username=username,
            password_hash=self.hash_password(password)
        )
        
        result = await db.users.insert_one(user.to_dict())
        user_id = str(result.inserted_id)
        
        # Create default preferences for the user
        preferences = PreferenceModel.create_default(user_id)
        await db.preferences.insert_one(preferences.to_dict())
        
        # Create access token
        token = self.create_access_token(user_id, email)
        
        return {
            "success": True,
            "user": {
                "id": user_id,
                "email": email,
                "username": username
            },
            "access_token": token,
            "token_type": "bearer"
        }
    
    async def login_user(
        self,
        email: str,
        password: str
    ) -> Dict[str, Any]:
        """Authenticate a user."""
        db = self._get_db()
        
        # Find user by email
        user_doc = await db.users.find_one({"email": email})
        if not user_doc:
            return {"success": False, "error": "Invalid email or password"}
        
        # Verify password
        if not self.verify_password(password, user_doc["password_hash"]):
            return {"success": False, "error": "Invalid email or password"}
        
        user_id = str(user_doc["_id"])
        
        # Create access token
        token = self.create_access_token(user_id, email)
        
        return {
            "success": True,
            "user": {
                "id": user_id,
                "email": email,
                "username": user_doc["username"]
            },
            "access_token": token,
            "token_type": "bearer"
        }
    
    async def get_user_by_id(self, user_id: str) -> Optional[UserModel]:
        """Get a user by their ID."""
        from bson import ObjectId
        
        db = self._get_db()
        
        try:
            user_doc = await db.users.find_one({"_id": ObjectId(user_id)})
            if user_doc:
                user_doc["_id"] = str(user_doc["_id"])
                return UserModel(**user_doc)
        except Exception:
            pass
        
        return None
    
    async def update_user(
        self,
        user_id: str,
        updates: Dict[str, Any]
    ) -> bool:
        """Update user data."""
        from bson import ObjectId
        
        db = self._get_db()
        
        # Don't allow updating sensitive fields
        updates.pop("password_hash", None)
        updates.pop("email", None)
        updates["updated_at"] = datetime.utcnow()
        
        result = await db.users.update_one(
            {"_id": ObjectId(user_id)},
            {"$set": updates}
        )
        
        return result.modified_count > 0
