"""
Explain service for ELI5 (Explain Like I'm 5) explanations.
"""
from typing import Dict, Any

from google import genai
from google.genai import types

from app.config import settings
from app.services.news_service import NewsService
from news_agent.config import config as agent_config
from news_agent.tools import extract_article_text


class ExplainService:
    """Service for generating simplified explanations of articles."""
    
    def __init__(self):
        self.client = genai.Client(api_key=settings.google_api_key)
        self.model = agent_config.main_model
        self.news_service = NewsService()
        self._article_cache = {}  # Cache fetched article content
    
    async def explain_article(
        self,
        article_id: str,
        user_id: str,
        level: str = "eli5"
    ) -> Dict[str, Any]:
        """
        Generate a simplified explanation of an article.
        
        Args:
            article_id: Article to explain
            user_id: User requesting explanation
            level: Complexity level (eli5, simple, detailed)
            
        Returns:
            Explanation response
        """
        # Get the article
        article = await self.news_service.get_article_by_id(article_id)
        if not article:
            return {
                "success": False,
                "error": "Article not found"
            }
        
        # Fetch full article content for simple and detailed levels
        full_text = ""
        if level in ["simple", "detailed"] and article.link:
            full_text = await self._get_full_article_text(article.link)
        
        # Build prompt based on level
        level_instructions = {
            "eli5": """Write a clear, simple summary of this news article that anyone can understand.

Requirements:
- Use plain, everyday language (no jargon)
- Explain WHO is involved, WHAT happened, and WHY it matters
- If there are technical terms, briefly explain them in parentheses
- Keep it to 4-6 sentences
- Be informative, not childish - write for an intelligent person who just wants the basics quickly

Do NOT use silly analogies or talk down to the reader. Just explain clearly.""",
            
            "simple": """Provide a clear, complete summary of this news article.

Requirements:
- Cover ALL the key facts from the article
- Explain WHO, WHAT, WHEN, WHERE, WHY, and HOW
- Use clear, accessible language
- Define any technical terms or acronyms
- Include important quotes or statistics if present
- Explain the significance/implications
- Use bullet points for clarity
- Length: 150-200 words

Make sure no important information is left out.""",
            
            "detailed": """Provide a comprehensive explanation of this news article.

Structure your response with these sections:
- **Summary**: 2-3 sentence overview
- **Key Facts**: All important details as bullet points
- **Background**: Context and what led to this
- **Key Players**: Who is involved and their roles
- **Why It Matters**: Significance and implications
- **What's Next**: Expected developments if mentioned

Requirements:
- Include ALL facts from the article
- Define technical terms
- Use markdown formatting
- Be thorough (300-500 words)"""
        }
        
        instruction = level_instructions.get(level, level_instructions["eli5"])
        
        # Build content section based on what we have
        content_section = f"""Article Title: {article.title}
Source: {article.source}
Topics: {', '.join(article.topics)}
Summary: {article.summary}"""

        if article.description and article.description != article.summary:
            content_section += f"\nDescription: {article.description}"
        
        if full_text:
            content_section += f"\n\n--- Full Article Content ---\n{full_text[:3000]}"
        
        prompt = f"""{instruction}

{content_section}

Provide your explanation:"""

        try:
            response = self.client.models.generate_content(
                model=self.model,
                contents=prompt
            )
            
            return {
                "success": True,
                "article_id": article_id,
                "level": level,
                "explanation": response.text,
                "article_title": article.title,
                "has_full_text": bool(full_text)
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    async def _get_full_article_text(self, url: str) -> str:
        """Fetch full article text from URL with caching."""
        if url in self._article_cache:
            return self._article_cache[url]
        
        try:
            result = await extract_article_text(url)
            if result.get("status") == "success":
                text = result.get("text", "")
                self._article_cache[url] = text
                return text
        except Exception as e:
            print(f"Failed to fetch article text: {e}")
        
        return ""
    
    async def explain_topic(
        self,
        article_id: str,
        topic: str,
        user_id: str
    ) -> Dict[str, Any]:
        """
        Explain a specific topic mentioned in an article.
        
        Args:
            article_id: Article containing the topic
            topic: Topic or term to explain
            user_id: User requesting explanation
            
        Returns:
            Topic explanation
        """
        # Get article for context
        article = await self.news_service.get_article_by_id(article_id)
        
        article_context = ""
        if article:
            article_context = f"""
This topic appears in an article about: {article.title}
Article summary: {article.summary[:200]}
"""
        
        prompt = f"""Explain the following topic/term in simple, clear language:

Topic: {topic}
{article_context}

Provide:
1. A one-sentence definition
2. A simple analogy or example
3. Why it matters in this context (1-2 sentences)

Keep the total explanation under 100 words."""

        try:
            response = self.client.models.generate_content(
                model=self.model,
                contents=prompt
            )
            
            return {
                "success": True,
                "topic": topic,
                "article_id": article_id,
                "explanation": response.text
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
