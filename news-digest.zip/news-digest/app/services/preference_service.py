"""
Preference service for managing user preferences and learning from interactions.
"""
from datetime import datetime
from typing import Dict, Any, List, Optional

from bson import ObjectId

from app.database import get_database
from app.models.preference import PreferenceModel
from app.models.interaction import InteractionModel, INTERACTION_WEIGHTS


class PreferenceService:
    """Service for managing user preferences."""
    
    def __init__(self):
        self.db = None
    
    def _get_db(self):
        if self.db is None:
            self.db = get_database()
        return self.db
    
    async def get_preferences(self, user_id: str) -> Optional[PreferenceModel]:
        """Get user preferences."""
        db = self._get_db()
        
        pref_doc = await db.preferences.find_one({"user_id": user_id})
        if pref_doc:
            pref_doc["_id"] = str(pref_doc["_id"])
            return PreferenceModel(**pref_doc)
        
        return None
    
    async def get_or_create_preferences(self, user_id: str) -> PreferenceModel:
        """Get existing preferences or create default ones."""
        preferences = await self.get_preferences(user_id)
        
        if preferences is None:
            preferences = PreferenceModel.create_default(user_id)
            db = self._get_db()
            await db.preferences.insert_one(preferences.to_dict())
        
        return preferences
    
    async def update_preferences(
        self,
        user_id: str,
        updates: Dict[str, Any]
    ) -> bool:
        """Update user preferences."""
        db = self._get_db()
        
        updates["updated_at"] = datetime.utcnow()
        
        result = await db.preferences.update_one(
            {"user_id": user_id},
            {"$set": updates}
        )
        
        return result.modified_count > 0
    
    async def record_interaction(
        self,
        user_id: str,
        article_id: str,
        action: str,
        article_title: str = "",
        article_topics: List[str] = None,
        article_source: str = "",
        time_spent_seconds: int = None
    ) -> Dict[str, Any]:
        """
        Record a user interaction and update preferences accordingly.
        
        This is the core of the preference learning algorithm.
        """
        db = self._get_db()
        
        if article_topics is None:
            article_topics = []
        
        # Create interaction record
        interaction = InteractionModel(
            user_id=user_id,
            article_id=article_id,
            action=action,
            article_title=article_title,
            article_topics=article_topics,
            article_source=article_source,
            time_spent_seconds=time_spent_seconds
        )
        
        await db.interactions.insert_one(interaction.to_dict())
        
        # Get current preferences
        preferences = await self.get_or_create_preferences(user_id)
        
        # Calculate weight adjustments based on action
        weights = INTERACTION_WEIGHTS.get(action, {})
        
        updates = {}
        
        # Update liked_topics
        if "liked_topics" in weights:
            delta = weights["liked_topics"]
            liked = dict(preferences.liked_topics)
            for topic in article_topics:
                liked[topic] = min(liked.get(topic, 0) + delta, 2.0)  # Cap at 2.0
            updates["liked_topics"] = liked
        
        # Update dismissed_topics
        if "dismissed_topics" in weights:
            delta = weights["dismissed_topics"]
            dismissed = dict(preferences.dismissed_topics)
            for topic in article_topics:
                dismissed[topic] = min(dismissed.get(topic, 0) + delta, 2.0)
            updates["dismissed_topics"] = dismissed
        
        # Update source_weights
        if "source_weights" in weights and article_source:
            delta = weights["source_weights"]
            sources = dict(preferences.source_weights)
            sources[article_source] = min(sources.get(article_source, 0) + delta, 2.0)
            updates["source_weights"] = sources
        
        # Apply updates
        if updates:
            await self.update_preferences(user_id, updates)
        
        # Update article stats
        stat_field = {
            "click": "view_count",
            "like": "like_count",
            "dismiss": "dismiss_count",
            "save": "save_count",
            "read": "view_count"
        }.get(action)
        
        if stat_field:
            await db.articles.update_one(
                {"_id": article_id},
                {"$inc": {stat_field: 1}}
            )
        
        return {
            "success": True,
            "action": action,
            "article_id": article_id,
            "preferences_updated": bool(updates)
        }
    
    async def get_interaction_history(
        self,
        user_id: str,
        limit: int = 50
    ) -> List[Dict[str, Any]]:
        """Get user's recent interaction history."""
        db = self._get_db()
        
        cursor = db.interactions.find(
            {"user_id": user_id}
        ).sort("created_at", -1).limit(limit)
        
        interactions = []
        async for doc in cursor:
            doc["_id"] = str(doc["_id"])
            interaction = InteractionModel(**doc)
            interactions.append(interaction.to_response())
        
        return interactions
    
    async def block_source(self, user_id: str, source: str) -> bool:
        """Add a source to the blocked list."""
        db = self._get_db()
        
        result = await db.preferences.update_one(
            {"user_id": user_id},
            {
                "$addToSet": {"blocked_sources": source},
                "$set": {"updated_at": datetime.utcnow()}
            }
        )
        
        return result.modified_count > 0
    
    async def unblock_source(self, user_id: str, source: str) -> bool:
        """Remove a source from the blocked list."""
        db = self._get_db()
        
        result = await db.preferences.update_one(
            {"user_id": user_id},
            {
                "$pull": {"blocked_sources": source},
                "$set": {"updated_at": datetime.utcnow()}
            }
        )
        
        return result.modified_count > 0
    
    async def add_custom_feed(
        self,
        user_id: str,
        feed_name: str,
        feed_url: str
    ) -> bool:
        """Add a custom RSS feed for the user."""
        db = self._get_db()
        
        result = await db.preferences.update_one(
            {"user_id": user_id},
            {
                "$set": {
                    f"custom_feeds.{feed_name}": feed_url,
                    "updated_at": datetime.utcnow()
                }
            }
        )
        
        return result.modified_count > 0
    
    async def remove_custom_feed(self, user_id: str, feed_name: str) -> bool:
        """Remove a custom RSS feed."""
        db = self._get_db()
        
        result = await db.preferences.update_one(
            {"user_id": user_id},
            {
                "$unset": {f"custom_feeds.{feed_name}": ""},
                "$set": {"updated_at": datetime.utcnow()}
            }
        )
        
        return result.modified_count > 0
    
    async def reset_preferences(self, user_id: str) -> bool:
        """Reset all preferences to default values."""
        db = self._get_db()
        
        default = PreferenceModel.create_default(user_id)
        
        result = await db.preferences.replace_one(
            {"user_id": user_id},
            default.to_dict()
        )
        
        return result.modified_count > 0
