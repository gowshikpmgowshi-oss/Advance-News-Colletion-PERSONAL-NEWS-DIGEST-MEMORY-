"""
News service for fetching and managing articles.
"""
from datetime import datetime
from typing import Dict, Any, List, Optional

from app.database import get_database
from app.models.article import ArticleModel
from news_agent.tools import fetch_all_feeds, fetch_rss_feed
from news_agent.config import config as agent_config


class NewsService:
    """Service for fetching and managing news articles."""
    
    def __init__(self):
        self.db = None
    
    def _get_db(self):
        if self.db is None:
            self.db = get_database()
        return self.db
    
    async def fetch_latest_news(
        self,
        custom_feeds: Dict[str, str] = None
    ) -> Dict[str, Any]:
        """
        Fetch latest news from all configured RSS feeds.
        
        Args:
            custom_feeds: Optional additional feeds to include
            
        Returns:
            Dictionary with fetched articles
        """
        # Combine default feeds with custom feeds
        feeds = dict(agent_config.default_feeds)
        if custom_feeds:
            feeds.update(custom_feeds)
        
        # Fetch from all feeds
        result = fetch_all_feeds(feeds)
        
        return result
    
    async def save_articles(
        self,
        articles: List[Dict[str, Any]]
    ) -> List[str]:
        """
        Save articles to the database.
        
        Args:
            articles: List of article dictionaries
            
        Returns:
            List of saved article IDs
        """
        db = self._get_db()
        saved_ids = []
        
        for article_data in articles:
            # Parse published date if string
            published = article_data.get("published")
            if isinstance(published, str):
                try:
                    published = datetime.fromisoformat(published.replace("Z", "+00:00"))
                except (ValueError, TypeError):
                    published = datetime.utcnow()
            
            article = ArticleModel(
                id=article_data.get("id"),
                title=article_data.get("title", "Untitled"),
                link=article_data.get("link", ""),
                source=article_data.get("source", "unknown"),
                published=published,
                description=article_data.get("description", ""),
                summary=article_data.get("summary", ""),
                tldr=article_data.get("tldr", ""),
                topics=article_data.get("topics", []),
                image_url=article_data.get("image_url"),
                # AI Analysis fields
                sentiment=article_data.get("sentiment"),
                sentiment_score=float(article_data.get("sentiment_score", 0.0)),
                bias=article_data.get("bias"),
                bias_explanation=article_data.get("bias_explanation", ""),
                is_breaking=bool(article_data.get("is_breaking", False)),
                breaking_score=float(article_data.get("breaking_score", 0.0)),
                related_ids=article_data.get("related_ids", []),
            )
            
            # Upsert article (update if exists, insert if not)
            await db.articles.update_one(
                {"_id": article.id},
                {"$set": article.to_dict()},
                upsert=True
            )
            saved_ids.append(article.id)
        
        return saved_ids
    
    async def get_article(self, article_id: str) -> Optional[ArticleModel]:
        """Get an article by ID."""
        db = self._get_db()
        
        doc = await db.articles.find_one({"_id": article_id})
        if doc:
            doc["id"] = doc.pop("_id")
            return ArticleModel(**doc)
        
        return None
    
    # Alias for compatibility
    async def get_article_by_id(self, article_id: str) -> Optional[ArticleModel]:
        """Alias for get_article."""
        return await self.get_article(article_id)
    
    async def get_recent_articles(
        self,
        limit: int = 50,
        source: str = None,
        topics: List[str] = None
    ) -> List[ArticleModel]:
        """Get recent articles with optional filtering."""
        db = self._get_db()
        
        query = {}
        if source:
            query["source"] = source
        if topics:
            query["topics"] = {"$in": topics}
        
        cursor = db.articles.find(query).sort("published", -1).limit(limit)
        
        articles = []
        async for doc in cursor:
            doc["id"] = doc.pop("_id")
            articles.append(ArticleModel(**doc))
        
        return articles
    
    async def search_articles(
        self,
        query: str,
        limit: int = 20
    ) -> List[ArticleModel]:
        """Search articles by title or description."""
        db = self._get_db()
        
        # Simple text search
        cursor = db.articles.find({
            "$or": [
                {"title": {"$regex": query, "$options": "i"}},
                {"description": {"$regex": query, "$options": "i"}}
            ]
        }).sort("published", -1).limit(limit)
        
        articles = []
        async for doc in cursor:
            doc["id"] = doc.pop("_id")
            articles.append(ArticleModel(**doc))
        
        return articles
