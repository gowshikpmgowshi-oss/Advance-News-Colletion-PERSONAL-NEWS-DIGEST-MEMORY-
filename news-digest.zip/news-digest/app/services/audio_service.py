"""
Audio service for generating TTS scripts for news digests.
"""
from datetime import datetime
from typing import Dict, Any, List

from google import genai

from app.config import settings
from app.services.digest_service import DigestService
from app.services.news_service import NewsService
from news_agent.config import config as agent_config


class AudioService:
    """Service for generating audio-ready scripts for news."""
    
    def __init__(self):
        self.client = genai.Client(api_key=settings.google_api_key)
        self.model = agent_config.main_model
        self.digest_service = DigestService()
        self.news_service = NewsService()
    
    async def generate_audio_script(
        self,
        user_id: str,
        style: str = "briefing"
    ) -> Dict[str, Any]:
        """
        Generate a spoken script for today's news digest.
        
        Args:
            user_id: User ID
            style: briefing, casual, or detailed
            
        Returns:
            Audio script ready for TTS
        """
        # Get today's digest
        digest = await self.digest_service.get_today_digest(user_id)
        
        if not digest or not digest.articles:
            return {
                "success": False,
                "error": "No digest available for today. Generate a digest first."
            }
        
        # Prepare articles summary
        articles_text = self._format_articles_for_speech(digest.articles)
        
        # Style-specific instructions
        style_prompts = {
            "briefing": """Write a professional news briefing script like a morning radio host would read.
- Start with a greeting and today's date
- Use clear, broadcast-style language
- Transition smoothly between stories
- End with a brief sign-off
- Duration: ~2 minutes of speech (~300 words)""",

            "casual": """Write a casual, friendly news update like you're telling a friend about the day's news.
- Start with a casual greeting
- Use conversational language
- Add brief commentary or context
- Make it engaging and relatable
- Duration: ~2 minutes of speech (~300 words)""",

            "detailed": """Write a comprehensive news summary covering all major stories in depth.
- Professional but accessible tone
- Include more context and background
- Connect related stories
- Provide analysis where appropriate
- Duration: ~4 minutes of speech (~600 words)"""
        }
        
        instruction = style_prompts.get(style, style_prompts["briefing"])
        today = datetime.utcnow().strftime("%A, %B %d, %Y")
        
        prompt = f"""{instruction}

Today is {today}.

Here are the news stories to cover:

{articles_text}

Write the script that will be read aloud. Use natural speech patterns, include pauses (indicated by "..."), and make it sound natural when spoken.

IMPORTANT: Write ONLY the spoken script, no stage directions or notes."""

        try:
            response = self.client.models.generate_content(
                model=self.model,
                contents=prompt
            )
            
            script = response.text
            
            # Estimate duration (average 150 words per minute)
            word_count = len(script.split())
            estimated_duration = round(word_count / 150, 1)
            
            return {
                "success": True,
                "script": script,
                "style": style,
                "word_count": word_count,
                "estimated_duration_minutes": estimated_duration,
                "article_count": len(digest.articles),
                "generated_at": datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    async def generate_article_audio(
        self,
        article_id: str,
        user_id: str
    ) -> Dict[str, Any]:
        """
        Generate a spoken summary of a specific article.
        """
        article = await self.news_service.get_article_by_id(article_id)
        
        if not article:
            return {
                "success": False,
                "error": "Article not found"
            }
        
        prompt = f"""Write a brief spoken summary of this news article for audio playback.
Make it sound natural when read aloud, about 30-45 seconds of speech (~75-100 words).

Article: {article.title}
Source: {article.source}
Summary: {article.summary}

Write ONLY the spoken text, starting with the headline and source."""

        try:
            response = self.client.models.generate_content(
                model=self.model,
                contents=prompt
            )
            
            script = response.text
            word_count = len(script.split())
            
            return {
                "success": True,
                "article_id": article_id,
                "article_title": article.title,
                "script": script,
                "word_count": word_count,
                "estimated_duration_seconds": round(word_count / 2.5)  # ~150 wpm
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    async def generate_headlines_audio(
        self,
        user_id: str,
        count: int = 5
    ) -> Dict[str, Any]:
        """
        Generate a quick headlines-only audio script.
        """
        digest = await self.digest_service.get_today_digest(user_id)
        
        if not digest or not digest.articles:
            return {
                "success": False,
                "error": "No digest available for today."
            }
        
        # Get top articles (breaking news first, then by relevance)
        articles = sorted(
            digest.articles,
            key=lambda a: (getattr(a, 'is_breaking', False), a.relevance_score),
            reverse=True
        )[:count]
        
        headlines = [f"{i+1}. {a.title}" for i, a in enumerate(articles)]
        headlines_text = "\n".join(headlines)
        
        today = datetime.utcnow().strftime("%A, %B %d")
        
        prompt = f"""Write a quick headlines briefing for audio playback.
Read these headlines in a clear, professional news anchor style.
Add brief natural transitions between headlines.
Duration: ~30 seconds (~75 words)

Headlines for {today}:
{headlines_text}

Write ONLY the spoken script."""

        try:
            response = self.client.models.generate_content(
                model=self.model,
                contents=prompt
            )
            
            script = response.text
            
            return {
                "success": True,
                "script": script,
                "headline_count": len(articles),
                "word_count": len(script.split()),
                "estimated_duration_seconds": round(len(script.split()) / 2.5)
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def _format_articles_for_speech(self, articles) -> str:
        """Format articles into a text block for script generation."""
        formatted = []
        
        # Sort: breaking news first
        sorted_articles = sorted(
            articles,
            key=lambda a: (getattr(a, 'is_breaking', False), a.relevance_score),
            reverse=True
        )
        
        for i, article in enumerate(sorted_articles[:10], 1):
            breaking = "[BREAKING] " if getattr(article, 'is_breaking', False) else ""
            sentiment = getattr(article, 'sentiment', 'neutral')
            
            formatted.append(f"""
Story {i}: {breaking}{article.title}
Source: {article.source}
Topics: {', '.join(article.topics)}
Sentiment: {sentiment}
Summary: {article.summary}
""")
        
        return "\n".join(formatted)
