"""
Agent service for interacting with the ADK news digest agent.
"""
import json
import asyncio
from datetime import datetime
from typing import Dict, Any, List, Optional, AsyncGenerator

from google import genai
from google.genai import types
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService

from app.config import settings
from app.database import get_database
from app.services.news_service import NewsService
from app.services.preference_service import PreferenceService
from app.services.digest_service import DigestService
from news_agent.agent import root_agent, parse_json_response
from news_agent.config import config as agent_config
from news_agent.tools import fetch_all_feeds, rank_articles


class AgentService:
    """Service for AI-powered news digest generation using ADK agents."""
    
    def __init__(self):
        self.client = genai.Client(api_key=settings.google_api_key)
        self.model = agent_config.main_model
        self.news_service = NewsService()
        self.preference_service = PreferenceService()
        self.digest_service = DigestService()
        self.session_service = InMemorySessionService()
        self.runner = Runner(
            agent=root_agent,
            app_name="news_digest",
            session_service=self.session_service
        )
    
    def _create_user_message(self, text: str) -> types.Content:
        """Create a properly formatted user message for ADK Runner."""
        return types.Content(
            role="user",
            parts=[types.Part(text=text)]
        )
    
    async def generate_digest(
        self,
        user_id: str,
        force_refresh: bool = False
    ) -> Dict[str, Any]:
        """
        Generate a personalized news digest for the user.
        
        Args:
            user_id: User ID
            force_refresh: If True, regenerate even if today's digest exists
            
        Returns:
            Dictionary with digest data
        """
        # Check if we already have today's digest
        if not force_refresh:
            existing = await self.digest_service.get_today_digest(user_id)
            if existing:
                return {
                    "success": True,
                    "cached": True,
                    "digest": existing.to_response()
                }
        
        # Get user preferences
        preferences = await self.preference_service.get_or_create_preferences(user_id)
        
        # Fetch latest news
        feeds = dict(agent_config.default_feeds)
        if preferences.custom_feeds:
            feeds.update(preferences.custom_feeds)
        
        news_result = fetch_all_feeds(feeds)
        
        if not news_result.get("articles"):
            return {
                "success": False,
                "error": "Could not fetch news articles"
            }
        
        raw_articles = news_result["articles"]
        
        # Use ADK agent for summarization and classification
        try:
            processed_articles = await self._process_with_agent(
                raw_articles[:30],  # Limit to 30 articles for processing
                user_id
            )
        except Exception as e:
            print(f"ADK agent failed, using fallback: {e}")
            processed_articles = await self._process_direct(raw_articles[:30])
        
        # Personalize articles based on preferences
        personalized = rank_articles(
            processed_articles,
            preferences.to_response(),
            max_articles=agent_config.max_articles_per_digest
        )
        
        # Save articles to database
        await self.news_service.save_articles(personalized)
        
        # Save digest
        digest = await self.digest_service.save_digest(
            user_id=user_id,
            articles=personalized
        )
        
        return {
            "success": True,
            "cached": False,
            "digest": digest.to_response()
        }
    
    async def generate_digest_streaming(
        self,
        user_id: str
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """
        Generate a personalized digest with streaming progress updates.
        """
        yield {
            "type": "status",
            "message": "Fetching latest news...",
            "phase": "fetching"
        }
        
        # Get user preferences
        preferences = await self.preference_service.get_or_create_preferences(user_id)
        
        # Fetch news
        feeds = dict(agent_config.default_feeds)
        if preferences.custom_feeds:
            feeds.update(preferences.custom_feeds)
        
        news_result = fetch_all_feeds(feeds)
        
        if not news_result.get("articles"):
            yield {
                "type": "error",
                "message": "Could not fetch news articles"
            }
            return
        
        yield {
            "type": "status",
            "message": f"Fetched {len(news_result['articles'])} articles",
            "phase": "processing"
        }
        
        raw_articles = news_result["articles"][:30]
        
        # Show articles being prepared for AI
        yield {
            "type": "status",
            "message": "Preparing articles for AI analysis...",
            "phase": "ai_processing"
        }
        
        # Emit each article as it's being prepared
        for i, article in enumerate(raw_articles):
            yield {
                "type": "article_processed",
                "article_number": i + 1,
                "total": len(raw_articles),
                "title": article.get("title", "")[:50]
            }
            await asyncio.sleep(0.02)  # Small delay for visual effect
        
        yield {
            "type": "status",
            "message": "AI is analyzing sentiment, bias, and generating summaries...",
            "phase": "ai_processing"
        }
        
        try:
            processed_articles = await self._process_with_agent(raw_articles, user_id)
        except Exception as e:
            yield {
                "type": "status",
                "message": "Using quick analysis mode...",
                "phase": "fallback"
            }
            processed_articles = await self._process_direct(raw_articles)
        
        yield {
            "type": "status",
            "message": "Personalizing your digest...",
            "phase": "personalizing"
        }
        
        # Personalize
        personalized = rank_articles(
            processed_articles,
            preferences.to_response(),
            max_articles=agent_config.max_articles_per_digest
        )
        
        # Save
        yield {
            "type": "status",
            "message": "Saving digest...",
            "phase": "saving"
        }
        
        await self.news_service.save_articles(personalized)
        digest = await self.digest_service.save_digest(
            user_id=user_id,
            articles=personalized
        )
        
        yield {
            "type": "complete",
            "digest": digest.to_response()
        }
    
    async def _process_with_agent(
        self,
        articles: List[Dict[str, Any]],
        user_id: str
    ) -> List[Dict[str, Any]]:
        """Process articles using ADK agent for summarization and classification."""
        # For now, use direct processing which has full AI analysis
        # The ADK agent pipeline can be used once sub-agents are fully configured
        return await self._process_direct(articles)
    
    async def _process_direct(
        self,
        articles: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """Fallback: Process articles using direct Gemini API with full AI analysis."""
        
        # Prepare articles for the prompt
        articles_for_prompt = [
            {
                "id": a.get("id"),
                "title": a.get("title"),
                "source": a.get("source"),
                "description": a.get("description", "")[:300]
            }
            for a in articles[:15]
        ]
        articles_json = json.dumps(articles_for_prompt, indent=2)
        
        # Build the prompt
        prompt = f"""Process these news articles. For each article, provide:
1. summary: A 2-3 sentence summary
2. tldr: A single sentence (max 15 words) capturing the essence
3. topics: 1-3 categories from: technology, science, business, politics, health, entertainment, sports, world, environment, education
4. sentiment: One of "positive", "negative", "neutral", "mixed"
5. sentiment_score: Float from -1.0 (very negative) to 1.0 (very positive)
6. bias: One of "left", "center-left", "center", "center-right", "right", "factual"
7. bias_explanation: One sentence explaining the bias rating
8. is_breaking: Boolean, true if this is breaking/urgent news
9. breaking_score: Float from 0.0 to 1.0 indicating importance

Articles:
{articles_json}

Return ONLY a valid JSON array with these exact fields for each article:
[{{"id": "...", "summary": "...", "tldr": "...", "topics": [...], "sentiment": "...", "sentiment_score": 0.0, "bias": "...", "bias_explanation": "...", "is_breaking": false, "breaking_score": 0.0}}]"""

        try:
            response = self.client.models.generate_content(
                model=self.model,
                contents=prompt
            )
            
            processed = parse_json_response(response.text, [])
            
            if processed:
                processed_map = {p.get("id"): p for p in processed}
                for article in articles:
                    if article.get("id") in processed_map:
                        p = processed_map[article["id"]]
                        article["summary"] = p.get("summary", article.get("description", ""))
                        article["tldr"] = p.get("tldr", "")
                        article["topics"] = p.get("topics", [])
                        article["sentiment"] = p.get("sentiment", "neutral")
                        article["sentiment_score"] = float(p.get("sentiment_score", 0.0))
                        article["bias"] = p.get("bias", "center")
                        article["bias_explanation"] = p.get("bias_explanation", "")
                        article["is_breaking"] = bool(p.get("is_breaking", False))
                        article["breaking_score"] = float(p.get("breaking_score", 0.0))
                    else:
                        # Default values for unprocessed articles
                        self._set_default_ai_fields(article)
            else:
                for article in articles:
                    self._set_default_ai_fields(article)
            
        except Exception as e:
            print(f"Direct processing failed: {e}")
            # Add default values
            for article in articles:
                self._set_default_ai_fields(article)
        
        # Find related articles based on topics
        self._find_related_articles(articles)
        
        return articles
    
    def _set_default_ai_fields(self, article: Dict[str, Any]):
        """Set default values for AI fields."""
        article["summary"] = article.get("description", "")[:200]
        article["tldr"] = article.get("title", "")[:80]
        article["topics"] = self._guess_topics(article)
        article["sentiment"] = "neutral"
        article["sentiment_score"] = 0.0
        article["bias"] = "center"
        article["bias_explanation"] = "Analysis pending"
        article["is_breaking"] = False
        article["breaking_score"] = 0.0
        article["related_ids"] = []
    
    def _find_related_articles(self, articles: List[Dict[str, Any]]):
        """Find related articles based on shared topics."""
        for article in articles:
            related = []
            article_topics = set(article.get("topics", []))
            
            for other in articles:
                if other.get("id") == article.get("id"):
                    continue
                    
                other_topics = set(other.get("topics", []))
                # If they share at least one topic, they're related
                if article_topics & other_topics:
                    related.append(other.get("id"))
            
            article["related_ids"] = related[:3]  # Max 3 related
    
    def _guess_topics(self, article: Dict[str, Any]) -> List[str]:
        """Guess topics based on source and keywords."""
        source = article.get("source", "").lower()
        title = article.get("title", "").lower()
        
        topics = []
        
        # Source-based guessing
        if "tech" in source or source in ["verge", "ars_technica", "wired"]:
            topics.append("technology")
        elif "science" in source:
            topics.append("science")
        elif "npr" in source or "bbc_world" in source:
            topics.append("world")
        
        # Keyword-based guessing
        tech_keywords = ["ai", "tech", "software", "app", "startup", "google", "apple", "microsoft"]
        science_keywords = ["research", "study", "scientists", "discovery", "space", "nasa"]
        business_keywords = ["market", "stock", "economy", "company", "billion", "ceo"]
        
        for kw in tech_keywords:
            if kw in title and "technology" not in topics:
                topics.append("technology")
                break
        
        for kw in science_keywords:
            if kw in title and "science" not in topics:
                topics.append("science")
                break
        
        for kw in business_keywords:
            if kw in title and "business" not in topics:
                topics.append("business")
                break
        
        return topics if topics else ["general"]
