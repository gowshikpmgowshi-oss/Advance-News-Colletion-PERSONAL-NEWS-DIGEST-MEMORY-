"""
Chat service for conversational Q&A about news articles.
"""
import json
from datetime import datetime
from typing import Dict, Any, List, Optional, AsyncGenerator

from google import genai
from google.genai import types
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.adk.agents import LlmAgent

from app.config import settings
from app.database import get_database
from app.services.digest_service import DigestService
from app.services.news_service import NewsService
from news_agent.config import config as agent_config


# Create a dedicated chat agent
CHAT_AGENT_INSTRUCTION = """You are an intelligent news assistant that helps users understand and explore their personalized news digest.

## Your Capabilities

1. **Answer Questions**: Answer questions about specific articles or today's digest
2. **Summarize**: Provide quick summaries when asked
3. **Explain**: Explain complex topics mentioned in articles
4. **Connect**: Find connections between different news stories
5. **Discuss**: Engage in thoughtful discussion about current events

## Context

You have access to:
- The user's personalized news digest for today
- Specific article details when provided
- Conversation history

## Guidelines

1. Be concise but informative
2. Stay factual and cite specific articles when relevant
3. Acknowledge when something isn't covered in the digest
4. Offer to explain complex topics in simpler terms
5. Be neutral and present multiple perspectives on controversial topics

## Format

- Use markdown for formatting when helpful
- Keep responses under 300 words unless asked for detail
- Use bullet points for lists
"""

chat_agent = LlmAgent(
    name="NewsAssistantAgent",
    model=agent_config.main_model,
    description="Interactive chat assistant for discussing news articles.",
    instruction=CHAT_AGENT_INSTRUCTION,
)


class ChatService:
    """Service for chat functionality with AI about news."""
    
    def __init__(self):
        self.client = genai.Client(api_key=settings.google_api_key)
        self.model = agent_config.main_model
        self.digest_service = DigestService()
        self.news_service = NewsService()
        self.session_service = InMemorySessionService()
        self.runner = Runner(
            agent=chat_agent,
            app_name="news_chat",
            session_service=self.session_service
        )
    
    async def chat(
        self,
        user_id: str,
        message: str,
        conversation_history: List[Dict[str, str]] = None,
        article_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Process a chat message and return AI response.
        
        Args:
            user_id: User ID
            message: User's chat message
            conversation_history: Previous messages in conversation
            article_id: Optional specific article to discuss
            
        Returns:
            Chat response with updated history
        """
        conversation_history = conversation_history or []
        
        # Get context
        context = await self._build_context(user_id, article_id)
        
        # Build the prompt with context and history
        prompt = self._build_prompt(message, context, conversation_history)
        
        try:
            # Try ADK agent first
            session_id = f"chat_{user_id}_{int(datetime.utcnow().timestamp())}"
            
            user_content = types.Content(
                role="user",
                parts=[types.Part(text=prompt)]
            )
            
            response_text = ""
            async for event in self.runner.run_async(
                user_id=user_id,
                session_id=session_id,
                new_message=user_content
            ):
                if hasattr(event, 'content') and event.content:
                    if hasattr(event.content, 'parts') and event.content.parts:
                        for part in event.content.parts:
                            if hasattr(part, 'text') and part.text:
                                response_text += part.text
            
            if not response_text:
                # Fallback to direct API
                response_text = await self._chat_direct(prompt)
            
        except Exception as e:
            print(f"ADK chat failed, using fallback: {e}")
            response_text = await self._chat_direct(prompt)
        
        # Update conversation history
        conversation_history.append({"role": "user", "content": message})
        conversation_history.append({"role": "assistant", "content": response_text})
        
        return {
            "success": True,
            "response": response_text,
            "conversation_history": conversation_history
        }
    
    async def chat_streaming(
        self,
        user_id: str,
        message: str,
        conversation_history: List[Dict[str, str]] = None,
        article_id: Optional[str] = None
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """
        Stream chat response for real-time effect.
        """
        conversation_history = conversation_history or []
        
        # Get context
        context = await self._build_context(user_id, article_id)
        prompt = self._build_prompt(message, context, conversation_history)
        
        full_response = ""
        
        try:
            # Stream using direct Gemini API for better streaming control
            response = self.client.models.generate_content_stream(
                model=self.model,
                contents=prompt
            )
            
            for chunk in response:
                if chunk.text:
                    full_response += chunk.text
                    yield {
                        "type": "chunk",
                        "content": chunk.text
                    }
            
        except Exception as e:
            yield {
                "type": "error",
                "error": str(e)
            }
            return
        
        # Update history
        conversation_history.append({"role": "user", "content": message})
        conversation_history.append({"role": "assistant", "content": full_response})
        
        yield {
            "type": "complete",
            "response": full_response,
            "conversation_history": conversation_history
        }
    
    async def clear_history(self, user_id: str) -> bool:
        """Clear chat history for user (stored client-side, this is a no-op for now)."""
        return True
    
    async def _build_context(
        self,
        user_id: str,
        article_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """Build context from digest and optionally specific article."""
        context = {
            "digest_articles": [],
            "specific_article": None,
            "date": datetime.utcnow().strftime("%B %d, %Y")
        }
        
        # Get today's digest
        digest = await self.digest_service.get_today_digest(user_id)
        if digest:
            context["digest_articles"] = [
                {
                    "id": a.id,
                    "title": a.title,
                    "summary": a.summary,
                    "tldr": getattr(a, 'tldr', ''),
                    "source": a.source,
                    "topics": a.topics,
                    "sentiment": getattr(a, 'sentiment', None),
                    "bias": getattr(a, 'bias', None),
                }
                for a in digest.articles
            ]
        
        # Get specific article if requested
        if article_id:
            article = await self.news_service.get_article_by_id(article_id)
            if article:
                context["specific_article"] = article.to_response()
        
        return context
    
    def _build_prompt(
        self,
        message: str,
        context: Dict[str, Any],
        history: List[Dict[str, str]]
    ) -> str:
        """Build the full prompt with context and history."""
        # Format articles for context
        articles_context = ""
        if context["digest_articles"]:
            articles_list = []
            for i, a in enumerate(context["digest_articles"][:10], 1):
                articles_list.append(
                    f"{i}. [{a['source']}] {a['title']}\n"
                    f"   Summary: {a['summary'][:200]}\n"
                    f"   Topics: {', '.join(a['topics'])}"
                )
            articles_context = "\n".join(articles_list)
        
        # Format specific article if present
        specific_context = ""
        if context.get("specific_article"):
            a = context["specific_article"]
            specific_context = f"""
SPECIFIC ARTICLE IN FOCUS:
Title: {a['title']}
Source: {a['source']}
Summary: {a['summary']}
Topics: {', '.join(a['topics'])}
"""
        
        # Format conversation history
        history_context = ""
        if history:
            history_lines = []
            for msg in history[-6:]:  # Last 6 messages
                role = "User" if msg["role"] == "user" else "Assistant"
                history_lines.append(f"{role}: {msg['content'][:300]}")
            history_context = "\n".join(history_lines)
        
        prompt = f"""You are a helpful news assistant. Today is {context['date']}.

TODAY'S NEWS DIGEST:
{articles_context if articles_context else "No articles available yet."}
{specific_context}

CONVERSATION HISTORY:
{history_context if history_context else "(New conversation)"}

USER'S MESSAGE: {message}

Respond helpfully, referencing specific articles when relevant. Be concise but informative."""
        
        return prompt
    
    async def _chat_direct(self, prompt: str) -> str:
        """Fallback: Direct Gemini API call for chat."""
        try:
            response = self.client.models.generate_content(
                model=self.model,
                contents=prompt
            )
            return response.text
        except Exception as e:
            return f"I apologize, but I encountered an error: {str(e)}. Please try again."
