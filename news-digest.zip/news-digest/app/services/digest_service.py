"""
Digest service for managing daily news digests.
"""
from datetime import datetime, date
from typing import Dict, Any, List, Optional
from collections import Counter

from bson import ObjectId

from app.database import get_database
from app.models.digest import DigestModel, DigestArticle


class DigestService:
    """Service for managing news digests."""
    
    def __init__(self):
        self.db = None
    
    def _get_db(self):
        if self.db is None:
            self.db = get_database()
        return self.db
    
    async def get_today_digest(self, user_id: str) -> Optional[DigestModel]:
        """Get today's digest for a user."""
        db = self._get_db()
        
        today = date.today().isoformat()
        
        doc = await db.digests.find_one({
            "user_id": user_id,
            "date": today
        })
        
        if doc:
            doc["_id"] = str(doc["_id"])
            return DigestModel(**doc)
        
        return None
    
    async def save_digest(
        self,
        user_id: str,
        articles: List[Dict[str, Any]],
        personalization_score: float = 0.0
    ) -> DigestModel:
        """
        Save a new digest for the user.
        
        Args:
            user_id: User ID
            articles: List of article dictionaries
            personalization_score: Average relevance score
            
        Returns:
            The saved digest model
        """
        db = self._get_db()
        today = date.today()
        
        # Convert articles to DigestArticle objects
        digest_articles = []
        all_topics = []
        sources = set()
        
        for article in articles:
            digest_article = DigestArticle(
                id=article.get("id", ""),
                title=article.get("title", ""),
                link=article.get("link", ""),
                source=article.get("source", ""),
                summary=article.get("summary", article.get("description", "")[:200]),
                tldr=article.get("tldr", ""),
                topics=article.get("topics", []),
                relevance_score=article.get("relevance_score", 1.0),
                published=article.get("published"),
                image_url=article.get("image_url"),
                # AI Analysis fields
                sentiment=article.get("sentiment"),
                sentiment_score=float(article.get("sentiment_score", 0.0)),
                bias=article.get("bias"),
                bias_explanation=article.get("bias_explanation", ""),
                is_breaking=bool(article.get("is_breaking", False)),
                related_ids=article.get("related_ids", [])
            )
            digest_articles.append(digest_article)
            all_topics.extend(article.get("topics", []))
            sources.add(article.get("source", ""))
        
        # Get top topics
        topic_counts = Counter(all_topics)
        top_topics = [t for t, _ in topic_counts.most_common(5)]
        
        # Calculate average personalization score
        if articles and personalization_score == 0:
            scores = [a.get("relevance_score", 1.0) for a in articles]
            personalization_score = sum(scores) / len(scores)
        
        digest = DigestModel(
            user_id=user_id,
            date=today,
            articles=digest_articles,
            article_count=len(digest_articles),
            top_topics=top_topics,
            sources_used=list(sources),
            personalization_score=round(personalization_score, 2)
        )
        
        # Upsert digest (replace if exists for today)
        await db.digests.update_one(
            {"user_id": user_id, "date": today.isoformat()},
            {"$set": digest.to_dict()},
            upsert=True
        )
        
        # Update user stats
        await db.users.update_one(
            {"_id": ObjectId(user_id)},
            {
                "$inc": {"total_digests_generated": 1},
                "$set": {"last_digest_at": datetime.utcnow()}
            }
        )
        
        return digest
    
    async def get_digest_history(
        self,
        user_id: str,
        limit: int = 30
    ) -> List[DigestModel]:
        """Get user's digest history."""
        db = self._get_db()
        
        cursor = db.digests.find(
            {"user_id": user_id}
        ).sort("date", -1).limit(limit)
        
        digests = []
        async for doc in cursor:
            doc["_id"] = str(doc["_id"])
            digests.append(DigestModel(**doc))
        
        return digests
    
    async def update_digest_stats(
        self,
        user_id: str,
        digest_date: str,
        action: str
    ) -> bool:
        """Update digest interaction stats."""
        db = self._get_db()
        
        stat_field = {
            "click": "articles_clicked",
            "like": "articles_liked",
            "dismiss": "articles_dismissed",
            "save": "articles_saved"
        }.get(action)
        
        if not stat_field:
            return False
        
        result = await db.digests.update_one(
            {"user_id": user_id, "date": digest_date},
            {"$inc": {stat_field: 1}}
        )
        
        return result.modified_count > 0
    
    async def get_digest_stats(self, user_id: str) -> Dict[str, Any]:
        """Get aggregate stats about user's digests."""
        db = self._get_db()
        
        pipeline = [
            {"$match": {"user_id": user_id}},
            {
                "$group": {
                    "_id": None,
                    "total_digests": {"$sum": 1},
                    "total_articles": {"$sum": "$article_count"},
                    "avg_personalization": {"$avg": "$personalization_score"},
                    "total_clicked": {"$sum": "$articles_clicked"},
                    "total_liked": {"$sum": "$articles_liked"},
                    "total_dismissed": {"$sum": "$articles_dismissed"},
                    "total_saved": {"$sum": "$articles_saved"}
                }
            }
        ]
        
        result = await db.digests.aggregate(pipeline).to_list(1)
        
        if result:
            stats = result[0]
            del stats["_id"]
            return stats
        
        return {
            "total_digests": 0,
            "total_articles": 0,
            "avg_personalization": 0,
            "total_clicked": 0,
            "total_liked": 0,
            "total_dismissed": 0,
            "total_saved": 0
        }
