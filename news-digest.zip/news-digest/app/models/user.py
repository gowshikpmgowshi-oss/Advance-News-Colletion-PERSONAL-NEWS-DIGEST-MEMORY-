"""
User model for MongoDB.
"""
from datetime import datetime
from typing import Optional, Dict, Any
from pydantic import BaseModel, EmailStr, Field


class UserSettings(BaseModel):
    """User preferences and settings."""
    theme: str = "light"
    digest_time: str = "08:00"  # Preferred digest delivery time
    max_articles: int = 15
    notifications_enabled: bool = True


class UserModel(BaseModel):
    """User database model."""
    id: Optional[str] = Field(None, alias="_id")
    email: EmailStr
    username: str
    password_hash: str
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    
    # Usage stats
    total_digests_generated: int = 0
    total_articles_read: int = 0
    last_digest_at: Optional[datetime] = None
    
    # Settings
    settings: UserSettings = Field(default_factory=UserSettings)
    
    class Config:
        populate_by_name = True
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for MongoDB insertion."""
        data = self.model_dump(by_alias=True, exclude={"id"})
        return data
    
    def to_response(self) -> Dict[str, Any]:
        """Convert to response dictionary (excludes password)."""
        return {
            "id": self.id,
            "email": self.email,
            "username": self.username,
            "created_at": self.created_at.isoformat(),
            "total_digests_generated": self.total_digests_generated,
            "total_articles_read": self.total_articles_read,
            "last_digest_at": self.last_digest_at.isoformat() if self.last_digest_at else None,
            "settings": self.settings.model_dump()
        }
