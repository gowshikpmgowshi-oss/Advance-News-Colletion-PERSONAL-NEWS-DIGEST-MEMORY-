"""
Pydantic models for the News Digest application.
"""
from .user import UserModel, UserSettings
from .article import ArticleModel
from .preference import PreferenceModel
from .interaction import InteractionModel
from .digest import DigestModel

__all__ = [
    "UserModel",
    "UserSettings",
    "ArticleModel",
    "PreferenceModel",
    "InteractionModel",
    "DigestModel",
]
