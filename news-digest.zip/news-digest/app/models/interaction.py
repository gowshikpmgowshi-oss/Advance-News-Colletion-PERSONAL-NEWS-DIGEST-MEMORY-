"""
User Interaction model for MongoDB.
"""
from datetime import datetime
from typing import Optional, Dict, Any, List, Literal
from pydantic import BaseModel, Field


InteractionType = Literal["click", "like", "dismiss", "save", "read"]


class InteractionModel(BaseModel):
    """User interaction with an article."""
    id: Optional[str] = Field(None, alias="_id")
    user_id: str
    article_id: str
    
    # Interaction details
    action: InteractionType
    
    # Article context at time of interaction
    article_title: str = ""
    article_topics: List[str] = Field(default_factory=list)
    article_source: str = ""
    
    # Timing
    created_at: datetime = Field(default_factory=datetime.utcnow)
    
    # Optional: time spent reading (for 'read' actions)
    time_spent_seconds: Optional[int] = None
    
    class Config:
        populate_by_name = True
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for MongoDB insertion."""
        data = self.model_dump(by_alias=True, exclude={"id"})
        return data
    
    def to_response(self) -> Dict[str, Any]:
        """Convert to API response."""
        return {
            "id": self.id,
            "article_id": self.article_id,
            "action": self.action,
            "article_title": self.article_title,
            "created_at": self.created_at.isoformat()
        }


# Preference weight adjustments for each action type
INTERACTION_WEIGHTS = {
    "click": {"liked_topics": 0.1, "source_weights": 0.05},
    "like": {"liked_topics": 0.3, "source_weights": 0.2},
    "dismiss": {"dismissed_topics": 0.2},
    "save": {"liked_topics": 0.5, "source_weights": 0.1},
    "read": {"liked_topics": 0.15, "source_weights": 0.05},
}
