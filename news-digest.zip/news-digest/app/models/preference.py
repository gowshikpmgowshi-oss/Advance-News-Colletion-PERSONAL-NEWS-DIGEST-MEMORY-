"""
User Preference model for MongoDB.
"""
from datetime import datetime
from typing import Optional, Dict, Any, List
from pydantic import BaseModel, Field


class PreferenceModel(BaseModel):
    """User preference model for personalization."""
    id: Optional[str] = Field(None, alias="_id")
    user_id: str
    
    # Topic preferences (topic -> weight, higher = more interested)
    liked_topics: Dict[str, float] = Field(default_factory=dict)
    
    # Dismissed topics (topic -> weight, higher = less interested)
    dismissed_topics: Dict[str, float] = Field(default_factory=dict)
    
    # Source preferences (source -> weight)
    source_weights: Dict[str, float] = Field(default_factory=dict)
    
    # Blocked sources (completely excluded)
    blocked_sources: List[str] = Field(default_factory=list)
    
    # Custom RSS feeds added by user
    custom_feeds: Dict[str, str] = Field(default_factory=dict)
    
    # Timestamps
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    
    class Config:
        populate_by_name = True
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for MongoDB insertion."""
        data = self.model_dump(by_alias=True, exclude={"id"})
        return data
    
    def to_response(self) -> Dict[str, Any]:
        """Convert to API response."""
        return {
            "user_id": self.user_id,
            "liked_topics": self.liked_topics,
            "dismissed_topics": self.dismissed_topics,
            "source_weights": self.source_weights,
            "blocked_sources": self.blocked_sources,
            "custom_feeds": self.custom_feeds,
            "updated_at": self.updated_at.isoformat()
        }
    
    @classmethod
    def create_default(cls, user_id: str) -> "PreferenceModel":
        """Create a new preference model with default values."""
        return cls(
            user_id=user_id,
            liked_topics={},
            dismissed_topics={},
            source_weights={},
            blocked_sources=[],
            custom_feeds={}
        )
