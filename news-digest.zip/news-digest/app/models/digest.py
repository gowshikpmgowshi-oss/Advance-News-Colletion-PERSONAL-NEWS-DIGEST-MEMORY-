"""
Daily Digest model for MongoDB.
"""
from datetime import datetime, date
from typing import Optional, Dict, Any, List
from pydantic import BaseModel, Field


class DigestArticle(BaseModel):
    """Article as it appears in a digest."""
    id: str
    title: str
    link: str
    source: str
    summary: str
    tldr: str = ""  # One-line summary
    topics: List[str] = Field(default_factory=list)
    relevance_score: float = 1.0
    published: Optional[str] = None
    image_url: Optional[str] = None  # Header/thumbnail image
    # AI analysis fields
    sentiment: Optional[str] = None  # positive, negative, neutral, mixed
    sentiment_score: float = 0.0
    bias: Optional[str] = None  # political leaning
    bias_explanation: str = ""
    is_breaking: bool = False
    related_ids: List[str] = Field(default_factory=list)


class DigestModel(BaseModel):
    """Daily digest model."""
    id: Optional[str] = Field(None, alias="_id")
    user_id: str
    date: date  # The date this digest is for
    
    # Articles in this digest
    articles: List[DigestArticle] = Field(default_factory=list)
    
    # Metadata
    generated_at: datetime = Field(default_factory=datetime.utcnow)
    article_count: int = 0
    
    # Stats about this digest
    top_topics: List[str] = Field(default_factory=list)
    sources_used: List[str] = Field(default_factory=list)
    personalization_score: float = 0.0  # Average relevance score
    
    # User interaction stats
    articles_clicked: int = 0
    articles_liked: int = 0
    articles_dismissed: int = 0
    articles_saved: int = 0
    
    class Config:
        populate_by_name = True
        json_encoders = {
            datetime: lambda v: v.isoformat(),
            date: lambda v: v.isoformat()
        }
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for MongoDB insertion."""
        data = self.model_dump(by_alias=True, exclude={"id"})
        # Convert date to string for MongoDB
        data["date"] = data["date"].isoformat() if isinstance(data["date"], date) else data["date"]
        return data
    
    def to_response(self) -> Dict[str, Any]:
        """Convert to API response."""
        return {
            "id": self.id,
            "date": self.date.isoformat() if isinstance(self.date, date) else self.date,
            "articles": [a.model_dump() for a in self.articles],
            "article_count": self.article_count,
            "top_topics": self.top_topics,
            "sources_used": self.sources_used,
            "personalization_score": self.personalization_score,
            "generated_at": self.generated_at.isoformat(),
            "stats": {
                "clicked": self.articles_clicked,
                "liked": self.articles_liked,
                "dismissed": self.articles_dismissed,
                "saved": self.articles_saved
            }
        }
