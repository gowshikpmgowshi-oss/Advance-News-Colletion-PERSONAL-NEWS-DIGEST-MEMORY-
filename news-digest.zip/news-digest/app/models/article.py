"""
Article model for MongoDB.
"""
from datetime import datetime
from typing import Optional, Dict, Any, List, Literal
from pydantic import BaseModel, Field


# Type definitions for AI features
SentimentType = Literal["positive", "negative", "neutral", "mixed"]
BiasType = Literal["left", "center-left", "center", "center-right", "right", "factual"]


class ArticleModel(BaseModel):
    """Article database model."""
    id: str  # MD5 hash of URL
    title: str
    link: str
    source: str
    published: Optional[datetime] = None
    fetched_at: datetime = Field(default_factory=datetime.utcnow)
    
    # Content
    description: str = ""
    summary: str = ""
    tldr: str = ""  # One-line ultra-short summary
    full_text: Optional[str] = None
    image_url: Optional[str] = None  # Header/thumbnail image from RSS
    
    # Classification
    topics: List[str] = Field(default_factory=list)
    
    # AI Analysis
    sentiment: Optional[SentimentType] = None  # positive, negative, neutral, mixed
    sentiment_score: float = 0.0  # -1.0 to 1.0
    bias: Optional[BiasType] = None  # political leaning
    bias_explanation: str = ""  # Why this bias rating
    is_breaking: bool = False  # Important/developing story
    breaking_score: float = 0.0  # 0.0 to 1.0 importance score
    related_ids: List[str] = Field(default_factory=list)  # IDs of related articles
    
    # Stats
    view_count: int = 0
    like_count: int = 0
    dismiss_count: int = 0
    save_count: int = 0
    
    class Config:
        populate_by_name = True
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for MongoDB insertion."""
        data = self.model_dump()
        data["_id"] = data.pop("id")
        return data
    
    def to_response(self) -> Dict[str, Any]:
        """Convert to API response."""
        return {
            "id": self.id,
            "title": self.title,
            "link": self.link,
            "source": self.source,
            "published": self.published.isoformat() if self.published else None,
            "summary": self.summary or self.description[:200],
            "tldr": self.tldr,
            "topics": self.topics,
            "image_url": self.image_url,
            "sentiment": self.sentiment,
            "sentiment_score": self.sentiment_score,
            "bias": self.bias,
            "bias_explanation": self.bias_explanation,
            "is_breaking": self.is_breaking,
            "related_ids": self.related_ids,
            "stats": {
                "views": self.view_count,
                "likes": self.like_count,
                "saves": self.save_count,
            }
        }
