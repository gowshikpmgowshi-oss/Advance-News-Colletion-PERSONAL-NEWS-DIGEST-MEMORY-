"""
News Digest - FastAPI Application Entry Point
"""
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
from pathlib import Path

from app.database import init_db, close_db
from app.routes import (
    auth_router,
    digest_router,
    articles_router,
    preferences_router,
    interactions_router,
    chat_router,
    explain_router,
    audio_router
)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan manager."""
    # Startup
    await init_db()
    yield
    # Shutdown
    await close_db()


# Create FastAPI application
app = FastAPI(
    title="News Digest",
    description="Personal News Digest with Memory - AI-powered news curation using Google ADK",
    version="1.0.0",
    lifespan=lifespan
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include API routers
app.include_router(auth_router)
app.include_router(digest_router)
app.include_router(articles_router)
app.include_router(preferences_router)
app.include_router(interactions_router)
app.include_router(chat_router)
app.include_router(explain_router)
app.include_router(audio_router)

# Serve static files
static_path = Path(__file__).parent.parent / "static"
if static_path.exists():
    app.mount("/static", StaticFiles(directory=str(static_path)), name="static")


# Serve frontend pages
@app.get("/", response_class=HTMLResponse)
async def serve_index():
    """Serve the landing/login page."""
    index_path = static_path / "index.html"
    if index_path.exists():
        return FileResponse(index_path)
    return HTMLResponse("<h1>News Digest</h1><p>Frontend not found.</p>")


@app.get("/dashboard", response_class=HTMLResponse)
async def serve_dashboard():
    """Serve the dashboard page."""
    dashboard_path = static_path / "dashboard.html"
    if dashboard_path.exists():
        return FileResponse(dashboard_path)
    return HTMLResponse("<h1>Dashboard</h1><p>Page not found.</p>")


@app.get("/preferences", response_class=HTMLResponse)
async def serve_preferences():
    """Serve the preferences page."""
    prefs_path = static_path / "preferences.html"
    if prefs_path.exists():
        return FileResponse(prefs_path)
    return HTMLResponse("<h1>Preferences</h1><p>Page not found.</p>")


@app.get("/article", response_class=HTMLResponse)
async def serve_article():
    """Serve the article detail page."""
    article_path = static_path / "article.html"
    if article_path.exists():
        return FileResponse(article_path)
    return HTMLResponse("<h1>Article</h1><p>Page not found.</p>")


# Health check
@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "healthy", "service": "news-digest"}
