# Personal News Digest with Memory

An intelligent news digest agent built with Google ADK that curates personalized news based on user preferences. The system learns from user interactions (clicks, likes, dismisses) to improve recommendations over time.

## Features

- **Personalized News Curation**: AI-powered digest tailored to your interests
- **Preference Learning**: System learns from your interactions (like, dismiss, save)
- **RSS Feed Aggregation**: Fetches from multiple trusted news sources
- **AI Summarization**: Gemini-powered 2-3 sentence summaries for quick reading
- **Topic Classification**: Automatic categorization of articles
- **No API Keys for News**: Uses free RSS feeds (BBC, TechCrunch, NPR, etc.)

## Architecture

```
news-digest/
├── news_agent/          # ADK Agent Module (Core)
│   ├── agent.py         # Root SequentialAgent
│   ├── config.py        # Agent configuration
│   ├── prompt.py        # Agent instructions
│   ├── tools.py         # RSS parsing tools
│   └── sub_agents/      # Specialized agents
├── app/                 # FastAPI Backend
│   ├── database/        # MongoDB connection
│   ├── models/          # Pydantic models
│   ├── routes/          # API endpoints
│   └── services/        # Business logic
└── static/              # Frontend (HTML/CSS/JS)
```

## Prerequisites

- Python 3.11+
- MongoDB running locally or remotely
- Google API Key (for Gemini)

## Installation

1. Clone the repository and navigate to the project:
   ```bash
   cd news-digest
   ```

2. Create a virtual environment:
   ```bash
   python -m venv .venv
   .venv\Scripts\activate  # Windows
   source .venv/bin/activate  # Linux/Mac
   ```

3. Install dependencies:
   ```bash
   pip install -e .
   ```

4. Copy environment file and configure:
   ```bash
   cp env.example .env
   # Edit .env with your GOOGLE_API_KEY
   ```

5. Start MongoDB (if not running)

6. Run the application:
   ```bash
   python -m uvicorn app.main:app --reload
   ```

7. Open http://localhost:8000 in your browser

## RSS Sources

The system fetches from these free RSS feeds:

| Source | Category |
|--------|----------|
| BBC World | World News |
| BBC Technology | Technology |
| TechCrunch | Technology |
| The Verge | Technology |
| Ars Technica | Technology |
| NPR News | General |
| Wired | Technology |

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| POST | /api/auth/register | Register new user |
| POST | /api/auth/login | Login, get JWT |
| GET | /api/digest/today | Get personalized digest |
| POST | /api/interactions | Record user action |
| GET | /api/preferences | Get learned preferences |

## How Personalization Works

The system tracks your interactions:

| Action | Effect on Preferences |
|--------|----------------------|
| Click | +0.1 to topic interest |
| Like | +0.3 to topic, +0.2 to source |
| Dismiss | +0.2 to dismissed topics |
| Save | +0.5 to topic interest |

Articles are then ranked based on your preference weights.

## License

MIT License
