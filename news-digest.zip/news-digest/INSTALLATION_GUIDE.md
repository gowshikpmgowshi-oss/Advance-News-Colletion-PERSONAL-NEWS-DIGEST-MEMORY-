# 📘 Personal News Digest with Memory - Complete Installation & Setup Guide

**A Step-by-Step Manual for First-Time Users**

Welcome! This guide will walk you through setting up the **Personal News Digest** application on your Windows computer. This AI-powered tool curates personalized news based on your interests and learns from your reading habits over time.

Don't worry if you've never used command-line tools before – we'll explain everything in simple terms with clear instructions.

---

## 📋 Table of Contents

1. [What You'll Need](#what-youll-need)
2. [Step 1: Install Python](#step-1-install-python)
3. [Step 2: Install MongoDB Database](#step-2-install-mongodb-database)
4. [Step 3: Get Your Google AI API Key](#step-3-get-your-google-ai-api-key)
5. [Step 4: Set Up the Project](#step-4-set-up-the-project)
6. [Step 5: Create a Virtual Environment](#step-5-create-a-virtual-environment)
7. [Step 6: Install Dependencies](#step-6-install-dependencies)
8. [Step 7: Configure Environment Variables](#step-7-configure-environment-variables)
9. [Step 8: Run the Application](#step-8-run-the-application)
10. [Common Errors & How to Fix Them](#common-errors--how-to-fix-them)
11. [How to Start After First Setup](#how-to-start-after-first-setup)
12. [Pro Tips](#pro-tips)

---

## What You'll Need

Before starting, make sure you have:

- ✅ A Windows 10 or Windows 11 computer
- ✅ At least 4 GB of free disk space
- ✅ An internet connection
- ✅ A Google account (for the AI API key)
- ✅ About 30-45 minutes for the initial setup

---

## Step 1: Install Python

Python is the programming language that powers this application. We need version 3.11 or higher.

### 1.1 Check if Python is Already Installed

1. Press `Windows + R` on your keyboard
2. Type `cmd` and press **Enter** to open Command Prompt
3. Type the following command and press **Enter**:
   ```bash
   python --version
   ```
4. If you see something like `Python 3.11.x` or higher, skip to [Step 2](#step-2-install-mongodb-database)
5. If you see an error or a version lower than 3.11, continue below

### 1.2 Download Python

1. Open your web browser and go to: **https://www.python.org/downloads/**
2. Click the big yellow button that says **"Download Python 3.12.x"** (or the latest version)
3. Save the installer file to your computer

### 1.3 Install Python

1. **Double-click** the downloaded installer file
2. ⚠️ **IMPORTANT**: Check the box that says **"Add Python to PATH"** at the bottom of the installer window
3. Click **"Install Now"**
4. Wait for the installation to complete (2-5 minutes)
5. Click **"Close"** when finished

### 1.4 Verify Python Installation

1. **Close** any open Command Prompt windows
2. Open a **new** Command Prompt (Windows + R, type `cmd`, press Enter)
3. Type:
   ```bash
   python --version
   ```
4. You should see: `Python 3.12.x` (or similar)
5. Also verify pip (Python's package manager):
   ```bash
   pip --version
   ```
6. You should see: `pip 24.x.x` (or similar)

✅ **Success!** Python is now installed.

---

## Step 2: Install MongoDB Database

MongoDB is where the application stores your preferences, saved articles, and user data.

### 2.1 Download MongoDB Community Server

1. Go to: **https://www.mongodb.com/try/download/community**
2. Make sure these options are selected:
   - **Version**: 7.0.x (or latest)
   - **Platform**: Windows
   - **Package**: MSI
3. Click **"Download"**

### 2.2 Install MongoDB

1. **Double-click** the downloaded `.msi` installer
2. Click **"Next"** on the welcome screen
3. Accept the license agreement and click **"Next"**
4. Choose **"Complete"** installation and click **"Next"**
5. ⚠️ **IMPORTANT**: Make sure **"Install MongoDB as a Service"** is checked
6. ⚠️ **IMPORTANT**: Check **"Install MongoDB Compass"** (this is a helpful visual tool)
7. Click **"Next"**, then **"Install"**
8. Wait for installation to complete (3-5 minutes)
9. Click **"Finish"**

### 2.3 Verify MongoDB Installation

1. Open Command Prompt
2. Type:
   ```bash
   mongod --version
   ```
3. You should see version information (e.g., `db version v7.0.x`)

> **📝 Note**: MongoDB runs automatically as a Windows service. You don't need to start it manually.

✅ **Success!** MongoDB is now installed and running.

---

## Step 3: Get Your Google AI API Key

The News Digest uses Google's Gemini AI to summarize articles and personalize your feed. You need an API key to use this service.

### 3.1 Create Your API Key

1. Go to: **https://aistudio.google.com/apikey**
2. Sign in with your Google account
3. Click **"Create API Key"**
4. Click **"Create API key in new project"**
5. Your API key will be displayed (a long string of letters and numbers)
6. ⚠️ **IMPORTANT**: Click the **copy button** to copy your API key
7. **Save this key somewhere safe** (like a text file) – you'll need it soon!

> **⚠️ WARNING**: Never share your API key publicly. Treat it like a password.

✅ **Success!** You now have your Google AI API key.

---

## Step 4: Set Up the Project

Now let's navigate to the project folder.

### 4.1 Open Command Prompt

1. Press `Windows + R`
2. Type `cmd` and press **Enter**

### 4.2 Navigate to the Project Folder

1. Navigate to the project directory:
   ```bash
   cd C:\Users\YourUsername\Downloads\OneDrive_1_1-22-2026\PERSONAL NEWS DIGEST WITH MEMORY\news-digest
   ```
   
   > **💡 Tip**: Replace `YourUsername` with your actual Windows username

2. To verify you're in the right folder, type:
   ```bash
   dir
   ```
   You should see files like `pyproject.toml`, and folders like `app`, `static`, `news_agent`, etc.

---

## Step 5: Create a Virtual Environment

A virtual environment is like a separate container for this project's software.

### 5.1 Create the Virtual Environment

While in the project folder, type:
```bash
python -m venv .venv
```

Wait a few seconds for it to complete.

### 5.2 Activate the Virtual Environment

Type:
```bash
.venv\Scripts\activate
```

You should now see `(.venv)` at the beginning of your command line, like this:
```
(.venv) C:\Users\YourUsername\...\news-digest>
```

> **📝 Note**: You'll need to activate the virtual environment every time you open a new Command Prompt to work on this project.

✅ **Success!** Virtual environment is ready.

---

## Step 6: Install Dependencies

Dependencies are additional software packages that the application needs to run.

### 6.1 Install All Required Packages

With your virtual environment activated (you should see `(.venv)`), type:
```bash
pip install -e .
```

This will download and install all required packages. This may take **3-5 minutes** depending on your internet speed.

### 6.2 Verify Installation

When it's done, verify the installation:
```bash
pip list
```

You should see packages like `fastapi`, `uvicorn`, `pymongo`, `google-adk`, and many others.

✅ **Success!** All dependencies are installed.

---

## Step 7: Configure Environment Variables

Environment variables are settings that tell the application how to connect to services.

### 7.1 Create the Environment File

1. In the project folder, you'll find a file called `env.example`
2. We need to make a copy called `.env`

Type this command:
```bash
copy env.example .env
```

### 7.2 Edit the Environment File

1. Open the `.env` file with Notepad:
   ```bash
   notepad .env
   ```

2. You'll see content like this:
   ```
   # Google AI API Key (required)
   GOOGLE_API_KEY=your_google_api_key_here
   
   # MongoDB Configuration
   MONGODB_URI=mongodb://localhost:27017
   MONGODB_DATABASE=news_digest
   
   # JWT Authentication
   JWT_SECRET_KEY=your_super_secret_jwt_key_change_in_production
   JWT_ALGORITHM=HS256
   JWT_EXPIRATION_HOURS=24
   
   # Application Settings
   APP_NAME=News Digest
   DEBUG=true
   HOST=0.0.0.0
   PORT=8000
   ```

3. **Replace** `your_google_api_key_here` with your actual Google API key from Step 3

4. **Replace** `your_super_secret_jwt_key_change_in_production` with any random phrase (e.g., `my-news-digest-secret-2024`)

5. **Save** the file (Ctrl + S) and close Notepad

### 7.3 Example of Completed .env File

```
# Google AI API Key (required)
GOOGLE_API_KEY=AIzaSyB1234567890abcdefghijklmnop

# MongoDB Configuration
MONGODB_URI=mongodb://localhost:27017
MONGODB_DATABASE=news_digest

# JWT Authentication
JWT_SECRET_KEY=my-news-digest-secret-key-2024
JWT_ALGORITHM=HS256
JWT_EXPIRATION_HOURS=24

# Application Settings
APP_NAME=News Digest
DEBUG=true
HOST=0.0.0.0
PORT=8000
```

✅ **Success!** Environment variables are configured.

---

## Step 8: Run the Application

Now let's start the application!

### 8.1 Start the Server

Make sure you're in the project folder with the virtual environment activated, then type:
```bash
python -m uvicorn app.main:app --reload
```

### 8.2 What You Should See

After a few seconds, you should see output like:
```
INFO:     Uvicorn running on http://127.0.0.1:8000 (Press CTRL+C to quit)
INFO:     Started reloader process
INFO:     Started server process
INFO:     Waiting for application startup.
INFO:     Application startup complete.
```

### 8.3 Access the Application

1. Open your web browser (Chrome, Firefox, Edge, etc.)
2. Go to: **http://localhost:8000**
3. You should see the Personal News Digest application!

### 8.4 Create an Account and Start Reading

1. Click **"Register"** or **"Sign Up"**
2. Enter your email and create a password
3. Log in with your new account
4. Select your interests and preferences
5. Get your personalized news digest!

### 8.5 Stop the Server

When you're done, go back to the Command Prompt and press `Ctrl + C` to stop the server.

✅ **Congratulations!** The application is running!

---

## Common Errors & How to Fix Them

### ❌ Error: "'python' is not recognized as an internal or external command"

**Problem**: Python wasn't added to your system PATH during installation.

**Solution**:
1. Reinstall Python from https://www.python.org/downloads/
2. ⚠️ Make sure to check **"Add Python to PATH"** at the bottom of the installer
3. Restart your computer
4. Try again

---

### ❌ Error: "'pip' is not recognized"

**Problem**: Pip wasn't installed correctly with Python.

**Solution**:
1. Try using `python -m pip` instead of just `pip`:
   ```bash
   python -m pip install -e .
   ```

---

### ❌ Error: "Cannot activate virtual environment"

**Problem**: PowerShell execution policy is blocking scripts.

**Solution**:
1. Open PowerShell as Administrator
2. Type:
   ```powershell
   Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
   ```
3. Type `Y` and press Enter
4. Close and reopen your terminal

**Alternative**: Use Command Prompt instead of PowerShell.

---

### ❌ Error: "Connection refused" or "Could not connect to MongoDB"

**Problem**: MongoDB service is not running.

**Solution**:
1. Press `Windows + R`, type `services.msc`, press Enter
2. Find **"MongoDB Server"** in the list
3. Right-click and select **"Start"**
4. If it's already running, try **"Restart"**

---

### ❌ Error: "Port 8000 already in use"

**Problem**: Another application is using port 8000.

**Solution 1**: Stop the other application:
1. Open Command Prompt as Administrator
2. Find what's using port 8000:
   ```bash
   netstat -ano | findstr :8000
   ```
3. Note the PID (number at the end)
4. Stop that process:
   ```bash
   taskkill /PID <PID> /F
   ```

**Solution 2**: Use a different port:
1. Edit your `.env` file
2. Change `PORT=8000` to `PORT=8001`
3. Run with:
   ```bash
   python -m uvicorn app.main:app --reload --port 8001
   ```
4. Access via http://localhost:8001

---

### ❌ Error: "GOOGLE_API_KEY not found" or "Invalid API key"

**Problem**: The API key is missing or incorrect.

**Solution**:
1. Open your `.env` file
2. Make sure `GOOGLE_API_KEY=` has your actual API key after it (no spaces)
3. Verify your API key at https://aistudio.google.com/apikey
4. Make sure there are no extra quotes around the key

---

### ❌ Error: "ModuleNotFoundError: No module named 'xyz'"

**Problem**: Dependencies weren't installed correctly.

**Solution**:
1. Make sure your virtual environment is activated (you should see `(.venv)`)
2. Reinstall dependencies:
   ```bash
   pip install -e .
   ```

---

### ❌ Error: "Failed to fetch RSS feeds" or "No articles found"

**Problem**: Network issues or RSS feed sources are temporarily unavailable.

**Solution**:
1. Check your internet connection
2. Wait a few minutes and try again
3. Some RSS sources may be temporarily down – the app uses multiple sources

---

### ❌ Error: "ERROR: Could not build wheels for..." during pip install

**Problem**: Missing build tools for some packages.

**Solution**:
1. Install Microsoft Visual C++ Build Tools:
   - Go to: https://visualstudio.microsoft.com/visual-cpp-build-tools/
   - Download and install
   - Select "Desktop development with C++"
2. Restart your computer
3. Try installing again

---

### ❌ Error: "SSL: CERTIFICATE_VERIFY_FAILED"

**Problem**: SSL certificate verification issues.

**Solution**:
```bash
pip install --trusted-host pypi.org --trusted-host pypi.python.org --trusted-host files.pythonhosted.org -e .
```

---

### ❌ Error: Application starts but page shows "Cannot connect" in browser

**Problem**: You might be using the wrong URL.

**Solution**:
1. Make sure you're using `http://` not `https://`
2. Try: http://localhost:8000
3. Try: http://127.0.0.1:8000

---

## How to Start After First Setup

Once you've completed the initial setup, starting the application is much simpler!

### Quick Start (Every Time)

1. **Open Command Prompt** (Windows + R, type `cmd`, press Enter)

2. **Navigate to the project folder**:
   ```bash
   cd C:\Users\YourUsername\Downloads\OneDrive_1_1-22-2026\PERSONAL NEWS DIGEST WITH MEMORY\news-digest
   ```

3. **Activate the virtual environment**:
   ```bash
   .venv\Scripts\activate
   ```

4. **Start the application**:
   ```bash
   python -m uvicorn app.main:app --reload
   ```

5. **Open your browser** and go to: **http://localhost:8000**

6. **When done**, press `Ctrl + C` in Command Prompt to stop

---

## Pro Tips

### 💡 Create a Startup Shortcut

Create a batch file to start the application with one double-click:

1. Open Notepad
2. Paste the following:
   ```batch
   @echo off
   cd /d "C:\Users\YourUsername\Downloads\OneDrive_1_1-22-2026\PERSONAL NEWS DIGEST WITH MEMORY\news-digest"
   call .venv\Scripts\activate
   echo Starting Personal News Digest...
   echo.
   echo Access the app at: http://localhost:8000
   echo Press Ctrl+C to stop the server
   echo.
   python -m uvicorn app.main:app --reload
   pause
   ```
3. Replace `YourUsername` with your actual Windows username
4. Save as `Start News Digest.bat` on your Desktop
5. Double-click it to start the application!

---

### 💡 How Personalization Works

The app learns from your interactions:

| Action | Effect |
|--------|--------|
| Click on article | +0.1 interest in that topic |
| Like an article | +0.3 topic interest, +0.2 source preference |
| Dismiss article | +0.2 to dismissed topics (shown less) |
| Save article | +0.5 topic interest |

The more you use it, the better your recommendations become!

---

### 💡 Backup Your Preferences

Your preferences and saved articles are stored in MongoDB. To back them up:

1. Open Command Prompt
2. Run:
   ```bash
   mongodump --db news_digest --out C:\Backups\news-backup
   ```

To restore:
```bash
mongorestore --db news_digest C:\Backups\news-backup\news_digest
```

---

### 💡 News Sources

The app fetches from these free RSS feeds:
- BBC World News
- BBC Technology
- TechCrunch
- The Verge
- Ars Technica
- NPR News
- Wired

No API keys needed for news – it's all free!

---

### 💡 View API Documentation

While the application is running, you can explore the API:
- **Interactive docs**: http://localhost:8000/docs
- **Alternative docs**: http://localhost:8000/redoc

---

## 📞 Need More Help?

If you encounter issues not covered in this guide:

1. **Check the README.md** file in the project folder for additional information
2. **Search the error message** on Google – someone has likely had the same problem
3. **Check MongoDB status** in Windows Services if database issues occur

---

## 🎉 Congratulations!

You've successfully set up the **Personal News Digest with Memory**! You can now:

- ✅ Get AI-curated news based on your interests
- ✅ Like, save, or dismiss articles to train your preferences
- ✅ Read AI-generated summaries for quick scanning
- ✅ Enjoy personalized recommendations that improve over time

Happy reading! 📰
