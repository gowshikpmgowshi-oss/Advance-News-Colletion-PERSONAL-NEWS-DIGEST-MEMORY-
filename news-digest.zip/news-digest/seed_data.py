"""
Seed data script for News Digest application.
Creates sample users with interaction history for testing.
"""
import asyncio
import random
from datetime import datetime, timedelta
from typing import Dict, Any, List

import bcrypt
from pymongo import AsyncMongoClient

# Configuration
MONGODB_URI = "mongodb://localhost:27017/"
MONGODB_DATABASE = "news_digest"

# Sample users
USERS = [
    {
        "email": "demo@example.com",
        "username": "demo",
        "password": "demo123"
    },
    {
        "email": "tech_lover@example.com",
        "username": "techlover",
        "password": "password123"
    },
    {
        "email": "news_junkie@example.com",
        "username": "newsjunkie",
        "password": "password123"
    }
]

# Sample articles
SAMPLE_ARTICLES = [
    {
        "id": "art001",
        "title": "AI Breakthrough: New Language Model Achieves Human-Level Reasoning",
        "link": "https://example.com/ai-breakthrough",
        "source": "techcrunch",
        "description": "Researchers announce a major advancement in AI capabilities...",
        "summary": "A new AI model demonstrates unprecedented reasoning abilities, matching human performance on complex logical tasks. This could revolutionize how we build intelligent systems.",
        "topics": ["technology", "science"],
        "published": (datetime.utcnow() - timedelta(hours=2)).isoformat()
    },
    {
        "id": "art002",
        "title": "Climate Summit Reaches Historic Agreement on Carbon Reduction",
        "link": "https://example.com/climate-summit",
        "source": "bbc_world",
        "description": "World leaders commit to ambitious new targets...",
        "summary": "The global climate summit concluded with nations agreeing to reduce carbon emissions by 50% by 2030. Environmental groups cautiously optimistic about implementation.",
        "topics": ["environment", "politics", "world"],
        "published": (datetime.utcnow() - timedelta(hours=5)).isoformat()
    },
    {
        "id": "art003",
        "title": "SpaceX Successfully Lands First Crew on Mars",
        "link": "https://example.com/spacex-mars",
        "source": "verge",
        "description": "Historic moment as humans set foot on the Red Planet...",
        "summary": "SpaceX's Starship delivered a crew of four astronauts to Mars, marking humanity's first interplanetary landing. The crew will establish the initial base camp.",
        "topics": ["technology", "science"],
        "published": (datetime.utcnow() - timedelta(hours=8)).isoformat()
    },
    {
        "id": "art004",
        "title": "Major Tech Companies Announce Record Quarterly Earnings",
        "link": "https://example.com/tech-earnings",
        "source": "ars_technica",
        "description": "Apple, Google, and Microsoft all beat expectations...",
        "summary": "Big tech companies reported earnings that exceeded analyst expectations. AI-driven products were cited as the main growth driver across all companies.",
        "topics": ["technology", "business"],
        "published": (datetime.utcnow() - timedelta(hours=10)).isoformat()
    },
    {
        "id": "art005",
        "title": "New Study Links Exercise to Improved Mental Health",
        "link": "https://example.com/exercise-mental-health",
        "source": "npr_news",
        "description": "Research confirms what many suspected about physical activity...",
        "summary": "A comprehensive study of 50,000 participants found that just 30 minutes of daily exercise significantly reduces symptoms of depression and anxiety.",
        "topics": ["health", "science"],
        "published": (datetime.utcnow() - timedelta(hours=12)).isoformat()
    },
    {
        "id": "art006",
        "title": "Electric Vehicle Sales Surpass Gas Cars for First Time",
        "link": "https://example.com/ev-sales",
        "source": "wired",
        "description": "A historic shift in the automotive industry...",
        "summary": "For the first time in history, electric vehicle sales have exceeded traditional gas-powered cars. Analysts predict this trend will accelerate.",
        "topics": ["technology", "business", "environment"],
        "published": (datetime.utcnow() - timedelta(hours=15)).isoformat()
    },
    {
        "id": "art007",
        "title": "Championship Final Goes to Overtime in Thrilling Match",
        "link": "https://example.com/championship-final",
        "source": "bbc_world",
        "description": "Sports fans witnessed an unforgettable game...",
        "summary": "The championship final delivered non-stop action, with the underdog team forcing overtime before ultimately claiming victory in the final seconds.",
        "topics": ["sports"],
        "published": (datetime.utcnow() - timedelta(hours=18)).isoformat()
    },
    {
        "id": "art008",
        "title": "Nobel Prize Awarded to Quantum Computing Pioneer",
        "link": "https://example.com/nobel-quantum",
        "source": "bbc_tech",
        "description": "Recognition for groundbreaking work in quantum mechanics...",
        "summary": "The Nobel Prize in Physics was awarded to a scientist whose work laid the foundation for quantum computing, promising to revolutionize computing power.",
        "topics": ["science", "technology"],
        "published": (datetime.utcnow() - timedelta(hours=20)).isoformat()
    }
]

# Interaction templates for different user types
USER_PREFERENCES = {
    "techlover": {
        "liked_topics": {"technology": 1.2, "science": 0.8, "business": 0.4},
        "dismissed_topics": {"sports": 0.6, "entertainment": 0.4},
        "source_weights": {"techcrunch": 0.8, "verge": 0.6, "ars_technica": 0.5}
    },
    "newsjunkie": {
        "liked_topics": {"world": 1.0, "politics": 0.9, "environment": 0.7, "health": 0.5},
        "dismissed_topics": {},
        "source_weights": {"bbc_world": 0.9, "npr_news": 0.7}
    }
}


def hash_password(password: str) -> str:
    """Hash a password using bcrypt."""
    hashed = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
    return hashed.decode('utf-8')


async def seed_database():
    """Seed the database with sample data."""
    print("Connecting to MongoDB...")
    client = AsyncMongoClient(MONGODB_URI)
    db = client[MONGODB_DATABASE]
    
    try:
        # Clear existing data
        print("Clearing existing data...")
        await db.users.delete_many({})
        await db.preferences.delete_many({})
        await db.articles.delete_many({})
        await db.interactions.delete_many({})
        await db.digests.delete_many({})
        
        # Create users
        print("Creating users...")
        user_ids = {}
        for user_data in USERS:
            user = {
                "email": user_data["email"],
                "username": user_data["username"],
                "password_hash": hash_password(user_data["password"]),
                "created_at": datetime.utcnow(),
                "updated_at": datetime.utcnow(),
                "total_digests_generated": 0,
                "total_articles_read": 0,
                "last_digest_at": None,
                "settings": {
                    "theme": "light",
                    "digest_time": "08:00",
                    "max_articles": 15,
                    "notifications_enabled": True
                }
            }
            result = await db.users.insert_one(user)
            user_ids[user_data["username"]] = str(result.inserted_id)
            print(f"  Created user: {user_data['username']} ({user_data['email']})")
        
        # Create preferences
        print("Creating preferences...")
        for username, user_id in user_ids.items():
            prefs = USER_PREFERENCES.get(username, {})
            preference = {
                "user_id": user_id,
                "liked_topics": prefs.get("liked_topics", {}),
                "dismissed_topics": prefs.get("dismissed_topics", {}),
                "source_weights": prefs.get("source_weights", {}),
                "blocked_sources": [],
                "custom_feeds": {},
                "created_at": datetime.utcnow(),
                "updated_at": datetime.utcnow()
            }
            await db.preferences.insert_one(preference)
            print(f"  Created preferences for: {username}")
        
        # Create articles
        print("Creating sample articles...")
        for article in SAMPLE_ARTICLES:
            article_doc = {
                "_id": article["id"],
                "title": article["title"],
                "link": article["link"],
                "source": article["source"],
                "description": article["description"],
                "summary": article["summary"],
                "topics": article["topics"],
                "published": datetime.fromisoformat(article["published"]),
                "fetched_at": datetime.utcnow(),
                "view_count": random.randint(0, 50),
                "like_count": random.randint(0, 20),
                "dismiss_count": random.randint(0, 10),
                "save_count": random.randint(0, 5)
            }
            await db.articles.insert_one(article_doc)
            print(f"  Created article: {article['title'][:50]}...")
        
        # Create sample interactions for techlover
        print("Creating sample interactions...")
        techlover_id = user_ids.get("techlover")
        if techlover_id:
            interactions = [
                ("art001", "like"),
                ("art001", "click"),
                ("art003", "like"),
                ("art003", "save"),
                ("art004", "click"),
                ("art006", "like"),
                ("art007", "dismiss"),
                ("art008", "click"),
                ("art008", "like"),
            ]
            
            for article_id, action in interactions:
                article = next((a for a in SAMPLE_ARTICLES if a["id"] == article_id), None)
                if article:
                    interaction = {
                        "user_id": techlover_id,
                        "article_id": article_id,
                        "action": action,
                        "article_title": article["title"],
                        "article_topics": article["topics"],
                        "article_source": article["source"],
                        "created_at": datetime.utcnow() - timedelta(hours=random.randint(1, 48))
                    }
                    await db.interactions.insert_one(interaction)
            
            print(f"  Created {len(interactions)} interactions for techlover")
        
        print("\n" + "=" * 50)
        print("Seed data created successfully!")
        print("=" * 50)
        print("\nYou can now log in with:")
        print("  Email: demo@example.com")
        print("  Password: demo123")
        print("\nOr try the pre-configured users:")
        print("  Email: tech_lover@example.com (password: password123)")
        print("  Email: news_junkie@example.com (password: password123)")
        
    finally:
        await client.close()


if __name__ == "__main__":
    asyncio.run(seed_database())
